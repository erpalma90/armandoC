function showSolicitudAprobacion(solicitudId){
    var urlStr = getShowSolicitudAprobacionURL();
    var passData = new Object();
    passData.solicitudId = solicitudId;
    ajaxGetData(urlStr, passData, solicitudAprobacionResultHtml)
}

function solicitudAprobacionResultHtml(data){
    jQuery("#modalShowSolicitudAprobacionId").modal();
    jQuery("#solicitudAprobacionDetalleBodyId").html(data);
}


function aprobarRechazarSolicitud(solicitudId, accion){
    try{
        showSpinner()
        var urlStr = getAprobarSolicitudURL();
        var passData = new Object();
        passData.solicitudId = solicitudId;
        passData.accion = accion;
        ajaxPutDataAsync(urlStr, passData, solicitudAprobadoResultHtml)
    }catch (error){
        console.log(error);
        hideSpinner()
    }
}

async function solicitudAprobadoResultHtml(data){
    var responseDTO = JSON.parse(data);
    if(responseDTO.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        toastTr('success', 'Creado', 'Creacion Exitosa!');
        reloadThisPage()
    }else{
        swalNotification('top-center', 'warning', responseDTO.resultError, 2000)
    }
}