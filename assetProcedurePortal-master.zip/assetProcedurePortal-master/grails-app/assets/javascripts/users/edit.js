window.addEventListener('load', function(){
    loadVendedoresSelect2();
    loadUsuarioSupevisorSelect2();
    loadData();
});

function loadData(){
    //var userSupervisorData = getUserSupervisor();
    //setOptToSelect2(jQuery("#vendedorSelect2Id"), userSupervisorData.result, userSupervisorData.id);
    //setOptToSelect2(jQuery("#userSupervisorSelect2Id"), getTipoDeSolicitudData(), getTipoDeSolicitudId());
}
