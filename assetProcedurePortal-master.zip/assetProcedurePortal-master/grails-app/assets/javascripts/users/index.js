window.addEventListener('load', function(){
    loadDtTable();
});
function loadDtTable(){
    var columnDataList = [];
    columnDataList = [
        { 'data': 'id' },
        { 'data': 'fullname' },
        { 'data': 'username' },
        { 'data': 'email' },
        { 'data': 'vendedor' },
        { 'data': 'supervisor' },
    ];
    var tableId = 'output';
    var url = getGetAllURL();
    var typeRequest = 'POST';
    loadIndexAjaxPagination(tableId, columnDataList, url, typeRequest, 'showUsers',
        false, MODULES.USERS.NAME, null, null);
}
function showUsers(id){
    window.location = getUsersShowURL(id)
}