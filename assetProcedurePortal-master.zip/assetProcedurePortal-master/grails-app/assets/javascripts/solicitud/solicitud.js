var solicitudDetalleToDeleteList = [];

function loadTipoDeSolicitudSelect2(){
    var select2Element = jQuery('#tipoDeSolicitudSelectId');
    var urlStr = getGetResultFromSelect2SolicitudURL();
    var passData = new Object();
    passData.entityName = 'tipoDeSolicitud';
    setSelect2WhitLimit(select2Element, passData, urlStr);
    select2Element.on('change', function (e) {

    });
}

async function loadProductosSolicitudSelect2(){
    var select2Element = jQuery('#productMultiSelect2Id');
    var seleccionados = jQuery("#productMultiSelect2Id").val()
    var urlStr = getGetResultFromSelect2SolicitudURL();
    var passData = new Object();
    passData.entityName = 'productos';
    passData.productosSeleccionados = seleccionados.toString();
    setSelect2WhitLimit(select2Element, passData, urlStr);

    select2Element.on("select2:select", async function (e) {
        var data = e.params.data.text;
        var productId = e.params.data.queryData.id;
        //await loadSelectUnidadDeMedida(productId)
        await addProductsSelectedInRetornoTable(productId);
    });

}


async function addProductsSelectedInRetornoTable(productId){
    var urlStr = getGetResultFromJSURL();
    var passData = new Object();
    passData.productoId = productId;
    passData.entityName = "productosTablaResultado"
    //var productList = await ajaxGetData(urlStr, passData);
    var productList = await getDataFromQueryAjax(urlStr, passData)

    var productTableElement = getById("productTableBodyId");
    var originalTrElement = getById("productTableTrId");
    for(var x = 0; x < productList.length; x++){
        var dto = productList[x];
        var productoId = dto.id;
        dto.removeId = "product-tr-id-"+productoId
        dto.cantidad = 0;
        dto.unidadDeMedidaSelect = "um-select"
        dto.motivoSolicitud = "";
        dto.codigoDeTickets = "";
        var productTr = getById("product-tr-id-"+productoId);
        if(productTr == null || productTr == undefined){
            var newTrElement = originalTrElement.cloneNode(true);
            newTrElement.style.display = "";
            newTrElement.setAttribute("id", "product-tr-id-"+productoId);
            newTrElement.setAttribute("attr-product-id", productoId)
            newTrElement.setAttribute("attr-unidadMedidaProductoIdFacturada", dto.unidad_medida_producto)
            newTrElement.setAttribute("class", "new-solicitudDetalle-product")
            setDataInTableTd(newTrElement, dto)
            productTableElement.appendChild(newTrElement)
            loadSelectUnidadDeMedida(productId)
            jQuery("#cantidad-"+productId).focus();
        }
    }

    //formatPageDataFromTags("attr-money-format");
}

function loadClientesSolicitudSelect2(){
    var select2Element = jQuery('#clienteSelect2Id');
    var urlStr = getGetResultFromSelect2SolicitudURL();
    var passData = new Object();
    passData.entityName = 'clientesSolicitud';
    var seleccionados = jQuery("#clienteSelect2Id").val()
    passData.seleccionados = seleccionados.toString();
    setSelect2WhitLimit(select2Element, passData, urlStr);
    select2Element.on('select2:select', function (e) {
        var data = e.params.data;
        var gcClienteHiddElement = getById("gcClientesElementId");
        var gcClienteSucursalHiddElement = getById("gcClienteSucursalElementId");

        var dataSplit = data.id.split("*");
        var id = dataSplit[0];
        var sucursalId = dataSplit[1];

        gcClienteHiddElement.value = id
        gcClienteSucursalHiddElement.value = sucursalId;
    });

}


function loadSelectUnidadDeMedida(productId){
    var urlStr = getGetResultFromJSURL();
    var passData = new Object();
    passData.productoId = productId;
    passData.entityName = "unidadDeMedidaPorProducto"
    var list = getDataFromQueryAjax(urlStr, passData)
    var selectElement = getById("unidadDeMedidaSelect-"+productId);
    jQuery(selectElement).children().remove();
    for(var x = 0; x < list.length; x++){
        var dto = list[x];
        var unidadMedidaProductoId = dto.id;
        var unidadMedida = dto.unidad_medida;
        var cantidad = dto.cantidad;
        var unidadMedidaId = dto.unidad_medida_id
        var optionElement = document.createElement("option");
        optionElement.appendChild(document.createTextNode(unidadMedida));
        optionElement.value = unidadMedidaProductoId;
        optionElement.setAttribute("cantidad", cantidad);
        //document.getElementById("orange").selected = true;
        if(unidadMedida.toUpperCase() == 'BOT' || unidadMedida.toUpperCase() == 'TET' ||
            unidadMedida.toUpperCase() == 'LAT' || unidadMedida.toUpperCase() == 'UND'){
            optionElement.selected = true;
        }
        selectElement.append(optionElement);
    }
}

function removeTrFromTrId(elementId, id){
    var productTrElement = document.getElementById(elementId);
    jQuery(productTrElement).remove();
    if(id != null && id != undefined){
        //jQuery('#productMultiSelect2Id').val(id).trigger("change");
        jQuery("#productMultiSelect2Id option[value='"+id+"']").remove();
    }
    if(productTrElement.classList.contains('existing-product')){
        solicitudDetalleToDeleteList.push(productTrElement.getAttribute("attr-solicitud-detalle-id"))
    }
}

function guardarSolicitud(){
    try {
        var requiredFieldsOkFlag = validateRequiredFields("solicitudFormDivId");
        if(requiredFieldsOkFlag){
            showSpinner();
            //obterner datos de cabecera
            var cabeceraList = document.getElementsByClassName("solicitudClass");
            var cabeceraMap = new Object();
            for(var x = 0; x < cabeceraList.length; x++){
                var element = cabeceraList[x];
                var fieldName = element.getAttribute("name");
                var elementValue = element.value;
                if(fieldName=='segundaSalida'){
                    elementValue = element.checked;
                }
                cabeceraMap[fieldName] = elementValue;
            }

            var detallesList = document.getElementsByClassName("new-solicitudDetalle-product");
            var detalleMapList = [];
            var detalleMap;
            for(var x = 0; x < detallesList.length; x++){
                detalleMap = new Object();
                var element = detallesList[x];
                var productoId = element.getAttribute("attr-product-id");
                var cantidad = document.getElementById("cantidad-"+productoId).value;
                var unidadDeMedida = document.getElementById("unidadDeMedidaSelect-"+productoId).value;
                var motivoSolicitud = document.getElementById("motivoSolicitud-"+productoId).value;
                var codigoDeTickets = document.getElementById("codigoDeTickets-"+productoId).value;
                detalleMap["productoId"]            = productoId;
                detalleMap["cantidad"]              = cantidad
                detalleMap["unidadDeMedida"]        = unidadDeMedida
                detalleMap["motivoSolicitudId"]       = motivoSolicitud
                detalleMap["codigoDeTickets"]       = codigoDeTickets
                detalleMapList.push(JSON.stringify(detalleMap));
            }
            var urlStr = getInsertSolicitudURL();
            var passData = new Object();
            passData.cabeceraMap = JSON.stringify(cabeceraMap);
            passData.detalleMapList = JSON.stringify(detalleMapList);
            getDataFromQueryAsyncAjax(urlStr, passData, solicitudResultHtml)
        }
    }catch (error){
        console.log(error);
        hideSpinner()
    }



}


function loadPlugins(){
    var dateToday = new Date();
    jQuery("#fechaDeRetiro").datepicker({
        format: "dd/mm/yyyy",
        clearBtn: true,
        language: "es",
        minDate: 0,
        autoclose: true,
        todayHighlight: true,
        startDate: '-0m'
    });
}

function solicitudResultHtml(data){
    try {
        var responseDTO = JSON.parse(data);
        if(responseDTO.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
            if(responseDTO.resultId != 0 && responseDTO.resultId != '0' &&
                responseDTO.resultId != null && responseDTO.resultId != ""){
                toastTr('success', 'Creado', 'Creacion Exitosa!');
                var resultId     = responseDTO.resultId;
                showSolicitud(resultId)

            }
        }else{
            swalNotification('top-center', 'warning', responseDTO.resultError, 2000)
        }
    }catch (error){
        hideSpinner()
    }
}

function showSolicitud(id){
    window.location = getShowSolicitudURL(id)
}

function actualizarSolicitud(){
    var requiredFieldsOkFlag = validateRequiredFields("solicitudFormDivId");
    if(requiredFieldsOkFlag){
        showSpinner()
        var solicitudId = getSolicitudId();
        //obterner datos de cabecera
        var cabeceraList = document.getElementsByClassName("solicitudClass");
        var cabeceraMap = new Object();
        for(var x = 0; x < cabeceraList.length; x++){
            var element = cabeceraList[x];
            var fieldName = element.getAttribute("name");
            var elementValue = element.value;
            if(fieldName=='segundaSalida'){
                elementValue = element.checked;
            }
            cabeceraMap[fieldName] = elementValue;
        }

        var detallesList = document.getElementsByClassName("new-solicitudDetalle-product");
        var detalleMapList = [];
        var detalleMap;
        for(var x = 0; x < detallesList.length; x++){
            detalleMap = new Object();
            var element = detallesList[x];
            var productoId = element.getAttribute("attr-product-id");
            var cantidad = document.getElementById("cantidad-"+productoId).value;
            var unidadDeMedida = document.getElementById("unidadDeMedidaSelect-"+productoId).value;
            var motivoSolicitud = document.getElementById("motivoSolicitud-"+productoId).value;
            var codigoDeTickets = document.getElementById("codigoDeTickets-"+productoId).value;

            detalleMap["productoId"]            = productoId;
            detalleMap["cantidad"]              = cantidad
            detalleMap["unidadDeMedida"]        = unidadDeMedida
            detalleMap["motivoSolicitudId"]     = motivoSolicitud
            detalleMap["codigoDeTickets"]       = codigoDeTickets
            detalleMapList.push(JSON.stringify(detalleMap));
        }

        var existentDetallesList = document.getElementsByClassName("existing-product");
        var existentDetalleMapList = [];
        var existentDetalleMap;
        for(var x = 0; x < existentDetallesList.length; x++){
            existentDetalleMap = new Object();
            var element = existentDetallesList[x];
            var solicitudDetalleId = element.getAttribute("attr-solicitud-detalle-id");
            var productoId = element.getAttribute("attr-producto-id");
            var cantidad = document.getElementById("cantidad-"+productoId).value;
            var unidadDeMedida = document.getElementById("unidadDeMedidaSelect-"+productoId).value;
            var motivoSolicitud = document.getElementById("motivoSolicitud-"+productoId).value;
            var codigoDeTickets = document.getElementById("codigoDeTickets-"+productoId).value;
            existentDetalleMap["solicitudDetalleId"] = solicitudDetalleId;
            existentDetalleMap["productoId"]                = productoId;
            existentDetalleMap["cantidad"]                  = cantidad
            existentDetalleMap["unidadDeMedida"]            = unidadDeMedida
            existentDetalleMap["motivoSolicitudId"]         = motivoSolicitud
            existentDetalleMap["codigoDeTickets"]           = codigoDeTickets
            existentDetalleMapList.push(JSON.stringify(existentDetalleMap));
        }

        var urlStr = getUpdateSolicitudURL();
        var passData = new Object();
        passData.solicitudId = solicitudId;
        passData.cabeceraMap = JSON.stringify(cabeceraMap);
        passData.newDetalleMapList = JSON.stringify(detalleMapList);
        passData.existentDetalleMapList = JSON.stringify(existentDetalleMapList);
        passData.solicitudDetalleToDeleteList = JSON.stringify(solicitudDetalleToDeleteList);
        getDataFromQueryAjax(urlStr, passData, solicitudResultHtml)
    }

}