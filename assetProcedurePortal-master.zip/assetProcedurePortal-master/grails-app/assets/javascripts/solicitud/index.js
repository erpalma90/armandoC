window.addEventListener('load', function(){
    //loadDtTable();
});
function loadDtTable(){
    var columnDataList = [];
    columnDataList = [
        { 'data': 'id' }
    ];
    var tableId = 'output';
    var url = getGetAllURL();
    var typeRequest = 'POST';
    var dataSet = new Object();
    loadIndexAjaxPagination(tableId, columnDataList, url, typeRequest, 'showPaciente',
        true, "solicitud_index", null, null);
}
function showPaciente(id){
    window.location = getPacienteShowURL(id)
}