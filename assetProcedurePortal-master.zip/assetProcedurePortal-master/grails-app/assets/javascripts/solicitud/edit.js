window.addEventListener('DOMContentLoaded', function(){
    loadTipoDeSolicitudSelect2()
    loadProductosSolicitudSelect2();
    loadClientesSolicitudSelect2();
    loadPlugins();
    loadDataSolicitud();
    loadSolicitudDetalle();
});

function loadDataSolicitud(){
    setOptToSelect2(jQuery("#tipoDeSolicitudSelectId"), getTipoDeSolicitudData(), getTipoDeSolicitudId());
    setOptToSelect2(jQuery("#clienteSelect2Id"), getClienteData(), getClienteId());
}


function loadSolicitudDetalle(){

    var solicitudDetalleElementsList = document.getElementsByClassName("solicitudDetalleClass");
    var productsSelect2 = jQuery("#productMultiSelect2Id")
    for(let x = 0; x < solicitudDetalleElementsList.length; x++){
        let hiddenElement = solicitudDetalleElementsList[x];
        let productoId = hiddenElement.getAttribute("attr-producto-id");
        let nombreProducto = hiddenElement.getAttribute("attr-producto")
        let productoCodigoDeBarra = hiddenElement.getAttribute("attr-producto-codigo-barra")
        let concat = productoId;
        if(productoCodigoDeBarra != null && productoCodigoDeBarra != undefined){
            concat = concat+"-"+productoCodigoDeBarra;
        }
        concat = concat+"-"+nombreProducto
        let opt = new Option(concat, productoId, true, true);
        productsSelect2.append(opt).trigger('change');
        //addProductsSelectedInRetornoTable(productoId);
    }

}