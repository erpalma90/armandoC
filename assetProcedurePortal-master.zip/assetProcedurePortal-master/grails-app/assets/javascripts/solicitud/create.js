window.addEventListener('DOMContentLoaded', function(){
    loadTipoDeSolicitudSelect2()
    loadProductosSolicitudSelect2();
    loadClientesSolicitudSelect2();
    loadPlugins();
});