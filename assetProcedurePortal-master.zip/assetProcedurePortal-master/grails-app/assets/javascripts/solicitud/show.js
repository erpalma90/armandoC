function procesarSolicitud(solicitudId){
    var passData = new Object();
    passData.solicitudId = solicitudId;
    ajaxPutData(getProcesarSolicitudURL(), passData, resolveProcesarSolicitud)

}

function resolveProcesarSolicitud(data){
    var responseDTO = JSON.parse(data);
    if(responseDTO.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        reloadThisPage();
    }else{
        swalNotification('top-center', 'warning', responseDTO.resultError, 2000)
    }
}