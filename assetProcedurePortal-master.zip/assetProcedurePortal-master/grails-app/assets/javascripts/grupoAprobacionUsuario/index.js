function showGrupoAprobacionUsuario(id){
    showSpinner();
    window.location = getShowGrupoAprobacionUsuarioURL(id);
}