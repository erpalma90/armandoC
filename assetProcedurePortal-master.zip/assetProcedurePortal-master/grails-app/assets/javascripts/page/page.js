window.addEventListener('load', function(){
    var passData = new Object();
    //ajaxGetData(getSolicitudesCantidadURL(), passData, loadChar)
});

function loadChar(data){
    var dataList =  JSON.parse(data);
    var descripcionList = [];
    var cantidadList = [];
    var cantidadTotal = 0
    for(var x = 0;x < dataList.length; x++){
        var dto = dataList[x];
        descripcionList.push(dto.tipoSolicitudDesc)
        cantidadList.push(parseInt(dto.cantidad))
        cantidadTotal = cantidadTotal+parseInt(dto.cantidad);
    }

    jQuery("#cantidadLabelId").html(cantidadTotal)
    const ctx = document.getElementById('myChart').getContext('2d');
    const myChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: descripcionList,
            datasets: [{
                label: '# of Votes',
                data: cantidadList,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 100)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            cutout: '0%',
            responsive: true,
            maintainAspectRatio: false
        }
    });
}