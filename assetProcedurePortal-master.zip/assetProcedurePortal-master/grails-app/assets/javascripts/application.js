// This is a manifest file that'll be compiled into application.js.
//
// Any JavaScript file within this directory can be referenced here using a relative path.
//
// You're free to add application-wide JavaScript to this file, but it's generally better
// to create separate JavaScript files as needed.
//
//= require bootstrap
//= require popper.min

//= require_self
/** //= require template */





function getById(id){
    var element = document.getElementById(id);
    return element;
}

function goToUrl(currentUrl, nextUrl, appendFlag, appendParams){
    var url = nextUrl;
    if(appendFlag == undefined || appendFlag == null || appendFlag != false){
        url = url+"?lastUrl="+currentUrl
        if(appendParams != null && appendParams != ""){
            url = url.trim()+" "+appendParams.trim();
        }
    }

    location.href = url;
}

function goToBackUrl(){
    var urlStr = lastUrlToBack();
    showSpinner();
    window.location = urlStr;
}
validateAndShowMenu();
function validateAndShowMenu(){
    let menuElementsList = document.getElementsByClassName("nav-item has-treeview");
    for(var x = 0; x < menuElementsList.length; x++){
        let element = menuElementsList[x];
        let childs = element.getElementsByClassName("sec-item");
        if(childs.length == 0){
            element.style.display = 'none';
        }
    }
}

var counter = 0;
function enviromentInfo(){
    ++counter;
    if(counter == 5){
        jQuery("#enviroment-info-modal-id").modal();
        counter = 0;
    }
}

