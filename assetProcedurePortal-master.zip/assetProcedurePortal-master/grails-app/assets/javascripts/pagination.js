
function loadIndexAjaxPagination(tableId, columnsDataList, url, typeRequest, showByIdFunction, filterEnterPress, entityName, dataSet, customizeDomDt){
    try{
        if(dataSet == undefined){
            dataSet = null;
        }
        $.fn.dataTable.ext.errMode = 'none';//desactivamos la molesta alerta de notificacion de columna vacia
        var table = $('#'+tableId).DataTable({
            // keys: true,
            "aLengthMenu": [[10, 50, 100, -1], [10, 50, 100, "Todos"]],
            "bProcessing": true,
            "serverSide": true,
            "entries": true,
            "bLengthChange": true,
            "bFilter": true,
            "pageLength": 10,
            //Hasta que no le agreguemos el boostrap esto no funciona
            language: {
                "lengthMenu": "Mostrando _MENU_ ",
                "zeroRecords": "No existen Registros",
                "info": "Mostrando pagina _PAGE_ de _PAGES_",
                "infoEmpty": "Vacio",
                "infoFiltered": "(filtrado de _MAX_ total de registros)",
                "search": "Buscar",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Siguiente"
                }

            },
            "ajax":{
                url :url, // json datasource
                type: typeRequest,  // type of method  , by default would be get
                "contentType": "application/json",
                "data":function (d){
                    d.entityName = entityName;
                    d.dataSet   = dataSet;
                    flag = true;
                    return JSON.stringify(d);
                },
                "dataSrc":function(json){
                    console.log(json)
                    return json.data;
                }
            },
            columns: columnsDataList,
            "fnRowCallback": function (nRow, aData, iDisplayIndex) {
                nRow.style.cursor = "pointer";
                nRow.setAttribute('onclick', showByIdFunction + '(' + aData.id + ')');
                nRow.setAttribute("id", "rowId-"+aData.id);
                nRow.setAttribute("class", "dtTrClass");
            },
            //dom: 'lfrtip',
            dom: (customizeDomDt!=null && customizeDomDt != undefined) ? customizeDomDt:""+
                "<'row'<'col-sm-12 col-md-2'l>" +
                "<'col-sm-12 col-md-2'f>" +
                "<'col-sm-12 col-md-2 pt-3'B>>"+
                "<'row'<'col-sm-12'tr>>" +
                "<'row'<'col-sm-12 col-md-12'p>" +
                "<'col-sm-12 col-md-12'i>>",
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation : 'landscape',
                    pageSize : 'A4',
                    className:"btn btn-warning",
                    customize: function(doc) {
                        doc.defaultStyle.alignment = 'center'
                    }
                },
            ]
        });

        var ouputFilterinputElement = $('#output_filter input');
        if(filterEnterPress == true){
            ouputFilterinputElement.unbind();
            ouputFilterinputElement.keyup(function (e) {
                if (e.keyCode == 13) /* if enter is pressed */ {
                    table.search($(this).val()).draw();
                }
            });
        }
    }catch(error){
        console.error("Exception in loadIndexAjaxPagination " + error);
    }
}





function dataTableAjaxTriggerSearch(tableId){
    let oTable = jQuery('#'+tableId).dataTable();
    oTable.fnFilter('');
}