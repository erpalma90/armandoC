window.addEventListener('load', function(){
    loadVendedoresSelect2();
    loadUsuarioSupevisorSelect2();
});
