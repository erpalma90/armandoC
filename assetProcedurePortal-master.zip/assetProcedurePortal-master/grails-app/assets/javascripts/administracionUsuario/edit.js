window.addEventListener('load', function(){
    loadVendedoresAdministrarUsuarioSelect2();
    loadSupervisorAdministrarUsuarioSelect2();
    loadJefeAdministracionUsuarioSelect2();
    loadDataAdministracionUsuario();
});

function loadDataAdministracionUsuario(){
    var vendedorData = getVendedorData();
    setOptToSelect2(jQuery("#vendedorSelect2Id"), vendedorData.result, vendedorData.id);
    var supervisorData = getSupervisorData();
    setOptToSelect2(jQuery("#supervisorSelect2Id"), supervisorData.result, supervisorData.id);


}


function actualizarUsuarioAdministracion(){
    try {
        //var requiredFieldsOkFlag = validateRequiredFields("solicitudFormDivId");
        if(true){
            showSpinner();
            //obterner datos de cabecera
            var cabeceraList = document.getElementsByClassName("users");
            var cabeceraMap = new Object();
            for(var x = 0; x < cabeceraList.length; x++){
                var element = cabeceraList[x];
                var fieldName = element.getAttribute("name");
                var elementValue;
                if(element.type.toUpperCase() == "CHECKBOX"){
                    elementValue = element.checked;
                }else{
                    elementValue = element.value;
                }
                cabeceraMap[fieldName] = elementValue;
            }

            var urlStr = getActualizarAdminsitrarUusarioURL();
            var passData = new Object();
            passData.cabeceraMap = JSON.stringify(cabeceraMap);

            getDataFromQueryAjax(urlStr, passData, administrarUsuarioResultHtml)
        }
    }catch (error){
        console.log(error);
        hideSpinner()
    }
}

async function administrarUsuarioResultHtml(data){
    reloadThisPage()

    /*
    try {

        var responseDTO = JSON.parse(data);
        if(responseDTO.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){

            if(responseDTO.resultId != 0 && responseDTO.resultId != '0' &&
                responseDTO.resultId != null && responseDTO.resultId != ""){
                toastTr('success', 'Creado', 'Creacion Exitosa!');
                var resultId     = responseDTO.resultId;
                showSolicitud(resultId)

            }

        }else{
            swalNotification('top-center', 'warning', responseDTO.resultError, 2000)
        }
    }catch (error){
        hideSpinner()
    }
    */
}