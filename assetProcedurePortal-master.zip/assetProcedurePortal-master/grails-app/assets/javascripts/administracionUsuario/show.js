window.addEventListener('load', function(){
    loadVendedoresRegistrarSelect2()
    loadSupervisorSelect2();
    loadJefeSelect2();
    changeRolActual(getById("nivelUsuarioSelectId"))
});
