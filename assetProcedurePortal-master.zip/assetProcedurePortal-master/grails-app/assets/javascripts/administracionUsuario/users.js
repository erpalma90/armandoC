
function loadVendedoresSelect2(){
    var select2Element = jQuery('#vendedorSelect2Id');
    var urlStr = getGetResultFromSelect2SolicitudURL();
    var passData = new Object();
    passData.entityName = 'vendedores';
    var seleccionados = select2Element.val()
    passData.seleccionados = seleccionados.toString();
    setSelect2WhitLimit(select2Element, passData, urlStr);
    select2Element.on('select2:select', function (e) {
        var data = e.params.data;
        var gcVendedoresHiddElement = getById("gcVendedoresHiddId");
        var gcVendedoresSucursalHiddElement = getById("gcVendedoresSucursalHiddId");

        var dataSplit = data.id.split("*");
        var id = dataSplit[0];
        var sucursalId = dataSplit[1];

        gcVendedoresHiddElement.value = id
        gcVendedoresSucursalHiddElement.value = sucursalId;

    });

}
function loadUsuarioSupevisorSelect2(){
    var select2Element = jQuery('#userSupervisorSelect2Id');
    var urlStr = getGetResultFromSelect2SolicitudURL();
    var passData = new Object();
    passData.entityName = 'userSupervisor';
    var seleccionados = select2Element.val()
    passData.seleccionados = seleccionados.toString();
    setSelect2WhitLimit(select2Element, passData, urlStr);
}
