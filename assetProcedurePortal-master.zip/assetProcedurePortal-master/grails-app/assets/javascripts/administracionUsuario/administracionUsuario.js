
function nularSelect2(){
    jQuery(".js-data-example-ajax").val(null).trigger('change')
}

function changeRolActual(element){
    nularSelect2()
    //REESTABLECER SELECT2 DEL VENDEDOR Y SUPERVISOR
    var elemento = $("option:selected", element);
    var seleccionado = elemento.attr("attr-nombreNivel");

    var vendedorDivElement = getById("vendedorDivId");
    var supervisorDivElement = getById("supervisorDivId");
    var jefeDivElement = getById("jefeDivId");
    if(seleccionado=="VENDEDOR"){
        vendedorDivElement.style.display = "block";
        supervisorDivElement.style.display = "block";
        jefeDivElement.style.display = "none";
    }else{
        vendedorDivElement.style.display = "none";
        supervisorDivElement.style.display = "none";
        jefeDivElement.style.display = "none";
        if(seleccionado=="VENTAS-SUPERVISOR"){
            jefeDivElement.style.display = "block";
        }else{
            jefeDivElement.style.display = "none";
        }
    }
}

function changeFilial(){
    nularSelect2()
}

function loadVendedoresAdministrarUsuarioSelect2(){
    var select2Element = jQuery('#vendedorSelect2Id');
    var urlStr = getGetResultFromSelect2RegisterURL();
    var passData = new Object();
    passData.entityName = 'vendedores';
    var idsValuesList = [];
    idsValuesList.push("sucursalId");
    idsValuesList.push("vendedorSelect2Id");
    setSelect2WhitLimitEnAdministrarUsuario(select2Element, passData, urlStr, idsValuesList);
    select2Element.on('select2:select', function (e) {
        var data = e.params.data;
        var gcVendedoresHiddElement = getById("gcVendedoresHiddId");
        var gcVendedoresSucursalHiddElement = getById("gcVendedoresSucursalHiddId");

        var dataSplit = data.id.split("*");
        var id = dataSplit[0];
        var sucursalId = dataSplit[1];

        gcVendedoresHiddElement.value = parseInt(id)
        gcVendedoresSucursalHiddElement.value = parseInt(sucursalId);

    });

}



function loadSupervisorAdministrarUsuarioSelect2(){
    var select2Element = jQuery('#supervisorSelect2Id');
    var urlStr = getGetResultFromSelect2RegisterURL();
    var passData = new Object();
    passData.entityName = "userSupervisor";
    var idsValuesList = [];
    idsValuesList.push("sucursalId");
    idsValuesList.push("vendedorSelect2Id");
    supervisorSelect2 = setSelect2WhitLimitEnAdministrarUsuario(select2Element, passData, urlStr, idsValuesList);
    select2Element.on('select2:select', function (e) {
        var data = e.params.data;
        getById("userSupervisorHiddId").value = data.id;
    });
}

function loadJefeAdministracionUsuarioSelect2(){
    var select2Element = jQuery('#jefeSelect2Id');
    var urlStr = getGetResultFromSelect2RegisterURL();
    var passData = new Object();
    passData.entityName = "userJefe";
    var idsValuesList = [];
    idsValuesList.push("sucursalId");
    idsValuesList.push("vendedorSelect2Id");
    supervisorSelect2 = setSelect2WhitLimitEnAdministrarUsuario(select2Element, passData, urlStr, idsValuesList);
    select2Element.on('select2:select', function (e) {
        var data = e.params.data;
        getById("userSupervisorHiddId").value = data.id;
    });
}

/*FUNCION PARA SETEAR DE FORMA GENERICA EL SELECT2*/
function setSelect2WhitLimitEnAdministrarUsuario(select2Element, passData, urlStr, idsValuesList){
    select2Element.select2({
        placeholder: 'Seleccionar',
        hideSelected: true,
        allowClear: true,
        width: 'resolve',
        ajax: {
            url: urlStr,
            dataType: 'json',
            type: 'GET',
            data: function (params) {
                var dataForPass = new Object();
                dataForPass = passData;
                if(idsValuesList != null && idsValuesList != undefined){
                    for(var x = 0; x < idsValuesList.length; x++){
                        var elementId = idsValuesList[x];
                        var element = getById(elementId);
                        dataForPass[elementId] = element.value;
                    }
                }

                var query = {
                    seleccionados:this.val(),//.toString(),
                    q: params.term,
                    passData:JSON.stringify(dataForPass)
                }
                // Query parameters will be ?search=[term]&page=[page]
                return query;
            },
            processResults(data) {
                return {
                    results: jQuery.map(data, function (item) {
                        var queryData = new Object();
                        for (const property in item) {
                            //console.log(`${property}: ${item[property]}`);
                            queryData[property] = item[property]
                        }
                        return {
                            text:   item.result,
                            id:     item.id,
                            queryData: queryData
                        }
                    })
                }
            }
        }
    });
    return select2Element;
}



