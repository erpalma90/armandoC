window.addEventListener('DOMContentLoaded', function(){
    jQuery('.js-example-basic-single').select2();
});