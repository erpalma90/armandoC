function editCondicionAprobacionDetalle(condicionAprobacionDetalleId){
    var urlStr = getEditCondicionAprobacionDetalleTemplateURL();
    var passData = new Object();
    passData.condicionAprobacionDetalleId = condicionAprobacionDetalleId;
    ajaxGetData(urlStr, passData, solicitudAprobacionResultHtml)
}

function deleteCondicionAprobacionDetalle(condicionAprobacionDetalleId){
    var urlStr = getDeleteCondicionAprobacionDetalleTemplateURL();
    var passData = new Object();
    passData.condicionAprobacionDetalleId = condicionAprobacionDetalleId;
    ajaxGetData(urlStr, passData, solicitudAprobacionDetalleCreateResultHtml)
}


function solicitudAprobacionResultHtml(data){
    jQuery("#modalCondicionAprobacionDetalleId").modal();
    jQuery("#solicitudAprobacionModalId").html(data);
}

function createCondicionAprobacionDetalle(){
    var urlStr = getCreateCondicionAprobacionDetalleTemplateURL();
    var passData = new Object();
    //passData.condicionAprobacionDetalleId = condicionAprobacionDetalleId;
    ajaxGetData(urlStr, passData, solicitudAprobacionResultHtml)
}

function guardarCondicionAprobacionDetalle(){
    var ordenAprobacion = getById("ordenAprobacion").value;
    var condicionAprobacionId = getCondicionAprobacionId();
    var grupoAprobacionId = getById("grupoAprobacion").value;
    var nombreGrupoAprobador = getById("nombreGrupoAprobador").value;


    var urlStr                      = getInsertCondicionAprobacionDetalleURL();
    var passData                    = new Object();
    passData.ordenAprobacion        = ordenAprobacion;
    passData.condicionAprobacionId  = condicionAprobacionId;
    passData.grupoAprobacionId      = grupoAprobacionId;
    passData.nombreGrupoAprobador   = nombreGrupoAprobador;
    ajaxPutData(urlStr, passData, solicitudAprobacionDetalleCreateResultHtml)
}

async function solicitudAprobacionDetalleCreateResultHtml(data){
    var responseDTO = JSON.parse(data);
    if(responseDTO.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        if(responseDTO.resultId != 0 && responseDTO.resultId != '0' &&
            responseDTO.resultId != null && responseDTO.resultId != ""){
            toastTr('success', 'Creado', 'Creacion Exitosa!');
            var resultId     = responseDTO.resultId;
            reloadThisPage()
        }
    }else{
        swalNotification('top-center', 'warning', responseDTO.resultError, 2000)
    }
}





function actualizarCondicionAprobacionDetalle(condicionAprobacionDetalleId){
    var ordenAprobacion = getById("ordenAprobacion").value;
    var condicionAprobacionId = getCondicionAprobacionId();
    var grupoAprobacionId = getById("grupoAprobacion").value;
    var nombreGrupoAprobador = getById("nombreGrupoAprobador").value;


    var urlStr                      = getUpdateCondicionAprobacionDetalleURL();
    var passData                    = new Object();
    passData.condicionAprobacionDetalleId = condicionAprobacionDetalleId;
    passData.ordenAprobacion        = ordenAprobacion;
    passData.condicionAprobacionId  = condicionAprobacionId;
    passData.grupoAprobacionId      = grupoAprobacionId;
    passData.nombreGrupoAprobador   = nombreGrupoAprobador;
    ajaxPutData(urlStr, passData, solicitudAprobacionDetalleCreateResultHtml)
}