function showCondicionAprobacion(id){
    showSpinner();
    window.location = getShowCondicionAprobacionURL(id);
}