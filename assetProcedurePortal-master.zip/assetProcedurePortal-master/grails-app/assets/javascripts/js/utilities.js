formatPageDataFromTags("attr-money-format");
formatPageDataFromTags("attr-numberRounded-format");
//getCurrentSucursal();
function createMovement(){
    jQuery("#modal-lg-id").modal();
}

function getOneValueFromTableAndCode(field, tableName, code){
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    passData.query = "SELECT "+field+" FROM "+tableName+" WHERE codigo = '"+code+"' ";
    var dataList = getDataFromQueryAjax(urlStr, passData)
    var valueReturn = null;
    for(var x = 0; x < dataList.length; x++){
        var data = dataList[x];
        valueReturn = data[field];
    }
    return valueReturn
}

function getDataFromQueryAjax(urlStr, passData, goToFunction){
    var dataToReturn = null;
    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:false,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            if(goToFunction != undefined && goToFunction != null){
                goToFunction(data);
            }else{
                dataToReturn = data;
            }
        },
        error: function () {
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
    return dataToReturn;
}

function getDataFromQueryAsyncAjax(urlStr, passData, goToFunction){
    var dataToReturn = null;
    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:true,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            if(goToFunction != undefined && goToFunction != null){
                goToFunction(data);
            }else{
                dataToReturn = data;
            }
        },
        error: function () {
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
    return dataToReturn;
}

async function postDataFromQueryAjax(urlStr, passData, goToFunction){
    var dataToReturn = null;
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:false,
        dataType: 'json',
        data: passData,
        complete: async function(data) {
            if(goToFunction != undefined && goToFunction != null){
                dataToReturn = null;
                await goToFunction();
            }else{
                dataToReturn = data;
            }
        },
        error: function () {
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
    return dataToReturn;
}
function getDataFromQueryAjaxJson(urlStr, passData, goToFunction){
    var dataToReturn = null;
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:true,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            if(goToFunction != undefined && goToFunction != null){
                goToFunction();
            }else{
                dataToReturn = data;
            }
        },
        error: function () {
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
    return dataToReturn;
}
function setDataInElementFromDto(dataDto){
    for(var data in dataDto) {
        var dataFormatted = camelCase(data)
        //dataDto.data = moment(date).format(formatter);
        var element = document.getElementById(dataFormatted);
        if(element != null && element != undefined){
            setValuesInElements(element, dataDto, data)
        }
    }
}


function setDataInTableTd(newTrElement, dataDto){
    for (var data in dataDto) {
        var element = newTrElement.getElementsByClassName(data)[0];
        if(element != undefined && element != null){
            if(element.getAttribute("attr-get") == "removeIconClass"){
                var removeIconElement = newTrElement.getElementsByClassName("removeIconClass")[0];
                removeIconElement.setAttribute("onclick", "removeTrFromTrId('"+dataDto[data]+"', '"+dataDto.id+"')");
            }else{
                //element.setAttribute("id", data+"-"+dataDto.id)
                setValuesInElements(element, dataDto, data)
            }
        }
    }
}
function setValuesInElements(element, dataDto, data){
    if(element.tagName.toUpperCase() == "INPUT"){
        if(element.type.toUpperCase() == "NUMBER"){
            element.setAttribute("id", data+"-"+dataDto.id)
            element.setAttribute("attr-id", dataDto.id)
        }else if(element.type.toUpperCase() == "CHECKBOX"){
            element.setAttribute("id", data+"-"+dataDto.id)
            element.setAttribute("attr-id", dataDto.id)
        }else if(element.type.toUpperCase() == "TEXT"){
            element.setAttribute("id", data+"-"+dataDto.id)
            element.setAttribute("attr-id", dataDto.id)
        }
    }else if(element.tagName.toUpperCase() == "I"){
        element.setAttribute("i-attr-id", dataDto.id)
    }else if(element.tagName.toUpperCase() == "SELECT"){
        element.setAttribute("id", data+"-"+dataDto.id)
        element.setAttribute("attr-id", dataDto.id)
    }else{
        jQuery(element).html(dataDto[data]);
    }
}
function showSpinner(){
    getById("spinnerId").style.display = "";
}

function hideSpinner(){
    getById("spinnerId").style.display = "none";
}


function refreshPage(){
    showSpinner();
    reloadPage();
}

function reloadPage(){
    location.reload();
}
var Toast;
$(function() {
    Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
    });
});

function toastTr(type, title, text){
    if(type == 'error'){
        toastr.error(text, title)
    }
    if(type == 'success'){
        toastr.success(text, title)
    }
    if(type == 'info'){
        toastr.info(text, title)
    }
    if(type == 'warning'){
        toastr.warning(text, title)
    }
}
function customToast(icon, title, text, confirmButtonText, confirmedFunction, notConfirmedfunction){
    Swal.fire({
        title: title,
        text: text,
        icon: icon,
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: confirmButtonText
    }).then((result) => {
        if (result.value == true) {
            confirmedFunction();
        }else{
            notConfirmedfunction();
        }
    })

}

function formatterDate(fecha, formato){
    var date = new Date(fecha);
    var newFecha = moment(date).format(formato);
    return newFecha;
}

function getConfigurationValueFromKey(key){
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    passData.query = "SELECT value FROM configuration WHERE key = '"+key+"' ";
    var dataList = getDataFromQueryAjax(urlStr, passData)
    var valueReturn = null;
    for(var x = 0; x < dataList.length; x++){
        var data = dataList[x];
        valueReturn = data['value'];
    }
    return valueReturn
}



function validarContraseñaFletero(){
    var returnFlag = false;
    var currentFleteroId = getCurrentFleteroId();
    var fleteroContraseña = getById("fleteroContraseñaInputId").value;
    var urlStr = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT count(*) FROM gc_fletero WHERE contraseña = ?  AND id = ? ");
    passData.query = sb.toString();
    var argsToSet = setContraseñaData(fleteroContraseña, currentFleteroId);
    passData.argsToSet = JSON.stringify(argsToSet);
    var dtoList = getDataFromQueryAjax(urlStr, passData)
    if(dtoList.length > 0){
        if(dtoList[0] != undefined && dtoList[0] != null){
            var cantidad = dtoList[0].count;
            if(cantidad > 0){
                toastTr('success', 'Aprobado', 'Verificacion Aprobada por Fletero');
                returnFlag = true;
            }else{
                toastTr('error', 'Error', 'Contraseña Incorrecta');
            }
        }
    }
    return returnFlag;
}

function setContraseñaData(fleteroContraseña, currentFleteroId){
    var columnsMap = new Map();
    columnsMap.set(1, [fleteroContraseña, DATABASE.DATA_TYPE.VARCHAR]);
    columnsMap.set(2, [currentFleteroId, DATABASE.DATA_TYPE.BIGINT]);

    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;

}

function modalConfirmMassiveApproval(movementNumber){
    //todo acenturion
    var checkClass = "";
    if(movementNumber == MOVIMIENTOS.DEVOLUCION.CODIGO){
        checkClass = "checkActionElement";
    }else if(movementNumber == MOVIMIENTOS.RETORNO.CODIGO){
        checkClass = "retornoCheckActionElement";
    }else if(movementNumber == MOVIMIENTOS.SOBRANTE.CODIGO){
        checkClass = "sobrantesCheckActionElement";
    }else if(movementNumber == MOVIMIENTOS.ACTIVOS_ENTRADA.CODIGO){
        checkClass = "activosEntradaCheckActionElement";
    }

    var checkedElement = jQuery("."+checkClass+":checkbox:checked")
    if(checkedElement != null && checkedElement.length > 0){
        var allShowedFlag = true;
        for(var x = 0; x < checkedElement.length; x++){
           var dvElement = checkedElement[x];
           var movementId = dvElement.getAttribute("attr-id");
           //movementNumber indica si se esta analizando desde devolucion(1) o retorno(2)
           var trElement = getById(movementNumber+"-"+movementId);
           var showed = trElement.getAttribute("attr-showed");
            if(showed == "false"){
                allShowedFlag = false;
                break;
            }
        }
        if(allShowedFlag){
            if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
                if(movementNumber == MOVIMIENTOS.DEVOLUCION.CODIGO){
                    modalContraseñaFletero('validarContraseñaFleteroYActualizacionMasiva')
                }else if(movementNumber == MOVIMIENTOS.RETORNO.CODIGO){
                    areYouShureRetornoAprovvedModalInMovimientosPorFletero();
                }else if(movementNumber == MOVIMIENTOS.SOBRANTE.CODIGO){
                    areYouShureSobranteAprovvedModalInMovimientosPorFletero();
                }else if(movementNumber == MOVIMIENTOS.ACTIVOS_ENTRADA.CODIGO){
                    areYouShureActivosEntradaAprovvedModalInMovimientosPorFletero();
                }
            }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
                var title = "Estas seguro? ";
                var text = "Estas seguro de realizar la aprobacion de la devolucion";
                var icon = 'warning'
                var confirmButtonText = "Si, aprobar";
                acceptOrCancellModal(title, text ,icon , confirmButtonText, devolucionStatusApproved)
            }
        }else{
            swalNotification('top-center', 'warning', 'Antes de realizar una aprobacion masiva, te recomendamos revisar y validar ' +
                'las cantidades de los productos.', 4000)
        }
    }else{
        swalNotification('top-center', 'warning', 'Debe seleccionar al menos un movimiento para aprobar', 2000)
    }
}

function modalContraseñaFletero(onclickName){
    jQuery("#fletero-contraseña-modal-id").modal();
    var fleteroContraseñaAcceptElement = getById("fleteroContraseñaAcceptActionId");
    fleteroContraseñaAcceptElement.setAttribute("onclick", onclickName+"()");
}

function acceptOrCancellModal(title, text, icon, confirmButtonText, confirmedFunction){
    Swal.fire({
        title: title,
        text: text,
        icon: icon,
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: confirmButtonText
    }).then((result) => {
        if (result.value == true) {
            confirmedFunction();
        }
    })
}

function swalNotification(position, icon, title, timer){
    hideSpinner()
    Swal.fire({
        customClass: {
            container: 'my-swal'
        },
        position: position,
        icon: icon,
        title: title,
        showConfirmButton: false,
        timer: timer
    })
}

function validateRequiredFields(parentElementId){
    var requiredElements = jQuery("#"+parentElementId+" [attr-required='true']");
    var flag = true;
    for(var x = 0; x < requiredElements.length; x++){
        var element = requiredElements[x];
        if(element.disabled != true && jQuery(element).is(':visible') == true){
            var currentValue = element.value;
            if(element.tagName.toUpperCase() == "INPUT"){
                var minValue = element.getAttribute("min");
                currentValue = element.value;
                if(minValue != null && minValue != undefined && parseInt(currentValue) < parseInt(minValue)){
                    flag = false;
                }
            }else if(element.tagName.toUpperCase() == "SELECT"){
                console.log(element)
                currentValue = element.value;
            }
            var alertText = "";
            var fieldName = element.getAttribute("attr-requiredName");
            if(flag){
                flag = variableLoadedValidation(currentValue);
                if(flag == false){
                    alertText = "El campo "+fieldName+" no puede estar vacio";
                }
            }else{
                alertText = "El campo "+fieldName+" no cumple con el valor minimo";
            }
            if(!flag){
                toastTr('warning', 'Alerta', alertText);
                break;
            }

        }
    }
    return flag;
}

function variableLoadedValidation(value){
    var flag = false;
    if(value != null && value != undefined && value.trim() != ""){
        flag = true;
    }
    return flag;
}

function camelCase(str) {
    return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(word, index)
    {
        return index == 0 ? word.toLowerCase() : word.toUpperCase();
    }).replace(/\s+/g, '');
}

async function getFletero(){
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    passData.query = "SELECT id, fletero, nro_movil FROM gc_fletero ";
    var resultList = await getDataFromQueryAjax(urlStr, passData)
    var select2Element = document.getElementById("fleteroSelectId");
    jQuery(select2Element).select2();
    for(var x = 0; x < resultList.length; x++){
        var dta = resultList[x];
        var optionElement = document.createElement("option")
        optionElement.appendChild(document.createTextNode(dta.nro_movil+" - "+dta.fletero));
        optionElement.value = dta.id
        select2Element.append(optionElement);
    }
}

function goToShowDevolucion(element){
    showSpinner();
    var devolucionId = element.getAttribute("i-attr-id");
    goToUrl(window.location, getDevolucionesShowUrl()+"/"+devolucionId);
}

function goToShowRetorno(element){
    showSpinner();
    var retornoId = element.getAttribute("i-attr-id");
    goToUrl(window.location, getRetornoShowUrl()+"/"+retornoId);
}

function goToShowSobrante(element){
    showSpinner();
    var sobranteId = element.getAttribute("i-attr-id");
    goToUrl(window.location, getSobranteShowUrl()+"/"+sobranteId);
}

function goToShowActivosSalida(element){
    showSpinner();
    var activosSalidaId = element.getAttribute("i-attr-id");
    goToUrl(window.location, getActivosSalidaShowUrl()+"/"+activosSalidaId);
}

function goToShowActivosEntrada(element){
    showSpinner();
    var activosEntradaId = element.getAttribute("i-attr-id");
    goToUrl(window.location, getActivosEntradaShowUrl()+"/"+activosEntradaId);
}

function priceAndIva(price){
    return parseFloat(price)+((parseFloat(price) * 10)/100);
}

function formatPageDataFromTags(attribute){
    var formatList = jQuery("["+attribute+"]");
    for(var x = 0; x < formatList.length; x++) {
        var element = formatList[x];
        var currentValue = "";
        currentValue = getValueFromContainerTag(element);
        if(attribute == "attr-money-format"){
            currentValue = formatter.format(currentValue);
        }else if(attribute == "attr-numberRounded-format"){
            if(element.getAttribute("attr-numberRounded-format") == "true"){
                currentValue = Math.round(currentValue);
            }
        }
        setValueFromContainerTag(element, currentValue);
    }
}

function getValueFromContainerTag(element){
    var value = null;
    if(element.tagName.toUpperCase() == "TD"){
        value = jQuery(element).html();
    }else if(element.tagName.toUpperCase() == "INPUT"){
        value = element.value;
    }else if(element.tagName.toUpperCase() == "SPAN"){
        value = jQuery(element).html();
    }
    return value;
}
function setValueFromContainerTag(element, value){
    if(element.tagName.toUpperCase() == "TD"){
        jQuery(element).html(value);
    }else if(element.tagName.toUpperCase() == "INPUT"){
        element.value = value;
    }else if(element.tagName.toUpperCase() == "SPAN"){
        jQuery(element).html(value);
    }
}

function reloadThisPage(){
    showSpinner();
    var urlStr = window.location;
    window.location = urlStr;
}

function refreshThisPage(){
    location.reload();
}

/*FUNCION PARA SETEAR DE FORMA GENERICA EL SELECT2*/
function setSelect2WhitLimit(select2Element, passData, urlStr){
    select2Element.select2({
        placeholder: 'Seleccionar',
        hideSelected: true,
        allowClear: true,
        width: 'resolve',
        ajax: {
            url: urlStr,
            dataType: 'json',
            type: 'GET',
            data: function (params) {
                var query = {
                    seleccionados:this.val().toString(),
                    q: params.term,
                    passData:JSON.stringify(passData)
                }
                // Query parameters will be ?search=[term]&page=[page]
                return query;
            },
            processResults(data) {
                return {
                    results: jQuery.map(data, function (item) {
                        var queryData = new Object();
                        for (const property in item) {
                            //console.log(`${property}: ${item[property]}`);
                            queryData[property] = item[property]
                        }
                        return {
                            text:   item.result,
                            id:     item.id,
                            queryData: queryData
                        }
                    })
                }
            }
        }
    });
}

function redondeoMonedaLocal(value){
    return Math.round(value);
}


function rechazoHtml(id){
    var r = new StringBuilder();
    r.append("<table>")
    if(id != null && id != undefined){
        r.append("  <tr>")
        r.append("      <td>")
        r.append("          <b>Id: </b>")
        r.append("      </td>")
        r.append("      <td>")
        r.append("          "+id);
        r.append("      </td>")
        r.append("  </tr>")
    }
    r.append("  <tr>")
    r.append("      <td>")
    r.append("          <b>Rechazado por Usuario: </b>")
    r.append("      </td>")
    r.append("      <td>")
    r.append("          "+getLoggedUsername());
    r.append("      </td>")
    r.append("  </tr>")
    r.append("  <tr>")
    r.append("      <td>")
    r.append("          <b>Motivo del Rechazo: </b>")
    r.append("      </td>")
    r.append("      <td>")
    r.append("          "+getById("motivoRechazoDeposito").value);
    r.append("      </td>")
    r.append("  </tr>")
    r.append("</table>")
    return r.toString();
}

function goToEmpaqueShowFromProductId(productId){
    goToUrl(window.location, getEmpaquesShowUrl()+"/"+productId, true);
}

function showAllRetornoDetalleDepositoFromDepositoId(depositoId){
    showSpinner();
    goToUrl(window.location, getDepositoDetalleFromDepositoIdURL()+"/"+depositoId, true);
}
function setOptToSelect2(select2Element, text, id){
    var opt = new Option(text, id, true, true);
    select2Element.append(opt).trigger('change');
}

function setResultListInSelect2(select2Element, resultList, columnsList){
    jQuery(select2Element).select2();
    for(var x = 0; x < resultList.length; x++){
        var data = resultList[x];
        var optionElement = document.createElement("option");
        var finalText = data[columnsList[0]];
        for(var i = 1; i < columnsList.length; i++){
            var currentText = data[columnsList[i]];
            finalText = finalText+currentText;
        }
        optionElement.appendChild(document.createTextNode(finalText));
        optionElement.value = data.id
        select2Element.append(optionElement);
    }
}

function loadDatePicker(datePickerElement, startView){
    //jQuery.datepicker.setDefaults(jQuery.datepicker.regional['es']);
    jQuery(datePickerElement).datepicker({
        todayHighlight: true,
        startView : startView,
        format: "dd/mm/yyyy",
        clearBtn: true,
        language: "es",
        autoclose: true
    });
    jQuery.fn.datepicker.dates['es'] = {
        days: ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"],
        daysShort: ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"],
        daysMin: ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sá"],
        months: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
        monthsShort: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
        today: "Hoy",
        clear: "Borrar",
        format: "dd/mm/yyyy",
        titleFormat: "MM yyyy", /* Leverages same syntax as 'format' */
        weekStart: 0
    };
    jQuery.datepicker.setDefaults(jQuery.datepicker.regional['es']);

    //jQuery("#datepicker").datepicker();
}

function getListToString(list){
    var sb = new StringBuilder();
    for(var x = 0; x < list.length; x++){
        sb.append("'")
        sb.append(list[x]);
        sb.append("'")
        sb.append(",");
    }
    var str = sb.toString();
    str = str.substring(0, str.length-1);
    return str;
}


function mostrarSucursalesAsignadas(){

    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    var sb = new StringBuilder();
    sb.append("select s.nombre, s.id as id_sucursal from user_sucursal us ");
    sb.append("left join sucursal s on s.id = us.sucursal_id ");
    sb.append("where (us.is_default != 'true' or  us.is_default is null or us.is_default = '') and us.user_id = "+getLoggedUserId()+" ORDER BY s.id asc ");
    console.log(sb.toString())
    passData.query = sb.toString();
    var dtoList = getDataFromQueryAjax(urlStr, passData)

    var parentElement = getById("sucursalModalParentDivId");
    jQuery(parentElement).html(""); //VACIA NUEVAMENTE AL HACER VARIAS VECES CLICK
    var originalElement = getById("originalSucursalBoxId");
    for(var x = 0; x < dtoList.length; x++){
        var dto = dtoList[x];
        var newElement = originalElement.cloneNode(true);
        newElement.id = "";
        newElement.style.display = "";
        newElement.setAttribute("onclick", "changeUserSucursalValue("+dto.id_sucursal+")");
        setDataInTableTd(newElement, dto)
        parentElement.appendChild(newElement)
    }
    jQuery("#sucursalesModalId").modal();

}


function changeUserSucursalValue(idSucursal){
    var urlStr = getUpdateSucursalDeUsuarioURL();
    var passData = new Object();
    passData.idSucursal = idSucursal;
    currentAjaxPutData(urlStr, passData, resolveChangeSucursal);
}



function resolveChangeSucursal(data){
    var messageDTO = JSON.parse(data);
    if(messageDTO.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        //swalNotification('top-center', 'success', 'Realizado', 2000);
        reloadThisPage()
    }else if(messageDTO.serverAction == SERVER_RESPONSE.SERVER_ERROR){
        hideSpinner();
        swalNotification('top-center', 'error', 'NO SE PUEDE EJECUTAR, CONSULTAR CON TI', 2000);
    }else{
        hideSpinner();
        swalNotification('top-center', 'warning', messageDTO.message, 7000)
    }
}


function currentAjaxPutData(urlStr, passData, goToFunction){
    let dataToReturn = null;
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:true,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                if(goToFunction != undefined && goToFunction != null){
                    goToFunction(data);
                }else{
                    dataToReturn = data;
                }
            }else if(data == ERROR.SERVER_ERROR){
                swalNotification('top-center', 'error', data.responseText, 2000);
            }
        },
        error: function (dataError) {
            swalNotification('top-center', 'error', dataError.responseText, 2000);
            console.log(dataError.responseText);
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
    return dataToReturn;
}

function currentAjaxGetData(urlStr, passData, goToFunction){
    let dataToReturn = null;
    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:true,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                if(goToFunction != undefined && goToFunction != null){
                    goToFunction(data);
                }else{
                    dataToReturn = data;
                }
            }else if(data == ERROR.SERVER_ERROR){
                swalNotification('top-center', 'error', data.responseText, 2000);
            }
        },
        error: function (dataError) {
            swalNotification('top-center', 'error', dataError.responseText, 2000);
            console.log(dataError.responseText);
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
    return dataToReturn;
}



function showUserUpdateModal(){
    var urlStr = getUserUpdateModalTemplateURL();
    var passData = new Object();
    var result = getDataFromQueryAjax(urlStr, passData, resolveShowUserUpdateModal)

}

function resolveShowUserUpdateModal(data){
    jQuery("#userUpdateModalId").modal();
    jQuery("#userUpdateModalBodyId").html(data);
}

function updateUserModal(){
    var pass = getById("password").value;
    var repass = getById("repassword").value;
    var requiredFieldsOkFlag = validateRequiredFields("updateUserDataDivId");
    if(requiredFieldsOkFlag){
        if(pass==repass){
            var passData = new Object();
            var entityFieldsList = document.getElementsByClassName("entity-field");
            var fields = new Object();
            for(var x = 0; x < entityFieldsList.length; x++){
                var entityFieldElement = entityFieldsList[x];
                fields[entityFieldElement.getAttribute("name")] = entityFieldElement.value;
            }
            passData.fields = JSON.stringify(fields);
            ajaxPutData(getUpdateUserDataFromModalURL(), passData, resolveUpdateUserModal)
        }else{
            swalNotification('top-center', 'warning', "Contraseñas no coincidentes", 2000)
        }
    }
}

async function resolveUpdateUserModal(data){
    var responseDTO = JSON.parse(data);
    if(responseDTO.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        desloguear()
    }else{
        swalNotification('top-center', 'warning', responseDTO.resultError, 2000)
    }
}

function areYouShureUpdateUserModal(){
    var title = "Estas seguro? ";
    var text = "Estas seguro de actualizar los datos de tu usuario?, esta accion cerrara tu sesión ";
    var icon = 'warning'
    var confirmButtonText = "Si, actualizar y cerrar sesión";
    acceptOrCancellModal(title, text ,icon , confirmButtonText, function () {
        updateUserModal();
    })
}

function printDocumentActivosEntrada(solicitudId){
    document.title="SOLICITUD_"+solicitudId;
    window.print();
    return false;
}