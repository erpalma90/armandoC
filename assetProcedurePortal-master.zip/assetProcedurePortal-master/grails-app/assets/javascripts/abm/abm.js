function create(element){
    var controller  = element.getAttribute("attr-entity");
    var action      = element.getAttribute("attr-action");

    var passData = new Object();
    passData.passEntity = controller;
    passData.passAction = action
    ajaxGetData(getMasterControllerURL(), passData, resultHtml)
}

function save(element, resultMethod){
    var entity  = element.getAttribute("attr-entity");
    var action  = element.getAttribute("attr-action");

    var passData = new Object();
    passData.passEntity = entity;
    passData.passAction = action;

    var entityFieldsList = document.getElementsByClassName("entity-field");
    var fields = new Object();
    for(var x = 0; x < entityFieldsList.length; x++){
        var entityFieldElement = entityFieldsList[x];
        fields[entityFieldElement.getAttribute("name")] = entityFieldElement.value;
    }
    passData.fields = JSON.stringify(fields);

    if(resultMethod == null || resultMethod ==undefined){
        ajaxPutData(getMasterControllerURL(), passData, resultHtml)
    }else {
        ajaxPutData(getMasterControllerURL(), passData, resultMethod)
    }

}

function showModal(element){
    var entity      = element.getAttribute("attr-entity");
    var action      = element.getAttribute("attr-action");
    var entityId    = element.getAttribute("attr-entityId");

    var passData = new Object();
    passData.passEntity     = entity;
    passData.passAction     = action;
    passData.passEntityId   = entityId;

    ajaxPutData(getMasterControllerURL(), passData, resultHtml)
}

function areYouShureDelete(element, functResult){
    var title = "Estas seguro? ";
    var text = "Estas seguro de eliminare el registro? ";
    var icon = 'warning'
    var confirmButtonText = "Si, eliminar";
    acceptOrCancellModal(title, text ,icon , confirmButtonText, function () {
        deleteModal(element, functResult);
    })
}

async function deleteModal(element, functResult){
    var entity      = element.getAttribute("attr-entity");
    var action      = element.getAttribute("attr-action");
    var entityId    = element.getAttribute("attr-entityId");

    var passData = new Object();
    passData.passEntity     = entity;
    passData.passAction     = action;
    passData.passEntityId   = entityId;

    if(functResult == null){
        functResult = resultHtml
    }
    await ajaxPutDataAsync(getMasterControllerURL(), passData, functResult);

}

async function resultHtml(data){
    var responseDTO = JSON.parse(data);
    if(responseDTO.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        if(responseDTO.resultTemplate != ""){
            var modalBodyElement = getById("modalBodyId");
            jQuery(modalBodyElement).html(responseDTO.resultTemplate);
            jQuery("#myModalId").modal()
        }else if(responseDTO.resultId != 0 && responseDTO.resultId != '0' &&
            responseDTO.resultId != null && responseDTO.resultId != ""){
            toastTr('success', 'Creado', 'Creacion Exitosa!');
            var resultId     = responseDTO.resultId;
            //jQuery("#myModalId").modal('toggle');
            //var table= jQuery('#output').Datatable();
            //table.draw();
            //alert("resultId; "+resultId)

            var resultEntity = responseDTO.resultEntity;
            var passData = new Object();
            passData.passEntity     = resultEntity;
            passData.passAction     = 'show';
            passData.passEntityId   = resultId;
            await ajaxPutData(getMasterControllerURL(), passData, resultHtml)

        }
    }else{
        swalNotification('top-center', 'warning', responseDTO.resultError, 2000)
    }
}


function updateMultiEntities(element, functResult){
    var entity  = element.getAttribute("attr-entity");
    var action  = element.getAttribute("attr-action");

    var passData = new Object();
    passData.passEntity = entity;
    passData.passAction = action;
    var containerElementId = element.getAttribute("container-field-id");
    var containerElement = getById(containerElementId);
    var entityFieldsList = containerElement.getElementsByClassName("entity-field");
    var fields = new Object();
    for(var x = 0; x < entityFieldsList.length; x++){
        var entityFieldElement = entityFieldsList[x];
        alert(entityFieldElement.value)
        fields[entityFieldElement.getAttribute("name")] = entityFieldElement.value;
    }
    passData.fields = JSON.stringify(fields);
    if(functResult == null){
        functResult = resultHtml
    }
    ajaxPutData(getMasterControllerURL(), passData, functResult)


}