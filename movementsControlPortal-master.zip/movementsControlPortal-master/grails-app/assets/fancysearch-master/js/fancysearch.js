/*
    JavaScript fancySearch
    created by P Kishor
    GitHub: https://github.com/punkish/fancysearch
    License: Released into the public domain under CC0
*/

"use strict";

const fancySearch = function() {

    // fsDiv is the container in which fancySearch is created
    // Everything happens inside fsDiv. It is set during init()
    let fsDiv;
    let facets;
    let facetKeys;
    let facetValues;

	const makeFsContainer = function(focus) {

        // We are going to create the following HTML
        /*
         *
         * <div class="fs-param-empty">
         *    <div class="fs-key off"></div>
         *    <input class="fs-key-input">
         *    <div class="fs-val off"></div>
         *    <input class="fs-val-input off">
         *    <div class="fs-cancel off"></div>
         * </div>
         *
         */

        let fsp = document.createElement('div');
        fsp.className = 'fs-param-empty';

        let fsk = document.createElement('div');
        fsk.className = 'fs-key off fskClass';

        let fskInput = document.createElement('input');
        fskInput.className = 'fs-key-input form-control fskInputClass';
        fskInput.setAttribute("style", "background-color: #2c518829;font-size:15px")
        fskInput.setAttribute("placeholder", "Buscar en columna")


        let fsv = document.createElement('div');
        fsv.className = 'fs-val off fsvClass';

        let fsvInput = document.createElement('input');
        fsvInput.className = 'fs-val-input off fsvInputClass';

        let fsc = document.createElement('div');
        fsc.innerText = 'x';
        fsc.className = 'fs-cancel off fscClass';

        // add '.fs-key' div to '.fs-param' div
        // and then add '.fs-param' div to 'fs' div
        fsp.appendChild(fsk);
        fsp.appendChild(fskInput);
        fsp.appendChild(fsv);
        fsp.appendChild(fsvInput);
        fsp.appendChild(fsc);
        fsDiv.appendChild(fsp);

        fskInput.addEventListener('keydown', modifyKeyPress);
        fsvInput.addEventListener('keydown', modifyKeyPress);
        fsc.addEventListener('click', removeFsp);

        aCfacets('key', fskInput, facetKeys);
        if(focus!=undefined&&focus==true){
            // fskInput.focus();
        }

    };

    const modifyKeyPress = function(event) {
        const ENTER = 13;
        const BACKSPACE = 8;
        const DEL = 46;
    
        event = event || window.event;
        const keyPressed = event.which || event.keyCode;

        let thisInput = event.target;
        let fsp = thisInput.parentElement;
        // let fsk = fsp.children[0];
        let fsk = fsp.getElementsByClassName("fskClass")[0];
        // let fskInput = fsp.children[1];
        let fskInput = fsp.getElementsByClassName("fskInputClass")[0];
        // let fsv = fsp.children[2];
        let fsv = fsp.getElementsByClassName("fsvClass")[0];
        // let fsvInput = fsp.children[3];
        let fsvInput = fsp.getElementsByClassName("fsvInputClass")[0];
        // let fsc = fsp.children[4];
        let fsc = fsp.getElementsByClassName("fscClass")[0]

        if (keyPressed == ENTER) {
            if (fsvInput.value !== '') {
                fsp.className = 'fs-param-filled';
                fsv.innerText = fsvInput.value;
                fsv.className = 'fs-val on fsvClass';
                fsvInput.className = 'off fsvInputClass';
                fsc.className = 'fs-cancel on';

                makeFsContainer();
                getById("go1").click()
            }
    
            event.preventDefault();
            event.stopPropagation();
            return false;
        }else if (keyPressed == BACKSPACE || keyPressed == DEL) {
            console.log('a');
            if (thisInput.value === '') {
                console.log('b');

                let allFsp = document.querySelectorAll(`div#${fsDiv.id} div.fs-param-filled`);
                let lastFsp = allFsp[allFsp.length];
    
                if (lastFsp) {
                    console.log('h');
                    if (lastFsp.className === 'fs-param-filled') {
                        lastFsp.className = 'fs-param-filled hilite';
                    }
                    else if (lastFsp.className = 'fs-param-filled hilite') {
                        lastFsp.parentElement.removeChild(lastFsp);
                    }
                    makeFsContainer(true);
                }else {
                    console.log('i');

                    let allFsp = document.querySelectorAll(`div#${fsDiv.id} div.fs-param-empty`);
                    let lastFsp = allFsp[allFsp.length - 1];

                    lastFsp.parentElement.removeChild(lastFsp);
                    makeFsContainer(true);
                }
                
            }
            else {
                console.log('c');
            }
        }
    };
    
    const removeFsp = function(event) {
        const that = this.parentElement;
        that.parentElement.removeChild(that);
    };
    
    const aCfacets = function(type, selector, choices) {

        new autoComplete({
            selector: selector,
            minChars: Array.isArray(choices) ? 0 : 3,
            source: function(term, response) {
    
                if (Array.isArray(choices)) {
                    term = term.toLowerCase();
                    let matches = [];
                    let j = choices.length;
        
                    for (let i = 0; i < j; i++) {
                        if (~choices[i].toLowerCase().indexOf(term)) {
                            matches.push(choices[i]);
                        }
                    }

                    response(matches);
                }
                else {
                    try { xhr.abort(); } catch(e){}
                    xhr(choices + '/' + term, response);
                }
            },
            onSelect: function(e, term, item) {
                let newChoices;
                let thisInput = this.selector;
                let fsp = thisInput.parentElement;
                
                if (type === 'key') {
                    let fsk = fsp.getElementsByClassName("fskClass")[0];
                    fsk.innerText = thisInput.value + ':';
                    fsk.className = 'fs-key on bg-primary text-white fskClass';

                    thisInput.className = 'off fskInputClass';
    
                    let i = 0;
                    let j = facets.length;
                    var dbQColumnName = "";
                    var dbColumnName = "";
                    var dbTableName = ""
                    for (; i < j; i++) {
                        var facetsObj = facets[i]
                        if (facetsObj.key === term) {
                            newChoices = facetsObj.values
                            dbQColumnName = facetsObj.dbQColumnName
                            dbColumnName = facetsObj.dbColumnName
                            dbTableName = facetsObj.dbTableName;
                            if (facetsObj.noDuplicates) {
                                facetKeys.splice(facetKeys.indexOf(term), 1);
                            }
                            break;
                        }
                    }
    
                    let nextInput = fsp.children[3];
                    nextInput.className = 'fs-val-input on form-control fsvInputClass';

                    fsk.setAttribute("attr-db-q-column-name", dbQColumnName)
                    fsk.setAttribute("attr-dbColumnName", dbColumnName)
                    fsk.setAttribute("attr-dbTableName", dbTableName)
                    aCfacets('val', nextInput, newChoices);
                    nextInput.focus();
                }else if (type === 'val') {

                    let fsv = fsp.children[2];
                    
                    if (term) {
                        fsv.innerText = thisInput.value;
                        fsv.className = 'fs-val on';
                    }
                    
                    thisInput.className = 'off';
                    fsp.className = 'fs-param-filled';
                    fsp.children[4].className = 'fs-cancel on';
    
                    let i = 0;
                    let j = facets.length;
    
                    for (; i < j; i++) {
                        if (facets[i]['key'] === term) {
                            newChoices = facets[i]['values'];
                            break;
                        }
                    }
    
                    makeFsContainer();
                }
            }
        });
    };

    const xhr = function(href, cb) {
        let x = new XMLHttpRequest();

        x.onload = function(event) {
            if (x.readyState === 4) {
                if (x.status === 200) {
                    const res = JSON.parse(x.responseText);
                    cb(res);
                }
            }
        };

        x.onerror = function(e) {
            console.error(x.statusText);
        };

        x.open("GET", href, true);
        x.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        x.send();
    };

	return  {
        
        result: function() {
            const params = fsDiv.getElementsByClassName("fs-param-filled");
            let q = {};
            for (let j = 0; j < params.length; j++) {
                // const kvOld = params[j].children;
                const kv = params[j];

                var fskElement = kv.getElementsByClassName("fskClass")[0];
                const dbQColumnName = fskElement.getAttribute("attr-db-q-column-name");
                const dbColumnName  = fskElement.getAttribute("attr-dbColumnName");
                const dbTableName   = fskElement.getAttribute("attr-dbTableName");

                const key = kv.getElementsByClassName("fskInputClass")[0].value;
                var valueElement = kv.getElementsByClassName("fsvInputClass")[0];
                const val = valueElement.value.replace(/\n$/, '');

                if (key && val) {
                    var obj = new Object();
                    if (key in q) {
                        if (q[key].constructor == Object) {
                            const newObj = q[key];
                            obj.dbQColumnName = dbQColumnName
                            obj.dbColumnName = dbColumnName;
                            obj.dbTableName = dbTableName;
                            obj.val = val
                            q[key] = [newObj, obj]
                        }else {
                            //alert("2")
                            obj.dbQColumnName = dbQColumnName
                            obj.dbColumnName = dbColumnName;
                            obj.dbTableName = dbTableName;
                            obj.val = val
                            q[key].push(obj);
                        }
                    }else{
                        obj.dbQColumnName = dbQColumnName
                        obj.dbColumnName = dbColumnName;
                        obj.dbTableName = dbTableName;
                        obj.val = val
                        q[key] = obj;
                    }
                }
            }
            // console.log(JSON.stringify(q))
            return q;
        },

		init: function(selector, data) {
            
            // https://stackoverflow.com/questions/7028145/find-key-name-in-hash-with-only-one-key
            fsDiv = selector;
            facets = data;
            facetKeys = facets.map(element => { return element['key'] });
            facetValues = facets.map(element => { return element['values'] });

            makeFsContainer(true);
		}
	};
};

function removeElement(element){
    const that = element.parentElement;
    that.parentElement.removeChild(that);
}