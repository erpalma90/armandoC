window.onload = function() {
    const fs1 = document.getElementById('fs1');
    const go1 = document.getElementById('go1');
    loadLastSearch()
    const widget1 = new fancySearch;
    widget1.init(fs1, facetsLocal);
    go1.addEventListener('click', function(event) {
        event.preventDefault();
        // event.stopPropagation();
        let query = widget1.result();
        getById("searchBoxId").value = JSON.stringify(query)
        getById("myForm").submit()
    });
};

function loadLastSearch(){
    var lastVal = getById("searchBoxId").value
    if(lastVal!=null&&lastVal!=""){
        var d = JSON.parse(lastVal)
        var resText = ""
        for (var key in d){
            var propJSON = d[key];
            var propList = []
            if(propJSON instanceof Array){
                propList = propJSON
            }else{
                propList.push(propJSON)
            }
            for(var z = 0; z < propList.length; z++){
                var propObject = propList[z];
                // alert(JSON.stringify(propObject))
                var valList = propObject.val;

                var dbQColumnName = propObject.dbQColumnName
                var dbColumnName = propObject.dbColumnName;
                var dbTableName = propObject.dbTableName;
                var val = propObject.val;

                resText = resText+" | "+key+"= " + val;
                constrLoadElements(dbQColumnName, dbColumnName, dbTableName, key, val)
            }

        }
        // jQuery("#resBusqId").html(resText)
    }else{
        // widget1.init(fs1, facetsLocal);
    }
}

function constrLoadElements(dbQColumnName, dbColumnName, dbTableName, key, val){
    var paramFilled = document.createElement("div");
    paramFilled.setAttribute("class", "fs-param-filled");

    var fskElement = document.createElement("div");
    fskElement.setAttribute("class", "fs-key on bg-primary text-white fskClass")
    fskElement.setAttribute("attr-db-q-column-name", dbQColumnName)
    fskElement.setAttribute("attr-dbcolumnname", dbColumnName)
    fskElement.setAttribute("attr-dbtablename", dbTableName)
    fskElement.innerHTML = key+":"

    var fslInputElement = document.createElement("input")
    fslInputElement.setAttribute("class", "off fskInputClass");
    fslInputElement.setAttribute("autocomplete", "off");
    fslInputElement.setAttribute("value", key);

    var fsvElement = document.createElement("div");
    fsvElement.setAttribute("class", "fs-val on fsvClass")
    fsvElement.innerHTML = val

    var fsvInputElement = document.createElement("input")
    fsvInputElement.setAttribute("class", "off fsvInputClass");
    fsvInputElement.setAttribute("autocomplete", "off");
    fsvInputElement.setAttribute("value", val);

    var fscElement = document.createElement("div");
    fscElement.setAttribute("class", "fs-cancel on")
    fscElement.setAttribute("onclick", "removeElement(this)")
    fscElement.innerHTML = "x"

    paramFilled.appendChild(fskElement);
    paramFilled.appendChild(fslInputElement);
    paramFilled.appendChild(fsvElement);
    paramFilled.appendChild(fsvInputElement);
    paramFilled.appendChild(fscElement);

    getById("fs1").appendChild(paramFilled);
}