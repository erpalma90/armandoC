calcularTotalLinea();

function calcularTotalLinea(){
    var trElements = document.getElementsByClassName("details-tr");
    var sumaImporteTotal = 0;
    var sumaImpuesto = 0;
    for(var x = 0; x < trElements.length; x++){
        var trElement = trElements[x];
        var cantidad    = trElement.getElementsByClassName("cantidadEnvaseClass")[0].value;
        var precioUnit  = trElement.getElementsByClassName("precioUnitClass")[0].value;
        var precioImpuestoUnit = redondeoMonedaLocal((parseInt(precioUnit)*10)/100)
        var impuestoPorCant = cantidad*precioImpuestoUnit;
        //sumaImpuesto = sumaImpuesto+impuestoPorCant;
        var totalLinea = parseInt(cantidad)*parseInt(precioUnit);
        console.log(precioUnit+"*"+cantidad+"=: "+totalLinea+" | "+precioImpuestoUnit)

        var totalLineaElement = trElement.getElementsByClassName("totalLineaAutocalcClass")[0];
        var totalLineaHiddenElement = trElement.getElementsByClassName("totalLineaHiddenClass")[0];
        jQuery(totalLineaElement).html(totalLinea);
        totalLineaHiddenElement.value = totalLinea
        sumaImporteTotal = sumaImporteTotal+totalLinea;
    }
    var importeTotalElement = getById("importeTotalId");


    jQuery(importeTotalElement).html(sumaImporteTotal+sumaImpuesto)
}

function changeTotalLinea(idProducto){
    var cantidad    = getById("cantidad-"+idProducto).value;
    var precioUnit  = getById("precioUnit-"+idProducto).value;
    var totalLinea = parseInt(cantidad)*parseInt(precioUnit);

    var totalLineaElement = getById("totalLineaAutocalc-"+idProducto);
    var totalLineaHiddenElement = getById("totalLineaConIva-"+idProducto);
    jQuery(totalLineaElement).html(totalLinea);
    totalLineaHiddenElement.value = totalLinea;
    calcularTotalLinea()
}

function removeTrFromTrIdRefact(elementId, id){
    var productTrElement = document.getElementById(elementId);
    jQuery(productTrElement).remove();
    if(id != null && id != undefined){
        jQuery("#productMultiSelect2Id option[value='"+id+"']").remove();
    }
    if(productTrElement.classList.contains('existing-product')){
        devolucionDetalleToDeleteList.push(productTrElement.getAttribute("attr-devolucion-detalle-id"))
    }
    calcularTotalLinea()
}

async function ejecutarRefacturacion(id){
    getById("spinnerId").style.display = "";
    var importeTotalElement = getById("importeTotalId")
    var importeTotal = jQuery(importeTotalElement).html();


    var detailsTrElements = document.getElementsByClassName("details-tr");
    var detalleMapList = [];
    var detalleMap;
    for(var x = 0; x < detailsTrElements.length; x++){
        detalleMap = new Object();
        var trElement = detailsTrElements[x];
        var productoId      = trElement.getAttribute("attr-product-id");
        var precioUnitario  = getById("precioUnit-"+productoId).value
        var cantidad        = getById("cantidad-"+productoId).value
        var idLinea         = getById("idLineaId-"+productoId).value;
        var totalLineaConIva= getById("totalLineaConIva-"+productoId).value;
        detalleMap["productoId"]        = productoId;
        detalleMap["precioUnitario"]    = precioUnitario;
        detalleMap["cantidad"]          = cantidad;
        detalleMap["idLinea"]           = idLinea;
        detalleMap["totalLineaConIva"]  = totalLineaConIva;
        detalleMapList.push(JSON.stringify(detalleMap));
    }

    var urlStr = getProcesarRefacturacionUrl();
    var passData = new Object();
    passData.refacturacionId    = id;
    passData.detalleMapList     = JSON.stringify(detalleMapList);

    ajaxGetData(urlStr, passData, refacturacionResultHtml)
}

async function refacturacionResultHtml(data){
    var responseDTO = JSON.parse(data);
    if(responseDTO.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        toastTr('success', 'Creado', 'Creacion Exitosa!');
        reloadThisPage();
    }else{
        swalNotification('top-center', 'warning', responseDTO.resultError, 2000)
    }
}