
function estasSeguroProcesarRefacturacion(id){
    var sb = new StringBuilder();
    sb.append("Esta accion")
    sb.append("<ul style='text-align:left'>");
    sb.append("     <li>Genera una nota de credito <b>\"ajuste por devolucion\"</b> en base a la factura original</li>");
    sb.append("     <li>Genera una nueva factura en base a los cambios realizados en esta ventana</li>");
    sb.append("     <li>Envia un correo de notificacion sobre esta accion</li>");
    sb.append("</ul>")
    acceptOrCancellModalHtml("Estas seguro de procesar la Refacturacion? ", sb.toString() ,'warning' ,
        "Si, procesar", async function () {return ejecutarRefacturacion(id)});
}

function estasSeguroNoProcesarRefacturacion(id){
    acceptOrCancellModal("Estas seguro? ", "Estas seguro de No Procesar la Refacturacion?" ,'warning' ,
        "Si, no procesar", function () {return procesarNoProcesar(id)});
}

function procesarRefacturacion(id){
    showSpinner();
    var urlStr = getProcesarRefacturacionUrl();
    var passData = new Object();
    passData.refacturacionId = id;
    ajaxPutData(urlStr, passData, processedFunction)
}

function processedFunction(data){
    var responseDTO = JSON.parse(data);
    if(responseDTO.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        swalNotification('top-center', 'success', 'Procesado', 2000);
        refreshThisPage();
    }else if(responseDTO.serverAction == SERVER_RESPONSE.SERVER_ERROR){
        swalNotification('top-center', 'error', 'NO SE PUEDE EJECUTAR, CONSULTAR CON TI', 2000);
    }else{
        hideSpinner();
        swalNotification('top-center', 'warning', data.msgRtrn, 2000)
    }
}


function procesarNoProcesar(id){
    showSpinner();
    var urlStr = getProcesarNoProcesarUrl();
    var passData = new Object();
    passData.refacturacionId = id;
    ajaxPutData(urlStr, passData, processedFunction)
}


function facturaModal(refacturacionId, accion){
    showSpinner();
    var urlStr = getObtenerDatosFacturaARefacturarUrl();
    var passData = new Object();
    passData.refacturacionId = refacturacionId;
    passData.accion = accion;
    ajaxGetData(urlStr, passData, resolveRefacturacionModal)
}

function resolveRefacturacionModal(data){
    hideSpinner()
    jQuery("#refacturacionModalId").modal();
    jQuery("#refacturacionModalBodyId").html(data);
}