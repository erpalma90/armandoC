var sobranteDetalleToDeleteList = [];
async function initJsPage(){
    await loadSobrantesData();
    await getFleterosPendientesDeRendicionSobrantesWhitLimit()
    await getProductosSobrantesWhitLimit();
    await showDetailsInLog();
}

function updateSobranteDetailsAuxDeposito(){
    var passDataList = []

    var sobrantesDetailsPassDataUpdate = getSobranteDetailsAuxDepositoPassDataUpdate();
    if(sobrantesDetailsPassDataUpdate != null){
        passDataList.push(sobrantesDetailsPassDataUpdate);
    }


    /*
    var sobrantesDetailsPassDataInsert = getSobrantesDetailsAuxDepositoPassDataInsert()
    if(sobrantesDetailsPassDataInsert != null){
        passDataList.push(sobrantesDetailsPassDataInsert)
    }
    */

    /*
    var sobrantesDetailsPassDataDelete = getSobranteDetailsAuxDepositoPassDataDelete()
    if(sobrantesDetailsPassDataDelete != null){
        passDataList.push(sobrantesDetailsPassDataDelete)
    }
    */


    var passData = new Object();
    passData.parentId = getSobranteId();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                reloadThisPage();
            }else{
                alert('No se pudo guardar el retorno: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo guardar el retorno');
        }
    });
}

function showDetailsInLog(){
    var sobranteId = getSobranteId();
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    var sb = new StringBuilder();
    sb.append("select p.id as producto_id, p.codigo_barra, p.producto, sd.cantidad_documentada, sd.cantidad_verificada_deposito ");
    sb.append("from sobrante_detalle sd ");
    sb.append("join gc_productos p on p.id = sd.gc_producto_id ");
    sb.append("where sd.sobrante_id = "+sobranteId);

    passData.query = sb.toString();
    var resultList = getDataFromQueryAjax(urlStr, passData)
    for(var i = 0; i < resultList.length; i++){
        var dto = resultList[i]
        console.log(dto.producto_id+"-"+dto.codigo_barra+"-"+dto.producto+": "+dto.cantidad_documentada);
    }
}