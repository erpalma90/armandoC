var sobranteDetalleToDeleteList = [];
async function initJsPage(){
    await loadSobrantesData();
    await getFleterosPendientesDeRendicionSobrantesWhitLimit()
    await getProductosSobrantesWhitLimit();
    loadOrdenDeTransporteSobrante();
}





function updateSobrante(){
    var passDataList = []
    var sobrantesDetailsPassDataUpdate = getSobranteDetailsPassDataUpdate();
    if(sobrantesDetailsPassDataUpdate != null){
        passDataList.push(sobrantesDetailsPassDataUpdate);
    }

    var sobrantesDetailsPassDataInsert = getSobrantesDetailsPassDataInsert()
    if(sobrantesDetailsPassDataInsert != null){
        passDataList.push(sobrantesDetailsPassDataInsert)
    }

    var sobrantesDetailsPassDataDelete = getSobranteDetailsPassDataDelete()
    if(sobrantesDetailsPassDataDelete != null){
        passDataList.push(sobrantesDetailsPassDataDelete)
    }

    var passData = getSobrantePassDataUpdate(true);
    passData.parentId = getSobranteId();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                goToBackUrl()
            }else{
                alert('No se pudo guardar el retorno: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo guardar el retorno');
        }
    });
}

function getSobranteDetailsPassDataUpdate(){
    var sb = new StringBuilder();
    sb.append("UPDATE sobrante_detalle SET cantidad_documentada=? ");
    sb.append("WHERE id = ? ");

    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosSobranteDetalleUpdate();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}


function getDatosSobranteDetalleUpdate(){
    let trProductosAgregados = document.getElementsByClassName("existing-product");
    let detallesList = [];
    for(let i = 0; i < trProductosAgregados.length; i++){
        var trProductElement = trProductosAgregados[i]
        var retornoDetalleId = trProductElement.getAttribute("attr-sobrante-detalle-id");
        let productId = trProductElement.getAttribute("attr-product-id")

        var options = getById("unidadDeMedidaSelect-"+productId).options;
        var unidadDeMedidaText     = options[options.selectedIndex].text;
        var cantidadDocumentada = parseInt(getById("cantidad-"+productId).value);
        if( unidadDeMedidaText.toUpperCase() == 'CAJ' ||
            unidadDeMedidaText.toUpperCase() == 'PACK'){
            cantidadDocumentada = cantidadDocumentada*options[options.selectedIndex].attributes[1].value
        }

        let columnsMap = new Map();
        columnsMap.set(1, [cantidadDocumentada,      DATABASE.DATA_TYPE.INTEGER]);
        columnsMap.set(2, [retornoDetalleId,            DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        detallesList.push(obj);
    }
    return detallesList;
}


function getSobrantePassDataUpdate(detailChangeFlag){
    var sb = new StringBuilder();
    sb.append("UPDATE sobrante SET gc_fletero_id=?, fecha_sobrante=current_timestamp, user_last_updated_date=current_timestamp, ");
    sb.append("user_last_updated_id=?, observacion=?, ");
    sb.append("sobrante_estados_id=?, od_freight_order_id=? ")
    sb.append("WHERE id = ? ");

    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosSobranteUpdate(detailChangeFlag);
    passData.argsToSet = JSON.stringify(argsToSet);

    return passData;
}

function getDatosSobranteUpdate(detailChangeFlag){
    var orderDeTransporteId = jQuery("#ordenTransporteSelectId").val();
    var currentUserId = getLoggedUserId();
    var gcFleteroId = getById("fleteroSeleccionadoId").value;
    var estadoPendienteId = getOneValueFromTableAndCode("id", "sobrante_estados",
        SOBRANTE.ESTADO.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.CODIGO);
    var observacion = getById("observacionId").value;

    let obj = null;
    if(1==1){
        var columnsMap = new Map();
        columnsMap.set(1, [gcFleteroId, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(2, [currentUserId, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(3, [observacion, DATABASE.DATA_TYPE.VARCHAR]);
        columnsMap.set(4, [estadoPendienteId, DATABASE.DATA_TYPE.BIGINT]);
        columnsMap.set(5, [orderDeTransporteId, DATABASE.DATA_TYPE.BIGINT]);
        columnsMap.set(6, [getSobranteId(), DATABASE.DATA_TYPE.BIGINT]);
        obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
    }

    return obj;
}

function getSobranteDetailsPassDataDelete(){
    var sb = new StringBuilder();
    sb.append("DELETE FROM sobrante_detalle WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosSobranteDetalleDelete();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosSobranteDetalleDelete(){
    let sobranteDetallesList = [];
    for(let i = 0; i < sobranteDetalleToDeleteList.length; i++){
        let sobranteDetalleId = sobranteDetalleToDeleteList[i]
        let columnsMap = new Map();
        columnsMap.set(1, [sobranteDetalleId, DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        sobranteDetallesList.push(obj);
    }
    return sobranteDetallesList;
}