async function initJsPage(){
    await getFleterosPendientesDeRendicionSobrantesWhitLimit()
    await getProductosSobrantesWhitLimit();
    loadOrdenDeTransporteSobrante()
}

function saveSobrante(){
    //var existFleteroSobranteEnFechaFlag = validateSobranteFleteroFechaExist();
    var flag = true //parseInt(existFleteroSobranteEnFechaFlag) == 0
    if(flag){
        showSpinner();
        var passDataList = [];
        passDataList.push(getSobrantesDetailsPassDataInsert())
        var passData = getSobrantePassDataInsert();
        passData.details = JSON.stringify(passDataList);
        var urlStr = getDynamicExecuteUpdateUrl();
        jQuery.ajax({
            url: urlStr,
            type: 'PUT',
            async:false,
            data: passData,
            success: function(data) {
                if(data != ERROR.SERVER_ERROR){
                    goToUrl(getIndexUrl(), getSobranteShowUrl()+"/"+data, true);
                }else{
                    alert('No se pudo guardar el sobrante: e '+ERROR.SERVER_ERROR);
                    hideSpinner();
                }
            },
            error: function () {
                hideSpinner();
                alert('Error, no se pudo guardar el sobrante');
            }
        });
    }else{
        var txtSb = new StringBuilder();
        txtSb.append("No se puede guardar este sobrante, el fletero ya cuenta con un sobrante creado en ");
        txtSb.append("la fecha.")
        swalNotification('top-center', 'warning', txtSb.toString(), 3000);
    }
}

function validateSobranteFleteroFechaExist(){
    var fleteroId = jQuery("#fleteroSelectId").val();
    var sb = new StringBuilder();
    sb.append("SELECT count(*) FROM sobrante WHERE gc_fletero_id = "+fleteroId+" AND cast(fecha_sobrante as DATE) = current_date ");
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    passData.query = sb.toString();
    var list = getDataFromQueryAjax(urlStr, passData);
    return list[0].count
}
