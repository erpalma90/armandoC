function editSobrante(){
    showSpinner();
    var sobranteId = getSobranteId();
    goToUrl(window.location, getSobranteEditUrl()+"/"+sobranteId);
}

function areYouShureSobranteAprovvedModalInShow(){
    var sobranteId = getSobranteId();
    if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
        acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la aprobacion del sobrante?" ,'warning' ,
            "Si, aprobar", function () {return actualizacionDeSobranteEstado(ACCION_APROBAR, sobranteId)});
    }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
        acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la aprobacion del retorno?" ,'warning' ,
            "Si, aprobar", function () {return validateSobranteCantidadesVerificadasAndActualizarEstado()});
    }
}



function validateSobranteCantidadesVerificadasAndActualizarEstado(){
    var sobranteId = getSobranteId();
    var cantidadDiferenciaRegistroDeposito = getSobranteDetalleAuxDepositoList(sobranteId);
    if(cantidadDiferenciaRegistroDeposito != null && cantidadDiferenciaRegistroDeposito != undefined && cantidadDiferenciaRegistroDeposito == 0){
        swalNotification('top-center', "success", "Cantidades Coicidentes con Registro", 7000);
        actualizacionDeSobranteEstado(ACCION_APROBAR, sobranteId);
    }else{
        var title = "La cantidad no coincide con la verificacion de Registro, favor volver a realizar el conteo, o aplicar rechazo del movimiento";
        swalNotification('top-center', "warning",
            title, 7000);
    }
}




function getSobranteDetalleAuxDepositoList(sobranteId){
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    var sb = new StringBuilder();
    sb.append("SELECT count(*) FROM sobrante_detalle ");
    sb.append("WHERE cantidad_verificada_deposito != cantidad_documentada AND sobrante_id = "+sobranteId+" ");
    passData.query = sb.toString();
    var resultList = getDataFromQueryAjax(urlStr, passData)
    return resultList[0].count;
}


function showSobrantesVerificacion(){
    getById("sobranteDetallesDivId").style.display = "none"
    getById("sobranteDetallesVerificateDivId").style.display = ""

    getById("sobranteDetallesDivButtonsId").style.display = "none"
    getById("sobranteDetallesVerificateDivButtonsId").style.display = ""

}

function guardarVerificacionSobrante(){
    updateSobranteDetailsAuxDeposito();
}

function printDocumentSobrante(retornoId, fletero){
    var d = moment().format('DD MM YYYY HH:mm');
    document.title="RETORNO_"+retornoId+"_"+fletero+"_"+d;
    window.print();
    return false;
}

function validacionDeRechazoSobrante(){
    jQuery("#rechazar-modal-id").modal();
    var correoDepositoSupervisor = getConfigurationValueFromKey("deposito.supervisor.correo.destinatario");
    jQuery("#correoNotificacionDivId").html(correoDepositoSupervisor);
    var rechazarBtnElement = getById("rechazarYEnviarCorreoBtnId");
    rechazarBtnElement.setAttribute("onclick", "rechazarSobranteEnDeposito()")
    //actualizacionDeEstado(2);
}

function rechazarSobranteEnDeposito(){
    var sobranteId = getSobranteId();
    var motivoRec = getById("motivoRechazoDeposito").value
    if(motivoRec != null && motivoRec != ""){
        showSpinner();
        var urlStr = getSendMailURL();
        var passData = new Object();
        passData.mailTo = getConfigurationValueFromKey("deposito.supervisor.correo.destinatario");
        passData.subject = "Sobrante Rechazado en Deposito"
        var element = getById("bodyHtmlId");
        var htmlContent = element.innerHTML;
        var motivoRechazoDeposito = rechazoHtml(getSobranteId());
        passData.body = motivoRechazoDeposito+htmlContent
        getDataFromQueryAjaxJson(urlStr, passData, null);
        actualizacionDeSobranteEstado(ACCION_RECHAZAR, sobranteId);
    }else{
        toastTr('warning', 'Advertencia', 'Debe describir el motivo del rechazo');
    }
}