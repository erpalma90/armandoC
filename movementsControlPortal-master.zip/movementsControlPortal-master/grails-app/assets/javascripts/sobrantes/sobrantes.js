function getFleterosPendientesDeRendicionSobrantesWhitLimit(){
    var url = getGetDataFromQueryAndPsInGCURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT TOP 300 f.[Id Fleteros] as id, cast(f.[Numero Camion] as varchar)+'-'+cast(f.nombre as varchar) AS result  ");
    sb.append("FROM [VTA_C Comprobantes de Ventas] cv ");
    sb.append("INNER JOIN vta_fleteros f ON ");
    sb.append("cv.[id sucursales] = f.[id sucursales] AND ");
    sb.append("cv.[id fleteros] = f.[id fleteros] ");
    sb.append("WHERE cv.Status = '00' AND cv.[Fecha] > '01/01/2021' ");
    sb.append("AND cv.[fecha cierre] IS NULL ");
    passData.query = sb.toString();
    var fleteroSelect2Element = jQuery('#fleteroSelectId');
    setSelect2WhitLimit(fleteroSelect2Element, sb.toString(), setFleteroData, getFleteroFilterQuery, url)
    fleteroSelect2Element.on('change', function (e) {

    });
}
function setFleteroData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}
function getFleteroFilterQuery(query, filter){
    if(filter != undefined && filter != null && filter.trim() != ''){
        query = query+" AND cast(f.[Numero Camion] as varchar)+'-'+cast(f.nombre as varchar) like ? "
    }
    return query+" GROUP BY f.[Id Fleteros], f.[Numero Camion], f.nombre ORDER BY result ASC ";
}

function getProductosSobrantesWhitLimit(){
    var url = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT gump.gc_productos_id as id, min(gump.cantidad) as cantidad, um.unidad_medida, p.producto, ");
    sb.append("concat(p.id,CASE WHEN p.codigo_barra is not null THEN CONCAT(' - ', p.codigo_barra) END, CONCAT(' - ',p.producto)) as result ");
    sb.append("FROM gc_unidad_medida_productos gump ");
    sb.append("JOIN gc_unidad_medidas um ON um.id = gump.gc_unidad_medidas_id ");
    sb.append("JOIN gc_productos p ON p.id = gump.gc_productos_id ");

    passData.query = sb.toString();
    var productMultiSelect2Element = jQuery('#productMultiSelect2Id');
    setSelect2WhitLimit(productMultiSelect2Element, sb.toString(), setProductosSobrantesData, getProductosSobrantesFilterQuery, url)
    productMultiSelect2Element.on("select2:select", async function (e) {
        var id = e.params.data.id;
        await addProductsSelectedInSobranteTable(id);
        await loadSelectUnidadDeMedidaEnSobrante(id)
    });
    productMultiSelect2Element.on("select2:unselect", function (e) {
        var id = e.params.data.id;
        removeTrFromTrId("product-tr-id-"+id)
    });
}

function setProductosSobrantesData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getProductosSobrantesFilterQuery(query, filter){
    var sb = new StringBuilder();
    sb.append(query.toString()+" ");


    var selectedProducts = jQuery('#productMultiSelect2Id').val().toString()
    if(selectedProducts != undefined && selectedProducts != null && selectedProducts.trim() != ''){
        sb.append(" AND p.id NOT IN ("+selectedProducts+") ")
    }

    if(filter != undefined && filter != null && filter.trim() != ''){
        sb.append("AND concat(p.id,CASE WHEN p.codigo_barra is not null THEN CONCAT(' - ', p.codigo_barra) END, CONCAT(' - ',p.producto)) ilike ? ")
    }

    sb.append("group by gump.gc_productos_id, um.unidad_medida, p.producto, ");
    sb.append("concat(p.id,CASE WHEN p.codigo_barra is not null THEN CONCAT(' - ', p.codigo_barra) END, CONCAT(' - ',p.producto)) ");
    sb.append("having min(gump.cantidad) = 1 ");
    sb.append("order by gump.gc_productos_id asc ");

    return sb.toString();

}


async function addProductsSelectedInSobranteTable(productId){
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    var sb = new StringBuilder();
    sb.append("SELECT p.*, um_bot.unidad_medida as medida_und, um_caj.unidad_medida as medida_pack, ump.id as unidad_medida_producto ");
    sb.append("FROM gc_unidad_medida_productos ump ");
    sb.append("JOIN gc_productos p on p.id = ump.gc_productos_id ");
    sb.append("LEFT JOIN gc_unidad_medidas um_bot ON um_bot.id = ump.gc_unidad_medidas_id AND um_bot.unidad_medida IN ('Bot', 'Und', 'Lat', 'Tet') ");
    sb.append("LEFT JOIN gc_unidad_medidas um_caj ON um_caj.id = ump.gc_unidad_medidas_id AND um_caj.unidad_medida IN ('Caj', 'Pack') ");
    sb.append("WHERE 1=1 ");
    sb.append("AND p.id = "+productId+" ");
    sb.append("ORDER BY p.id ASC, um_bot.unidad_medida NULLS LAST ");
    sb.append("LIMIT 1 ");

    passData.query = sb.toString();
    var productList = await getDataFromQueryAjax(urlStr, passData)
    var productTableElement = getById("productTableBodyId");
    var originalTrElement = getById("productTableTrId");
    for(var x = 0; x < productList.length; x++){
        var dto = productList[x];
        var productoId = dto.id;
        //var unidadMedidaProductoIdFacturada = dto.unidad_medida_producto_id
        dto.removeId = "product-tr-id-"+productoId
        dto.cantidad = 0;
        dto.unidadDeMedidaSelect = "um-select"
        var productTr = getById("product-tr-id-"+productoId);
        if(productTr == null || productTr == undefined){
            var newTrElement = originalTrElement.cloneNode(true);
            newTrElement.style.display = "";
            newTrElement.setAttribute("attr-product-id", productoId)
            newTrElement.setAttribute("id", "product-tr-id-"+productoId);
            newTrElement.setAttribute("attr-cantidadEnvaseFacturada", dto.cantidadEnvase);
            newTrElement.setAttribute("attr-precioUnitarioFacturado", dto.precioUnitario);
            newTrElement.setAttribute("attr-precioTotalFacturado", dto.precioTotalFacturado)
            newTrElement.setAttribute("attr-unidadMedidaProductoIdFacturada", dto.unidad_medida_producto)
            newTrElement.setAttribute("class", "new-sobrante-product")
            setDataInTableTd(newTrElement, dto)
            productTableElement.appendChild(newTrElement)
        }
    }
    //formatPageDataFromTags("attr-money-format");
}


function loadSelectUnidadDeMedidaEnSobrante(productId){
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    var sb = new StringBuilder();
    sb.append("SELECT ump.id, um.id as unidad_medida_id, um.unidad_medida, ump.cantidad as cantidad FROM gc_unidad_medida_productos ump ");
    sb.append("JOIN gc_unidad_medidas um ON um.id = ump.gc_unidad_medidas_id ");
    sb.append("WHERE ump.gc_productos_id = "+productId+" ");
    sb.append("order by um.unidad_medida asc ");
    passData.query = sb.toString();
    var list = getDataFromQueryAjax(urlStr, passData)
    var selectElement = getById("unidadDeMedidaSelect-"+productId);
    jQuery(selectElement).children().remove();
    for(var x = 0; x < list.length; x++){
        var dto = list[x];
        var unidadMedidaProductoId = dto.id;
        var unidadMedida = dto.unidad_medida;
        var cantidad = dto.cantidad;
        var unidadMedidaId = dto.unidad_medida_id
        var optionElement = document.createElement("option");
        optionElement.appendChild(document.createTextNode(unidadMedida));
        optionElement.value = unidadMedidaProductoId;
        optionElement.setAttribute("cantidad", cantidad);
        //document.getElementById("orange").selected = true;
        if(unidadMedida.toUpperCase() == 'BOT' || unidadMedida.toUpperCase() == 'TET' ||
            unidadMedida.toUpperCase() == 'LAT' || unidadMedida.toUpperCase() == 'UND'){
            optionElement.selected = true;
        }
        selectElement.append(optionElement);
    }
}





var currentStepNumberVal = 1;
function nextSobranteBtnClicked(btnElement, nextStep){
    var currentStepNumber = currentStepNumberVal;
    var currentBodyStep = getById("bodyStep"+currentStepNumber+"Id");
    var parentElementId = "bodyStep"+currentStepNumber+"Id";
    var requiredFieldsOkFlag = true;
    if(nextStep == true){
        requiredFieldsOkFlag = validateRequiredFields(parentElementId);
    }

    if(requiredFieldsOkFlag){
        currentBodyStep.style.display = "none";
        var stepMap = getNextOrPrevousStep(currentStepNumber)
        var newStepNumber
        if(nextStep){
            newStepNumber = stepMap.get("nextStep");
            getById("previousBtnId").style.display = ""
        }else{
            newStepNumber = stepMap.get("previousStep");
            if(newStepNumber == 1){
                btnElement.style.display = "none" //Se oculta el boton de atras cuando estamos en la primera parte
            }
        }
        var newBodyStep = getById("bodyStep"+newStepNumber+"Id");
        newBodyStep.style.display = "";
        var newStepMap =  getNextOrPrevousStep(newStepNumber)
        var title = newStepMap.get("title");
        jQuery("#stepsTitleId").html(title);

        stepLine(newStepNumber);
        btnElement.setAttribute("current-step", newStepNumber)
        currentStepNumberVal = newStepNumber;
    }

}
function getNextOrPrevousStep(currentStep){
    var nextStep = 1;
    var previousStep = 1;
    var title = "Identificacion y Producto"
    switch(currentStep) {
        case 1:
            nextStep = 2;
            previousStep = 1;
            title = "Identificacion y Producto"
            break;
        case 2:
            nextStep = 3
            previousStep = 1;
            title = "Observacion"
            break;
        default:
            alert("default nextStep")
    }
    var returnMap = new Map();
    returnMap.set("nextStep", nextStep)
    returnMap.set("previousStep", previousStep);
    returnMap.set("title", title);
    return returnMap;
}

function stepLine(currentStep){
    var disabledList;
    var stepElement = getById("step"+currentStep+"Id");
    stepElement.removeAttribute("disabled");
    stepElement.classList.remove("btn-default");
    stepElement.classList.add("btn-success");
    switch(currentStep) {
        case 1:
            getById("nextBtnId").style.display = ""
            getById("saveBtnId").style.display = "none"
            getById("updateBtnId").style.display = "none"
            disabledList = ["step2Id"];
            break;
        case 2:
            getById("nextBtnId").style.display = "none"
            if(currentSobrantePageName()=='create'){
                getById("saveBtnId").style.display = ""
            }else if (currentSobrantePageName() == 'edit'){
                getById("updateBtnId").style.display = ""
            }
            break;
        default:
            alert("default nextStep")
    }
    if(disabledList != null && disabledList != undefined){
        for(var i = 0; i < disabledList.length; i++){
            var disabledId = disabledList[i];
            var element = getById(disabledId);
            if(element != null && element != undefined){
                element.setAttribute("disabled", "disabled");
                element.classList.remove("btn-success");
                element.classList.add("btn-default");
            }
        }
    }
}


function removeTrFromTrId(elementId, id){
    var productTrElement = document.getElementById(elementId);
    jQuery(productTrElement).remove();
    if(id != null && id != undefined){
        //jQuery('#productMultiSelect2Id').val(id).trigger("change");
        jQuery("#productMultiSelect2Id option[value='"+id+"']").remove();
    }
    if(productTrElement.classList.contains('existing-product')){
        sobranteDetalleToDeleteList.push(productTrElement.getAttribute("attr-sobrante-detalle-id"))
    }
}



function getSobrantesDetailsPassDataInsert(){
    var sb = new StringBuilder();
    sb.append("INSERT INTO sobrante_detalle(id, version, sobrante_id, gc_producto_id, ");
    sb.append("cantidad_documentada, gc_unidad_medida_producto_id) ");
    sb.append("VALUES (nextval('sobrante_detalle_seq'), 0, ?, ?, ?, ?); ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosSobranteDetalleInsert();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}


function getDatosSobranteDetalleInsert(){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let trProductosAgregados = document.getElementsByClassName("new-sobrante-product");
    let detallesList = [];
    for(let i = 0; i < trProductosAgregados.length; i++){
        var trProductElement = trProductosAgregados[i]
        let productId = trProductElement.getAttribute("attr-product-id")
        var options = getById("unidadDeMedidaSelect-"+productId).options;
        var unidadDeMedidaText     = options[options.selectedIndex].text;
        var cantidadRetornada = parseInt(getById("cantidad-"+productId).value);
        var unidadMedidaProductoIdFacturada = trProductElement.getAttribute("attr-unidadMedidaProductoIdFacturada");
        if( unidadDeMedidaText.toUpperCase() == 'CAJ' ||
            unidadDeMedidaText.toUpperCase() == 'PACK' || unidadDeMedidaText.toUpperCase() == 'PAC'){
            cantidadRetornada = cantidadRetornada*options[options.selectedIndex].attributes[1].value
        }
        let columnsMap = new Map();
        columnsMap.set(1, ['parentId',                      DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(2, [productId,                       DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(3, [cantidadRetornada,               DATABASE.DATA_TYPE.INTEGER])
        columnsMap.set(4, [unidadMedidaProductoIdFacturada, DATABASE.DATA_TYPE.VARCHAR])
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        detallesList.push(obj);
    }
    return detallesList;
}

function getSobrantePassDataInsert(){
    var sb = new StringBuilder();
    sb.append("INSERT INTO sobrante(id, version, sobrante_estados_id, gc_fletero_id, retorno_id, fecha_sobrante, ");
    sb.append("observacion, user_creation_id, ");
    sb.append("user_creation_date, od_freight_order_id) ");
    sb.append("VALUES (nextval('sobrante_seq'), 0, ?, ?, null, current_timestamp, ?, ?, current_timestamp, ?) ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosSobranteInsert();
    passData.argsToSet = JSON.stringify(argsToSet);
    return passData;
}

function getDatosSobranteInsert(){
    var orderDeTransporteId = jQuery("#ordenTransporteSelectId").val();
    var gcFleteroId = getById("fleteroSeleccionadoId").value;
    var sobranteEstadoPendienteId = getOneValueFromTableAndCode("id", "sobrante_estados",
        SOBRANTE.ESTADO.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.CODIGO);
    var userCreationId = getLoggedUserId();
    var observacion = getById("observacionId").value;

    var columnsMap = new Map();
    columnsMap.set(1, [sobranteEstadoPendienteId , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(2, [gcFleteroId      , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(3, [observacion , DATABASE.DATA_TYPE.VARCHAR]);
    columnsMap.set(4, [userCreationId , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(5, [orderDeTransporteId, DATABASE.DATA_TYPE.BIGINT]);

    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;

}




async function loadSobrantesData(){
    setOptToSelect2(jQuery("#ordenTransporteSelectId"), getFreightOrderData(), getFreightOrderId());
    var productsElementsList = document.getElementsByClassName("productsSelectedHiddenClass")
    var productsSelect2 = jQuery("#productMultiSelect2Id")
    for(let x = 0; x < productsElementsList.length; x++){
        let productHiddenElement = productsElementsList[x];
        let productId = productHiddenElement.value;
        let productDescription = productHiddenElement.getAttribute("attr-product-descr")
        let opt = new Option(productDescription, productId, true, true);
        productsSelect2.append(opt).trigger('change');
        let unidadDeMedidaIdFacturada = productHiddenElement.getAttribute("attr-product-unidadMedidaRet");
        await loadSelectUnidadDeMedidaEnSobrante(productId)

    }
    if(getById("observacionId") != null && getById("observacionId") != undefined){
        getById("observacionId").value = getObservacion();
    }
}

async function actualizacionDeSobranteEstado(value, sobranteId){
    showSpinner();
    try {
        var passData = new Object();
        passData.checkedList = sobranteId;
        var newStatus = "";
        if(value == ACCION_APROBAR){
            if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
                newStatus = SOBRANTE.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO;
            }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
                newStatus = SOBRANTE.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO;
            }
        }else if(value == ACCION_RECHAZAR){
            if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
                newStatus = null;
            }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
                newStatus = RETORNO.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO;
            }
        }
        passData.nuevoEstadoSobrante = newStatus;
        var returnActualizacionDeEstado = await postDataFromQueryAjax(updateSobranteEstadoUrl(), passData, reloadThisPage);
        if(returnActualizacionDeEstado != ERROR.AJAX_RETURN){
            var obs = "";
            if(getById("motivoRechazoDeposito") != null){
                obs = getById("motivoRechazoDeposito").value;
            }else if(getById("motivoNoRegistroRegistroId") != null){
                obs = getById("motivoNoRegistroRegistroId").value;
            }
            let obj = new Object();
            obj.estado = passData.nuevoEstadoSobrante;
            obj.observacion = obs;
            await saveInAuditoriaSobrante(sobranteId, JSON.stringify(obj), passData.nuevoEstadoSobrante, "U", obs);
        }
    }catch (error){
        hideSpinner();
        alert("Error accionAprobar: "+error)
    }
}

function saveInAuditoriaSobrante(id, estadoJson, estado, action, observation){
    var data = new Object();
    data.action = action;
    data.dominioId = id;
    data.observacion = observation;
    data.dominio = "Sobrante"
    data.userId = getLoggedUserId();
    data.estado = estado;
    data.datos = estadoJson;
    insertarAuditoria(data);
}



function getSobranteDetailsAuxDepositoPassDataUpdate(){
    var sb = new StringBuilder();
    sb.append("UPDATE sobrante_detalle SET cantidad_verificada_deposito=? ");
    sb.append("WHERE id = ? ");

    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosSobranteDetalleAuxDepositoUpdate();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosSobranteDetalleAuxDepositoUpdate(){
    let trProductosAgregados = document.getElementsByClassName("existing-product");
    let detallesList = [];
    for(let i = 0; i < trProductosAgregados.length; i++){
        var trProductElement = trProductosAgregados[i]
        var retornoDetalleId = trProductElement.getAttribute("attr-sobrante-detalle-id");
        let productId = trProductElement.getAttribute("attr-product-id")

        var cantidadDocumentada = parseInt(getById("cantidad-"+productId).value);
        //var options = getById("unidadDeMedidaSelect-"+productId).options;
        /*var unidadDeMedidaText     = options[options.selectedIndex].text;
        if( unidadDeMedidaText.toUpperCase() == 'CAJ' ||
            unidadDeMedidaText.toUpperCase() == 'PACK'){
            cantidadDocumentada = cantidadDocumentada*options[options.selectedIndex].attributes[1].value
        }*/

        let columnsMap = new Map();
        columnsMap.set(1, [cantidadDocumentada,      DATABASE.DATA_TYPE.INTEGER]);
        columnsMap.set(2, [retornoDetalleId,            DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        detallesList.push(obj);
    }
    return detallesList;
}



var dataTable = null;
async function showSobranteAudit(retornoId){
    if(dataTable != null){
        dt2.clear();
        dt2.destroy()
        //dataTable.fnDraw(false);
    }
    var cardElement = getById("cardBodyId")
    jQuery(cardElement).children().remove();

    var devolucionesTableElement = getById("auditoriaTableId");
    var newDevolucionesTableElement = devolucionesTableElement.cloneNode(true);
    newDevolucionesTableElement.setAttribute("id", "");
    newDevolucionesTableElement.style.display = "";

    cardElement.appendChild(newDevolucionesTableElement);
    var newTableElement = cardElement.getElementsByTagName("table")[0]
    newTableElement.setAttribute("id", "auditoriaTableId");
    var newTbodyElement = newTableElement.getElementsByTagName("tbody")[0];
    newTbodyElement.setAttribute("id", "auditoriaTbodyId");
    var newOriginalTrElement = newTbodyElement.getElementsByTagName("tr")[0];
    newOriginalTrElement.setAttribute("id", "auditoriaTableTrId");


    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select aj.*, u.username, r.authority from audit_json aj ");
    sb.append("join users u on u.id = aj.user_id ")
    sb.append("join users_roles ur on ur.users_id = u.id ");
    sb.append("join roles r on ur.roles_id = r.id ");
    sb.append("WHERE aj.table_id = '"+retornoId+"' AND table_name = 'sobrante'  order by aj.date desc");

    passData.query = sb.toString();
    devolucionesDtoList = await getDataFromQueryAjax(urlStr, passData)
    var tbodyElement = getById("auditoriaTbodyId");
    var originalTrElement = getById("auditoriaTableTrId");
    var formatter= 'DD-MM-YYYY HH:mm';
    for(var x = 0; x < devolucionesDtoList.length; x++){
        var dto = devolucionesDtoList[x];
        dto.date = formatterDate(dto.date, "DD-MM-YYYY HH:mm:ss");
        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.id = "";
        newTrElement.style.display = "";
        newTrElement.setAttribute("class", "auditoriaTrGeneradoClass");
        setDataInTableTd(newTrElement, dto)
        tbodyElement.appendChild(newTrElement)
        getById("auditoriaTableTrId").style.display = 'none'
    }
    dt2 = jQuery("#auditoriaTableId").DataTable({
        "order": [],
        "columnDefs": [ {
            "targets"  : 'no-sort',
            "orderable": false,
        }]
    });
    jQuery("#showDevolucionAuditId").modal();
}



function loadOrdenDeTransporteSobrante(){
    var url = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select fo.id as id, fo.license_plate, fo.name, ");
    sb.append("concat(fo.license_plate,'-',fo.name,'-',f.fletero) as result, ");
    sb.append("f.id as fletero_id, r.id as retorno_id ");
    sb.append("from od_freight_order fo ");
    sb.append("join gc_fletero f on f.fletero = fo.driver_name ");
    sb.append("left join retorno r on r.od_freight_order_id = fo.id ");
    sb.append("WHERE 1=1 ");
    sb.append("and r.id is null ");
    passData.query = sb.toString();
    var ordenDeTransporteSelect2Element = jQuery('#ordenTransporteSelectId');
    setSelect2WhitLimit(ordenDeTransporteSelect2Element, sb.toString(), setOrdenTransporteSobranteData,
        getOrdenDeTransporteSobranteFilterQuery, url)

    ordenDeTransporteSelect2Element.on("select2:select", async function (e) {
        jQuery('#facturaNroSelect2Id').val(null).trigger('change');
        var fleteroId = e.params.data.queryData.fletero_id;
        getById("fleteroSeleccionadoId").value = fleteroId
    });

}


function setOrdenTransporteSobranteData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getOrdenDeTransporteSobranteFilterQuery(query, filter){
    if(filter != undefined && filter != null && filter.trim() != ''){
        query = query+" AND concat(fo.license_plate,'-',fo.name,'-',f.fletero) ilike ? "
    }
    return query;
}