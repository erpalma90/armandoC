function printDocumentActivosEntrada(retornoId, fletero){
    var d = moment().format('DD MM YYYY HH:mm');
    document.title="ACTIVOS_ENTRADA_"+retornoId+"_"+fletero+"_"+d;
    window.print();
    return false;
}

function verificacionActivosEntrada(){
    jQuery("#verificacion-modal-id").modal();
}



async function actualizarVerificacionActivosEntradaDetalles(){
    var requiredFieldsOkFlag = validateRequiredFields("verificacion-modal-id");
    if(requiredFieldsOkFlag){
        showSpinner();
        var elementosCantidadVerificada = document.getElementsByClassName("cantidadVerificadaClass");
        var sb = new StringBuilder();
        var existChangeFlag = false;
        if(elementosCantidadVerificada != undefined && elementosCantidadVerificada != null){
            for(var x = 0; x < elementosCantidadVerificada.length; x++){
                var elemento = elementosCantidadVerificada[x];
                var cantidadVerificadaNueva = elemento.value
                var cantidadDocumentada = elemento.getAttribute("attr-cant-documentada");
                var activosEntradaDetalleId = elemento.getAttribute("attr-activosEntradaDetalleId");
                var cantidadVerificadaActual = elemento.getAttribute("attr-cantidadVerificadaActual");
                if(cantidadVerificadaNueva.toString().trim() == "" || cantidadVerificadaNueva.toString().trim().indexOf(".") != -1 || cantidadVerificadaNueva.toString().trim().indexOf(",") != -1){
                    cantidadVerificadaNueva = cantidadDocumentada;
                }else if(cantidadVerificadaNueva.toString() != cantidadVerificadaActual.toString()){
                    await updateVerificacionActivosEntradaDetalle(activosEntradaDetalleId, cantidadVerificadaNueva, "cantidad_verificada_registro", existChangeFlag);
                    existChangeFlag = true;
                }
            }
        }
        if(!existChangeFlag){
            jQuery('#observacion-modal-id').modal('toggle');
            hideSpinner();
        }
    }

}


function updateVerificacionActivosEntradaDetalle(activosEntradaDetalleId, cantidad, columnToUpdate, existChangeFlag){
    var passData = new Object();
    var passDataList = []
    if(!existChangeFlag){
        passDataList.push(getActivosEntradaUpdateLastUserModified());
    }
    passDataList.push(getActivosDetallesDetailVerificacionUpdateData(activosEntradaDetalleId, cantidad, columnToUpdate));
    passData.parentId = getActivosEntradaId();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                var urlStr = window.location;
                window.location = urlStr;
                //location.href = getDevolucionesShowUrl()+"/"+data;
            }else{
                alert('No se pudo guardar la entrada de activo: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo guardar la entrada del activo');
        }
    });
}

function getActivosEntradaUpdateLastUserModified(){
    var sb = new StringBuilder();
    sb.append("UPDATE activos_entrada SET user_last_updated_id = ?, user_last_updated_date = current_timestamp ");
    sb.append("WHERE id = ? ")
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosActivosEntradaActualizacion();
    passData.argsToSet = argsToSet;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        passData = null;
    }
    return JSON.stringify(passData);
}

function getDatosActivosEntradaActualizacion(){
    let detallesList = [];
    let columnsMap = new Map();
    var activosEntradaId = getActivosEntradaId();

    columnsMap.set(1, [getLoggedUserId(),       DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(2, [activosEntradaId,        DATABASE.DATA_TYPE.BIGINT])

    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    detallesList.push(obj);

    return detallesList;

}

function getActivosDetallesDetailVerificacionUpdateData(activosEntradaDetalleId, cantidad, columnToUpdate){
    var sb = new StringBuilder();
    sb.append("UPDATE activos_entrada_detalle SET "+columnToUpdate+" = ? WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosActualizarVerificacionActivosEntrada(activosEntradaDetalleId, cantidad);
    passData.argsToSet = argsToSet;
    return JSON.stringify(passData);
}

function getDatosActualizarVerificacionActivosEntrada(detalleId, cantidad){
    var list = [];
    var columnsMap = new Map();
    columnsMap.set(1, [cantidad, DATABASE.DATA_TYPE.INTEGER])
    columnsMap.set(2, [detalleId, DATABASE.DATA_TYPE.BIGINT])
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    list.push(obj)
    return list;
}

function areYouShureActivosEntradaAprovvedModalInShow(activosEntradaId, action){
    if(action == ACCION_APROBAR){
        if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
            acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la aprobacion de la entrada de activos?" ,'warning' ,
                "Si, aprobar", async function () {return actualizacionActivosEntradaEstado(ACCION_APROBAR, activosEntradaId)});
        }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
            acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la aprobacion de la entrada de activos?" ,'warning' ,
                "Si, aprobar", async function () {return validateCantidadesVerificadasActivosEntrada()});
        }
    }else if(action == ACCION_RECHAZAR){
        acceptOrCancellModal("Estas seguro? ", "Estas seguro de rechazar la entrada de activos?" ,'warning' ,
            "Si, rechazar", async function () {return actualizacionActivosEntradaEstado(ACCION_RECHAZAR, activosEntradaId)});
    }

}


function saveInAuditoria(id, estadoRetornoJson, estado, action, observation){
    var data = new Object();
    data.action = action;
    data.dominioId = id;
    data.observacion = observation;
    data.dominio = "Activos_Entrada"
    data.userId = getLoggedUserId();
    data.estado = estado;
    data.datos = estadoRetornoJson;
    insertarAuditoria(data);
}


function verificacionActivosEntradaDeposito(){
    var cantidadesModal = document.getElementsByClassName("cantidadVerificadaDepositoClass");
    for(var x = 0; x < cantidadesModal.length; x++){
        var element = cantidadesModal[x]
        console.log("Cantidad verificada registro: "+element.getAttribute("attr-cantidadVerificada"))
    }
    jQuery("#verificacionDeposito-modal-id").modal();
}


function actualizarCantidadVerificadaActivosEntradaDeposito(){
    showSpinner();
    var cantVerificadaDepositoList = document.getElementsByClassName("cantidadVerificadaDepositoClass");
    var existChangeFlag = false;
    if(cantVerificadaDepositoList != undefined && cantVerificadaDepositoList != null){
        for(var x = 0; x < cantVerificadaDepositoList.length; x++){
            var elemento = cantVerificadaDepositoList[x];
            var cantidadNuevo = elemento.value
            var cantidadVerificadaDepositoActual = elemento.getAttribute("attr-cantidadVerificadaDeposito");
            var activosEntradaDetalleId = elemento.getAttribute("attr-activosEntradaDetalleId");
            if(cantidadNuevo != null && cantidadNuevo != "" && parseInt(cantidadNuevo) >= 0){
                if(cantidadNuevo.toString() != cantidadVerificadaDepositoActual.toString()){
                    updateVerificacionActivosEntradaDetalle(activosEntradaDetalleId, cantidadNuevo, "cantidad_verificada_deposito", existChangeFlag);
                    existChangeFlag = true;
                }
            }
        }
    }
    if(!existChangeFlag){
        jQuery('#verificacion-deposito-modal-id').modal('toggle');
        hideSpinner();
    }

}


function validateCantidadesVerificadasActivosEntrada(){
    var cantidadesVerificadas = document.getElementsByClassName("cantidadVerificadaDepositoClass");
    var resultMap = new Map();
    if(cantidadesVerificadas != undefined && cantidadesVerificadas != null){
        for(var x = 0; x < cantidadesVerificadas.length; x++){
            var elemento = cantidadesVerificadas[x];
            var cantidadVerificadaRegistro = elemento.getAttribute("attr-cantidadVerificada");
            var cantidadVerificadaDeposito = elemento.getAttribute("attr-cantidadVerificadaDeposito");
            var activosEntradaDetalleId = elemento.getAttribute("attr-activosEntradaDetalleId");
            if(cantidadVerificadaRegistro != cantidadVerificadaDeposito){
                resultMap.set(activosEntradaDetalleId, "Registro: "+cantidadVerificadaRegistro+" - Deposito: "+cantidadVerificadaDeposito);
            }
        }
    }
    if(resultMap.size == 0){
        var activosEntradaId = getActivosEntradaId();
        swalNotification('top-center', "success", "Cantidades Coicidentes con Registro", 7000);
        //updateDevolucionStatusToApproved();
        actualizacionActivosEntradaEstado(ACCION_APROBAR, activosEntradaId)
    }else{
        //alert("Existe diferencia")
        var title = "La cantidad no coincide con la verificacion de Registro, favor volver a realizar el conteo, o aplicar rechazo del movimiento";
        swalNotification('top-center', "warning",
            title, 7000);
    }
}

async function updateLiquidacionStatus(newStatus, observation){
    var urlStr = getUpdateActivosEntradaLiquidacionStatusURL();
    var passData = new Object();
    passData.entityId = getActivosEntradaId();
    passData.liquidacionEstadoCodigo = newStatus;
    if(observation == null || observation == undefined){
        observation = "";
    }
    passData.observacion = observation.trim();
    await ajaxPutData(urlStr, passData, resolveAccionLiquidacion);
}

function resolveAccionLiquidacion(data){
    var resumenComprobanteStockDto = JSON.parse(data);
    if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        //swalNotification('top-center', 'success', 'Realizado', 2000);
        reloadThisPage()
    }else if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_ERROR){
        hideSpinner();
        swalNotification('top-center', 'error', 'NO SE PUEDE EJECUTAR, CONSULTAR CON TI', 2000);
    }else{
        hideSpinner();
        swalNotification('top-center', 'warning', resumenComprobanteStockDto.message, 7000)
    }
}