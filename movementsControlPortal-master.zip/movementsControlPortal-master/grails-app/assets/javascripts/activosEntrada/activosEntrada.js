var dataTable = null;
async function showActivosEntradaAudit(activosEntradaId){
    var activosEntradaDtoList = null;
    if(dataTable != null){
        dt2.clear();
        dt2.destroy()
        //dataTable.fnDraw(false);
    }
    var cardElement = getById("cardBodyId")
    jQuery(cardElement).children().remove();

    var devolucionesTableElement = getById("auditoriaTableId");
    var newDevolucionesTableElement = devolucionesTableElement.cloneNode(true);
    newDevolucionesTableElement.setAttribute("id", "");
    newDevolucionesTableElement.style.display = "";

    cardElement.appendChild(newDevolucionesTableElement);
    var newTableElement = cardElement.getElementsByTagName("table")[0]
    newTableElement.setAttribute("id", "auditoriaTableId");
    var newTbodyElement = newTableElement.getElementsByTagName("tbody")[0];
    newTbodyElement.setAttribute("id", "auditoriaTbodyId");
    var newOriginalTrElement = newTbodyElement.getElementsByTagName("tr")[0];
    newOriginalTrElement.setAttribute("id", "auditoriaTableTrId");


    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select aj.*, u.username, r.authority from audit_json aj ");
    sb.append("join users u on u.id = aj.user_id ")
    sb.append("join users_roles ur on ur.users_id = u.id ");
    sb.append("join roles r on ur.roles_id = r.id ");
    sb.append("WHERE aj.table_id = '"+activosEntradaId+"' AND table_name = 'activos_entrada'  order by aj.date desc");

    passData.query = sb.toString();
    activosEntradaDtoList = await getDataFromQueryAjax(urlStr, passData)
    var tbodyElement = getById("auditoriaTbodyId");
    var originalTrElement = getById("auditoriaTableTrId");
    var formatter= 'DD-MM-YYYY HH:mm';
    for(var x = 0; x < activosEntradaDtoList.length; x++){
        var dto = activosEntradaDtoList[x];
        dto.date = formatterDate(dto.date, "DD-MM-YYYY HH:mm:ss");
        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.id = "";
        newTrElement.style.display = "";
        newTrElement.setAttribute("class", "auditoriaTrGeneradoClass");
        setDataInTableTd(newTrElement, dto)
        tbodyElement.appendChild(newTrElement)
        getById("auditoriaTableTrId").style.display = 'none'
    }
    dt2 = jQuery("#auditoriaTableId").DataTable({
        "order": [],
        "columnDefs": [ {
            "targets"  : 'no-sort',
            "orderable": false,
        }]
    });
    jQuery("#showDevolucionAuditId").modal();
}

async function actualizacionActivosEntradaEstado(value, activosEntradaId){
    showSpinner();
    try {
        var passData = new Object();
        passData.checkedList = activosEntradaId;
        var newStatus = "";
        if(value == ACCION_APROBAR){
            if(CURRENT_ROLE == ROLES.ROLE_ADMIN || CURRENT_ROLE == ROLES.ROLE_REGISTRO){
                newStatus = ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO;
            }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
                newStatus = ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO;
            }
        }else if(value == ACCION_RECHAZAR){
            if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
                newStatus = ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO;
            }
        }

        passData.nuevoEstado = newStatus;

        //var returnActualizacionDeEstado = await postDataFromQueryAjax(updateActivosEntradaEstadoUrl(), passData, null);
        var returnActualizacionDeEstado = ajaxGetData(updateActivosEntradaEstadoUrl(), passData, resolveAprobarActivosSalida);

        if(returnActualizacionDeEstado != ERROR.AJAX_RETURN){
            var obs = "";
            let obj = new Object();
            obj.estado = passData.nuevoEstado;
            obj.observacion = obs;
            await saveInAuditoria(activosEntradaId, JSON.stringify(obj), passData.nuevoEstado, "U", obs);
        }
    }catch (error){
        hideSpinner();
        alert("Error accionAprobar: "+error)
    }
}

function resolveAprobarActivosSalida(data){
    var resumenComprobanteStockDto = JSON.parse(data);
    if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        reloadThisPage()
    }else if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_ERROR){
        hideSpinner();
        swalNotification('top-center', 'error', 'NO SE PUEDE EJECUTAR, CONSULTAR CON TI', 2000);
    }else{
        hideSpinner();
        swalNotification('top-center', 'warning', resumenComprobanteStockDto.message, 7000)
    }
}