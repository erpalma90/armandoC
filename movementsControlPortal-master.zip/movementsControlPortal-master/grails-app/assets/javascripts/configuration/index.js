function initJsPage(){
    dataTableInitialize();
}


async function dataTableInitialize(){
    jQuery.noConflict();
    var table = jQuery('#configurationTableId').DataTable();
}