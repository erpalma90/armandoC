function initJsPage(){
    var searchProductIdList = getById("searchProductIdListHiddenId").value;
    if(searchProductIdList != null && searchProductIdList != ""){
        var urlStr = getGetDataFromQueryInGCURL();
        var passData = {};
        passData.query = getProductosForDepositoGCQuery()+" AND p.[ID Productos] in ("+searchProductIdList+") ";
        var resultList = getDataFromQueryAjax(urlStr, passData);
        for(var i = 0; i < resultList.length; i++){
            var dto = resultList[i];
            setOptToSelect2(jQuery("#productMultiSelect2Id"), dto.result, dto.id);
        }
    }
    //setOptToSelect2(jQuery("#productMultiSelect2Id"), productId+'-'+productName, productId);

    var resumenComprobanteVenta = getResumeComprobanteVenta();
    if(resumenComprobanteVenta == true){
        jQuery("#devolucionDetalleMovimientoResumenId").modal();
    }
    getProductsForDepositosDetalles();
}
function changeDepositosSelect(element){
    var retornosDetallesDepositosId = element.getAttribute("attr-id");
    var trElement = getById("checkId-"+retornosDetallesDepositosId);
    var selectedDepositoId = element.value;
    var actualDepositoId = trElement.getAttribute("attr-depositoActual");
    if(selectedDepositoId != "null"){
        trElement.style.background = "#ff6a0040";
        if(!trElement.classList.contains("detailToUpdate")){
            trElement.classList.add("detailToUpdate");
        }
    }else{
        trElement.style.background = "#f4f6f9";
        if(trElement.classList.contains("detailToUpdate")){
            trElement.classList.remove("detailToUpdate");
        }
    }

}



function updateDevolucionDictamen(devolucionDetalleId, devolucionId){
    var requiredFieldsOkFlag = validateRequiredFields("dictamenTBodyId-"+devolucionDetalleId);
    if(requiredFieldsOkFlag){
        var cantidadVerificada = getById("cantidadVerificadaId-"+devolucionDetalleId).getAttribute("attr-cantidadVerificada");
        var totalDictaminado = getCantidadTotalDictaminadaPorDevolucionDetalle(devolucionDetalleId);
        //parseInt(cantidadVerificada) >= parseInt(total)
        if(parseInt(cantidadVerificada) >= parseInt(totalDictaminado)){
            var passData = new Object();

            var trDictamenClassElements = jQuery(".trDictamenClass-"+devolucionDetalleId+":visible");
            var laboratorioDictamenPorDetalleObjList = [];
            var laboratorioDictamenPorDetObj;
            for(var x = 0; x < trDictamenClassElements.length; x++){
                var currentElement = trDictamenClassElements[x];
                var requiredFieldsOkFlag = validateRequiredFields("dictamenTBodyId-"+devolucionDetalleId);
                var cantidad = currentElement.getElementsByClassName("dictamenCantidad-class")[0].value;
                var dictamen = currentElement.getElementsByClassName("js-example-basic-single")[0].value;
                var laboratorioDestFinal = currentElement.getElementsByClassName("laboratorio-destino-final-select2-class")[0].value;
                var fechaVencimiento = currentElement.getElementsByClassName("fechaClassElement")[0].value;
                laboratorioDictamenPorDetObj = new Object();
                laboratorioDictamenPorDetObj.cantidad = cantidad;
                laboratorioDictamenPorDetObj.laboratorioDictamenId = dictamen;
                laboratorioDictamenPorDetObj.fechaVencimiento = fechaVencimiento;
                laboratorioDictamenPorDetObj.laboratorioDestinoFinalId = laboratorioDestFinal;
                laboratorioDictamenPorDetalleObjList.push(laboratorioDictamenPorDetObj);
                //toastTr('success', 'Actualizado', 'Dictamen actualizado');
            }
            var urlStr = getInsertOrUpdateLaboratorioDictamenListURL();
            passData.devolucionId = devolucionId;
            passData.devolucionDetalleId = devolucionDetalleId;
            passData.laboratorioDictamenPorDetalleObjList = JSON.stringify(laboratorioDictamenPorDetalleObjList);
            if(laboratorioDictamenPorDetalleObjList != null){
                jQuery.ajax({
                    url: urlStr,
                    type: 'GET',
                    async:true,
                    //dataType: 'json',
                    data: passData,
                    success: function(data) {
                        jQuery("#dictamenTdId-"+devolucionDetalleId).html(data);
                        toastTr('success', 'Dictaminado Exitosamente', 'Se aplico el dictamen');
                    },
                    error: function (dataError) {
                        swalNotification('top-center', 'error', dataError.responseText, 2000);
                        console.log(dataError.responseText);
                        dataToReturn = ERROR.AJAX_RETURN;
                    }
                });
            }
        }else{
            toastTr('warning', 'No se puede Guardar', 'La cantidad dictaminada no puede superar la cantidad a dictaminar');
        }
    }else{
        laboratorioDictamenPorDetalleObjList = null;
    }



}


function changeUnidMedSelectRetornosDetallesDepositos(element){
    //var productId = element.getAttribute("attr-id");
    var depositoDetalleId = element.getAttribute("attr-id");
    var trElement = getById("checkId-"+depositoDetalleId)
    var cantidadExistenteDeposito = trElement.getAttribute("attr-cantidadActual");
    var cantidadElement = getById("cantidadId-"+depositoDetalleId);
    var options = element.options;
    var unidadDeMedidaId      = options[options.selectedIndex].value;
    var unidadDeMedidaCantidad = options[options.selectedIndex].getAttribute("cantidad");
    cantidadElement.value = Math.round(parseInt(cantidadElement.value)/parseInt(unidadDeMedidaCantidad));

    maxProductQuantityValidityInDeposito(cantidadElement);
}

function maxProductQuantityValidityInDeposito(element){
    var depositoDetalleId = element.getAttribute("attr-id");
    var trElement = getById("checkId-"+depositoDetalleId)
    var cantidadExistenteDeposito = trElement.getAttribute("attr-cantidadActual");
    //var cantidadEnvaseMinFacturada = trElement.getAttribute("attr-cantidadEnvaseFacturada");
    var currentValue = element.value;
    var cantUnidMedSelectedElement = getById("unidadDeMedidaSelectId-"+depositoDetalleId);
    var cantUnidMedSelectedValue = cantUnidMedSelectedElement[cantUnidMedSelectedElement.selectedIndex].getAttribute("cantidad");
    var cantidadTotal = parseInt(currentValue)*parseInt(cantUnidMedSelectedValue);
    if(cantidadTotal > parseInt(cantidadExistenteDeposito)){
        element.value = "";
        element.setAttribute("attr-finalValue", "");
        toastTr('warning', 'Alerta', "La cantidad retornada, no puede superar a la cantidad facturada");
    }else{
        element.setAttribute("attr-finalValue", cantidadTotal);
        var cantidadResumeElement = getById("cantidadResumeId-"+depositoDetalleId);
        jQuery(cantidadResumeElement).html(cantidadTotal);
        if(cantidadTotal == parseInt(cantidadExistenteDeposito)){
            if(cantidadResumeElement.classList.contains("text-warning")){
                cantidadResumeElement.classList.remove("text-warning")
                cantidadResumeElement.classList.add("text-success")
            }
        }else{
            if(cantidadResumeElement.classList.contains("text-success")){
                cantidadResumeElement.classList.remove("text-success")
                //cantidadResumeElement.classList.add("text-warning")
            }
        }
    }
}


function estaSeguroDeCrearComprobanteDeStock(nombreDepositoEmisor, transferenciaFilial){
    var title = "Estas seguro? ";
    var text = "";
    if(transferenciaFilial){
        text = "Estas seguro de ejecutar la Transferencia a Matriz de los productos seleccionados?";
    }else{
        text = "Estas seguro de ejecutar el movimiento de productos seleccionados?";
    }
    var icon = 'warning'
    var confirmButtonText = "Si, ejecutar";
    acceptOrCancellModal(title, text ,icon , confirmButtonText,
        function(){createComprobantesDeStock(nombreDepositoEmisor, transferenciaFilial)})
}


function createComprobantesDeStock(nombreDepositoEmisor, transferenciaFilial){
    showSpinner();
    requiredFieldsOkFlag = validateRequiredFields("depositoTableId .inputQuantityTdClass");
    if(requiredFieldsOkFlag){
        var depositoToId = null;
        if(!transferenciaFilial){
            depositoToId = getById("depositoToId").value
        }
        if((depositoToId != null && depositoToId != undefined && depositoToId != 'null') || transferenciaFilial){
            var requiredFieldsOkFlag;
            if(nombreDepositoEmisor == DEPOSITOS.REEMP.NOMBRE){
                requiredFieldsOkFlag = validateRequiredFields("depositoTableId .itemsCheckClass:checkbox:checked");
            }else{
                requiredFieldsOkFlag = validateRequiredFields("depositoTableId input[name=productRadio]:checked");
            }
            if(requiredFieldsOkFlag){
                var elementsToUpdateList;
                if(nombreDepositoEmisor == DEPOSITOS.REEMP.NOMBRE){
                    elementsToUpdateList = jQuery('input[name=productRadio]:checked')
                }else{
                    elementsToUpdateList = jQuery('.itemsCheckClass:checkbox:checked')
                }
                if(elementsToUpdateList.length > 0){
                    var detailDataObj;
                    var objList = [];
                    var dataObject = new Object();
                    dataObject.depositoEmisorId = getDepositoId();

                    dataObject.depositoReceptorId = depositoToId;
                    if(!transferenciaFilial){
                        dataObject.comprobanteStock = 3;
                    }else{
                        dataObject.comprobanteStock = 2;
                    }
                    var passData = new Object();
                    for(var x = 0; x < elementsToUpdateList.length; x++){
                        var currentElement = elementsToUpdateList[x];
                        var id = currentElement.getAttribute("attr-id");
                        detailDataObj = new Object();
                        detailDataObj.id = currentElement.getAttribute("attr-id");
                        detailDataObj.retornoDetalleId = currentElement.getAttribute("attr-retornoDetalleId");
                        //detailDataObj.depositoId = getDepositoId();
                        detailDataObj.isCurrent = currentElement.getAttribute("attr-isCurrent");
                        detailDataObj.cantidad = getById("cantidadId-"+id).getAttribute("attr-finalValue");
                        detailDataObj.unidadDeMedida = getById("unidadDeMedidaSelectId-"+id).value;
                        detailDataObj.productId = currentElement.getAttribute("attr-productId");
                        //detailDataObj.newDepositoId = getById("depositosSelectId-"+id).value;
                        objList.push(detailDataObj);
                    }
                    var urlStr = getCreateComprobantesDeStockURL();
                    passData.dataObject = JSON.stringify(dataObject);
                    passData.retornosDetallesDepositosObjList = JSON.stringify(objList);
                    passData.transferenciaFilial = transferenciaFilial;
                    if(objList != null){
                        jQuery.ajax({
                            url: urlStr,
                            type: 'GET',
                            async:true,
                            //dataType: 'json',
                            data: passData,
                            success: function(data) {
                                var resumenComprobanteStockDto = JSON.parse(data);
                                if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
                                    //swalNotification('top-center', 'success', 'MOVIMIENTO APROBADO', 2000);
                                    refreshThisPage();
                                }else if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_ERROR){
                                    swalNotification('top-center', 'error', 'NO SE PUEDE EJECUTAR, CONSULTAR CON TI', 2000);
                                }else{
                                    hideSpinner();
                                    swalNotification('top-center', 'warning', data.msgRtrn, 2000)
                                }
                            },
                            error: function (dataError) {
                                swalNotification('top-center', 'error', dataError.responseText, 2000);
                                console.log(dataError.responseText);
                                dataToReturn = ERROR.AJAX_RETURN;
                            }
                        });
                    }
                }else{
                    hideSpinner();
                    swalNotification('top-center', 'warning', 'No se encontro producto seleccionado', 2000);
                }
            }
        }else{
            hideSpinner();
            swalNotification('top-center', 'warning', 'No se seleccionó un depósito', 2000);
        }
    }else{
        hideSpinner();
    }

}

function clickInCheck(element){
    var productId = element.getAttribute("attr-id");
    var trElement = getById("trId-"+productId);
    if(element.checked){
        if(trElement.classList.contains("trSelected") == false){
            trElement.classList.add("trSelected");
        }
    }else{
        if(trElement.classList.contains("trSelected")){
            trElement.classList.remove("trSelected");
        }
    }
}

function clickInRadio(element){
    jQuery(".trSelected").removeClass("trSelected");
    var productId = element.getAttribute("attr-id");
    var trElement = getById("trId-"+productId);
    if(element.checked){
        if(trElement.classList.contains("trSelected") == false){
            trElement.classList.add("trSelected");
        }
    }else{
        if(trElement.classList.contains("trSelected")){
            trElement.classList.remove("trSelected");
        }
    }
}

function checkAllProducts(element){
    var checkedElements = document.getElementsByClassName("itemsCheckClass")
    for(var i = 0; i < checkedElements.length; i++){
        var checksElement = checkedElements[i];
        if(element.checked == true){
            jQuery(checksElement).prop("checked", true)
        }else{
            jQuery(checksElement).prop("checked", false)
        }
        clickInCheck(checksElement)
    }

}

function getProductsForDepositosDetalles(){
    var url = getGetDataFromQueryAndPsInGCURL();
    var query = getProductosForDepositoGCQuery();
    var select2Element = jQuery('#productMultiSelect2Id');
    setSelect2WhitLimit(select2Element, query, setProductForDepositoData, getProductForDepositoFilterQuery, url)
    select2Element.on("select2:select", async function (e) {
        var id = e.params.data.id;
        //await addProductsSelectedInEmpaqueTable(id);
    });
    select2Element.on("select2:unselect", function (e) {
        var id = e.params.data.id;
        //removeTrFromTrId("product-tr-id-"+id)
    });
}

function getProductosForDepositoGCQuery() {
    var sb = new StringBuilder();
    sb.append("SELECT p.[ID Productos] as id,  ");
    sb.append("cast(p.[ID Productos] as varchar)+CASE WHEN p.[Codigo Barra] is not null THEN '-'+p.[Codigo Barra] ELSE '' ");
    sb.append("END+'-'+p.Descripcion as result ")
    sb.append("FROM STK_Productos p WHERE 1=1 ");
    // WHERE p.[clasificacion 9] != 'Promo' AND [Clasificacion 7] = 'SI'
    return sb.toString();
}

function setProductForDepositoData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}


function getProductForDepositoFilterQuery(query, filter){
    var queryFilter = new StringBuilder();
    queryFilter.append(query.toString()+" ");

    var selectedProducts = jQuery('#productMultiSelect2Id').val().toString()
    if(selectedProducts != undefined && selectedProducts != null && selectedProducts.trim() != ''){
        queryFilter.append(" AND CAST(p.[ID Productos] as varchar) NOT IN ("+selectedProducts+") ");
    }


    if(filter != undefined && filter != null && filter.trim() != ''){
        //" AND cast(p.id as varchar)+CASE WHEN p.codigo_barra is not null THEN '-'+p.codigo_barra END, p.producto like ? "
        queryFilter.append("AND cast(p.[ID Productos] as varchar)+");
        queryFilter.append("CASE WHEN p.[Codigo Barra] is not null THEN '-'+p.[Codigo Barra] ELSE '' END +'-'+p.Descripcion like ? ");
        //query = query+" AND cast(f.[Numero Camion] as varchar)+'-'+cast(f.nombre as varchar) like ? "
    }
    return queryFilter.toString()+" ORDER BY p.[ID Productos] ASC";
}

function goToDeposito(depositoId, list){
    //searchProductIdList
    alert(list)
    var appendParams;
    goToUrl(window.location, getDepositoDetalleFromDepositoIdURL()+"/"+depositoId, true);
}