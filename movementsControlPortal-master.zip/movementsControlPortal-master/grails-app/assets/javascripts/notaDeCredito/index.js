function initJsPage(){
    dataTableInitialize();
}

async function dataTableInitialize(){
    $.noConflict();
    var table = $('#ncTableId').DataTable();

    // Add event listener for opening and closing details
    jQuery('#ncTableId tbody').on('click', 'td.details-control', async function () {
        //recuperamos el id de la devolucion
        // Get the rows id value
        var id = table.row(this).id();
        id = id.replace(/\D/g, '');
        id = parseInt(id, 10);

        var tr = jQuery(this).closest('tr');
        var row = table.row(tr);
        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        }else {
            var urlStr = getGetDataFromQueryURL();
            var passData = {};
            var sb = new StringBuilder();
            sb.append("SELECT ncd.id, ncd.version, ncd.cantidad, ncd.precio_unitario, ncd.producto_id, ncd.precio_total, ");
            sb.append("ncd.solicitud_nota_de_credito_id, p.codigo_barra, p.producto ");
            sb.append("FROM solicitud_nota_de_credito_detalle ncd ");
            sb.append("JOIN gc_productos p ON p.id = ncd.producto_id ")
            sb.append("WHERE ncd.solicitud_nota_de_credito_id = ")
            sb.append(id)
            //passData.query = "SELECT p.id, p.codigo_barra, p.producto, dd.cantidad FROM devolucion_detalle dd JOIN gc_productos p ON p.id = dd.producto_id WHERE devolucion_id = "+id+")"
            passData.query = sb.toString();
            var dtoList = await getDataFromQueryAjax(urlStr, passData)
            row.child(format(dtoList)).show();
            tr.addClass('shown');
        }
    });
}

function hideOrShowDetails(trId){
    var trElement = document.getElementById(trId);
    if(trElement.style.display == 'none'){
        trElement.style.display = ''
    }else{
        trElement.style.display = 'none'
    }
}

/* Formatting function for row details - modify as you need */
function format(dataDtoList) {
    var filaSb = new StringBuilder();
    if (dataDtoList != '') {
        var counter = 1;
        for (var dataDto in dataDtoList) {
            var data = dataDtoList[dataDto]

            filaSb.append("<tr>")
            filaSb.append("     <td>"+counter+"</td>");
            filaSb.append("     <td>"+data.producto_id+' - '+data.codigo_barra+' - '+data.producto+"</td>");
            filaSb.append("     <td>"+formatter.format(data.precio_unitario)+"</td>");
            filaSb.append("     <td>"+data.cantidad+"</td>");
            filaSb.append("     <td>"+formatter.format(data.precio_total)+"</td>");
            filaSb.append("</tr>");
            ++counter;
        }
        return '<table style="width:100%" id="example" class="display">' +
            '<thead>' +
            '<tr>' +
                '<th>Nro.Item</th>' +
                '<th>Producto</th>' +
                '<th>Precio Unit</th>' +
                '<th>Cantidad</th>' +
                '<th>PrecioCant</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>' +
            filaSb.toString() +
            '</tbody>' +
            '</table>';
    }
}

function checkAll(element){
    var checkedElements = document.getElementsByClassName("nc-check-class")
    if(element.checked == true){
        jQuery(checkedElements).prop("checked", true)
    }else{
        jQuery(checkedElements).prop("checked", false)
    }
}


function modalConfirmSNCApproval(){
    var checkActionElementList = jQuery(".nc-check-class:checked");
    if(checkActionElementList.length > 0){
        var title = "Estas seguro? ";
        var text = "Estas seguro de realizar la aprobacion de la Snc";
        var icon = 'warning'
        var confirmButtonText = "Si, aprobar";
        acceptOrCancellModal(title, text ,icon , confirmButtonText, ncApproved)
    }else{
        swalNotification('top-center', 'warning', 'Favor seleccionar las solicitudes a aprobar', 2000);
    }
}
function ncApproved(){
    updateNcStatus(CUENTAS_CORRIENTES.ESTADOS.APROBADO.CODIGO)
}
async function updateNcStatus(newStatus){
    try {
        showSpinner();
        var checkActionElementList = jQuery(".nc-check-class:checked");
        var passData = new Object();
        passData.checkedList = checkActionElementList;
        document.getElementById("formId").submit();
    }catch (error){
        hideSpinner();
        console.log("Error updateNcStatus: "+error)
    }
}
async function updateNcStatusOld(newStatus){
    try {
        showSpinner();
        var checkActionElementList = jQuery(".nc-check-class:checked");

        var selectedsId = new StringBuilder();
        for(var x = 0; x < checkActionElementList.length; x++){
            var checkElement = checkActionElementList[x];
            var id = checkElement.getAttribute("attr-nc-id");
            selectedsId.append(id+",");
        }
        var selectedIds = selectedsId.toString().substring(0, selectedsId.toString().length-1);
        var passData = new Object();
        passData.checkedList = selectedIds;

        passData.newStatus = newStatus;

        jQuery.ajax({
            url: updateNotaDeCreditoStatusUrl(),
            type: 'POST',
            async:false,
            dataType: 'json',
            data: passData,
            complete: async function(data) {
                await reloadPage();
            },
            error: function () {
                dataToReturn = ERROR.AJAX_RETURN;
            }
        });

        //var dataReturn = await postDataFromQueryAjax(updateNotaDeCreditoStatusUrl(), passData, reloadPage());
    }catch (error){
        hideSpinner();
        console.log("Error accionAprobar: "+error)
    }
}

function showFactura(facturaJsonCabList, facturaJsonDetList){
    var facturaCabObj = facturaJsonCabList[0];
    if(facturaCabObj != null && facturaCabObj != undefined){
        jQuery(".generatedClass").remove();
        jQuery("#factura-modal-id").modal();
        //alert(facturaCabObj.Numero)
        //alert(camelCase("Importe Impuesto ME"));
        //var facturaCabObj = camelCase(facturaCabObj);
        facturaCabObj.fecha = formatterDate(facturaCabObj.fecha, "DD-MM-YYYY")
        var importeTotalConIva = parseFloat(facturaCabObj["importe_total_ml"])+parseFloat(facturaCabObj["importe_impuesto_ml"]);

        facturaCabObj["importeTotalConIva"] = formatter.format(importeTotalConIva);

        setDataInElementFromDto(facturaCabObj);

        var tbodyElement = getById("tbody-id")
        var originalTrElement = getById("product-tr-id");
        for(var x = 0; x < facturaJsonDetList.length; x++){
            var facturaDetObj = facturaJsonDetList[x];


            var precioVentaMLConIva = priceAndIva(facturaDetObj["Precio Venta ML"]);
            facturaDetObj["precioVentaMLConIva"] = formatter.format(precioVentaMLConIva);
            var totalLineaMLConIva = priceAndIva(facturaDetObj["Total Linea ML"]);
            facturaDetObj["totalLineaMLConIva"] = formatter.format(totalLineaMLConIva);


            var newTrElement = originalTrElement.cloneNode(true);
            newTrElement.id = "";
            newTrElement.style.display = "";
            newTrElement.setAttribute("class", "generatedClass")
            //newTrElement.setAttribute("class", "devolucionTrGeneradoClass");
            setDataInTableTd(newTrElement, facturaDetObj)
            tbodyElement.appendChild(newTrElement);
        }
    }else{
        swalNotification('top-center', 'warning', 'Factura asociada no existente', 4000);
    }

}

function facturaNotExist(){
    swalNotification('top-center', 'warning', 'Factura asociada no existente', 4000);
}
function noAprobarSNC(sncId){
    jQuery("#liberar-modal-id").modal();
    var noAprobadoAcceptBtnElement = getById("liberarAcceptBtnId")
    var newStatus = CUENTAS_CORRIENTES.ESTADOS.LIBERADO.CODIGO;
    noAprobadoAcceptBtnElement.setAttribute("onclick", "updateNcStatusWhereSncId('"+newStatus+"', "+sncId+")");
}
function aprobarSNC(sncId){
    var title = "Estas seguro? ";
    var text = "Estas seguro de realizar la aprobacion de la Snc";
    var icon = 'warning'
    var confirmButtonText = "Si, aprobar";
    //function() { DoThis(); }
    var newStatus = CUENTAS_CORRIENTES.ESTADOS.APROBADO.CODIGO;
    acceptOrCancellModal(title, text ,icon , confirmButtonText,
        function(){updateNcStatusWhereSncId(newStatus, sncId);})
}

async function updateNcStatusWhereSncId(newStatus, sncId){
    try {
        var motivoLiberarSNC = getById("motivoLiberarSNC").value;
        var passData = new Object();
        if(newStatus == CUENTAS_CORRIENTES.ESTADOS.APROBADO.CODIGO ||
            (newStatus == CUENTAS_CORRIENTES.ESTADOS.LIBERADO.CODIGO && motivoLiberarSNC.trim() != "")){
            showSpinner();
            var urlStr = "";
            passData = new Object();
            passData.newStatus = newStatus;
            passData.sncId = sncId;
            passData.observacion = "";
            if(newStatus == CUENTAS_CORRIENTES.ESTADOS.LIBERADO.CODIGO){
                passData.observacion = motivoLiberarSNC;
                urlStr = getUpdateNcStatusLiberadoWhereSncIdURL();
            }else{
                urlStr = getUpdateNcStatusWhereSncIdURL();
            }

            await ajaxPutData(urlStr, passData, reloadThisPage);
        }else{
            swalNotification('top-center', 'warning', 'Escriba el motivo de la liberacion', 4000);
        }
    }catch (error){
        hideSpinner();
        console.log("Error updateNcStatus: "+error)
    }
}

function editClienteFromSNCId(sncId){
    getById("actualClienteDivSnc-"+sncId).style.display = "none";
    getById("nuevoClienteDivSnc-"+sncId).style.display = "";
    getClientes(sncId);
}

function cancellEditCliente(sncId){
    getById("actualClienteDivSnc-"+sncId).style.display = "";
    getById("nuevoClienteDivSnc-"+sncId).style.display = "none";
}

function areYouShureUpdateClienteFromSNC(sncId){
    var clienteData = jQuery("#clienteSelectId-"+sncId).select2('data')
    var clienteText = clienteData[0].text;


    var actualClienteData = getById("clienteDataSncId-"+sncId).getAttribute("attr-val");
    var title = "Estas seguro de realizar el cambio de "+actualClienteData+" a "+clienteText+"?";
    var text = "Se procederá a liberar la SNC con el cliente actual. En 6 minutos se creará como pendiente la SNC con el cliente actualizado."
    var icon = 'warning'
    var confirmButtonText = "Si, aprobar";
    //function() { DoThis(); }
    var newStatus = CUENTAS_CORRIENTES.ESTADOS.APROBADO.CODIGO;
    acceptOrCancellModal(title, text ,icon , confirmButtonText,
        function(){updateClienteFromSNC(sncId);})
}


//TODO ACENTURION
function updateClienteFromSNC(sncId){
    var requiredCompleted = validateRequiredFields("nuevoClienteDivSnc-"+sncId);
    if(requiredCompleted){
        var clienteId = jQuery("#clienteSelectId-"+sncId).val();
        try {
            showSpinner();
            passData = new Object();
            passData.sncId = sncId;
            passData.clienteId = clienteId;
            var urlStr = getCambioClienteSNCURL();
            ajaxPutData(urlStr, passData, reloadThisPage);
        }catch (error){
            hideSpinner();
            console.log("Error updateNcStatus: "+error)
        }
    }
}



function getClientes(sncId){
    jQuery("#clienteSelectId-"+sncId).select2({
        placeholder: 'Select a option',
        ajax: {
            url: getClientesUrl(),
            dataType: 'json',
            type: 'GET',
            processResults(data) {
                return {
                    results: jQuery.map(data, function (item) {
                        return {
                            text:   item.datosCliente,
                            id:     item.id,
                        }
                    })
                }
            }
        }
    });
}

function showSncDetails(sncId){
    var trDetailsElement = getById("sncTrId-"+sncId);
    if(trDetailsElement.style.display == 'none'){
        trDetailsElement.style.display = '';
    }else{
        trDetailsElement.style.display = 'none';
    }
}