function getDepositosList(){
    var url = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    //sb.append("SELECT id, fletero as result FROM gc_fletero ");
    sb.append("SELECT id, nombre as result FROM deposito WHERE 1=1 ");
    passData.query = sb.toString();
    var select2Element = jQuery('.js-data-example-ajax');
    setSelect2WhitLimit(select2Element, sb.toString(), setDepositosData, getDepositoFilterQuery, url)
    /*
    select2Element.on('change', function (e) {
        $('#facturaNroSelect2Id').val(null).trigger('change');
    });
    */
}

function setDepositosData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getDepositoFilterQuery(query, filter){
    if(filter != undefined && filter != null && filter.trim() != ''){
        query = query+" AND nombre ilike ? "
    }
    return query;
}




async function validateExistDepositoRegla(depositoDesdeId, depositoHastaId){
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var passDataSb = new StringBuilder();
    passDataSb.append("SELECT count(*) FROM deposito_regla WHERE from_deposito_id = "+depositoDesdeId+" ");
    passDataSb.append("AND to_deposito_id = "+depositoHastaId);
    passData.query = passDataSb.toString();

    var cantidadList = await getDataFromQueryAjax(urlStr, passData)
    var cantidad = cantidadList[0].count;
    return cantidad;
}