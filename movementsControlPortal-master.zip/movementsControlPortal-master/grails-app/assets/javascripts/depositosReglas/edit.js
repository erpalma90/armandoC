async function initJsPage(){
    await getDepositosList();
    await loadData();
}

function loadData(){
    var fromDepositoId  = getFromDepositoId();
    var fromDepositoNombre = getFromDepositoNombre();
    var toDepositoId    = getToDepositoId();
    var toDepositoNombre = getToDepositoNombre();


    jQuery('#fromDepositoSelect2Id').val(fromDepositoId)
    jQuery('#toDepositoSelect2Id').val(toDepositoId)
    jQuery('.js-data-example-ajax').trigger('change');

    var fromDepositoSelect = jQuery('#fromDepositoSelect2Id');
    var option1 = new Option(fromDepositoNombre, fromDepositoId, true, true);
    fromDepositoSelect.append(option1).trigger('change');

    var toDepositoSelect = jQuery('#toDepositoSelect2Id');
    var option2 = new Option(toDepositoNombre, toDepositoId, true, true);
    toDepositoSelect.append(option2).trigger('change');

}

async function updateDepositoRegla(){
    var depositoReglaId = getDepositoReglaId();
    var depositoDesdeId = jQuery("#fromDepositoSelect2Id").val();
    var depositoHastaId = jQuery("#toDepositoSelect2Id").val();
    var requiredFieldsOkFlag = validateRequiredFields("createDepositoReglaDivId");
    if(requiredFieldsOkFlag){
        var originalDepositoDesdeId = getFromDepositoId();
        var originalDepositoHastaId = getToDepositoId();
        if(originalDepositoDesdeId != depositoDesdeId || depositoHastaId != originalDepositoHastaId){
            if(depositoDesdeId != depositoHastaId){
                var cantidadExist = await validateExistDepositoRegla(depositoDesdeId, depositoHastaId);
                if(cantidadExist == 0){
                    showSpinner();
                    var passDataList = [];
                    //passDataList.push(getRetornosDetailsPassDataInsert(montoMap))
                    //var montoTotal = productPriceMap.get("TOTAL");
                    var passData = await getDepositoReglaPassDataUpdate();
                    passData.details = JSON.stringify(passDataList);
                    var urlStr = await getDynamicExecuteUpdateUrl();
                    jQuery.ajax({
                        url: urlStr,
                        type: 'PUT',
                        async:false,
                        data: passData,
                        success: function(data) {
                            if(data != ERROR.SERVER_ERROR){
                                goToUrl(getDepositosReglasIndexUrl(), getDepositosReglasShowUrl()+"/"+data, true);
                            }else{
                                alert('No se pudo guardar el retorno: e '+ERROR.SERVER_ERROR);
                                hideSpinner();
                            }
                        },
                        error: function () {
                            hideSpinner();
                            alert('Error, no se pudo guardar el retorno');
                        }
                    });
                }else{
                    swalNotification('top-center', 'warning', 'No se puede guardar, esta combinacion ya existe', 2000);
                }
            }else{
                swalNotification('top-center', 'warning', 'no puede combinar mismos depositos', 2000);
            }
        }else{
            swalNotification('top-center', 'warning', 'Realizar algun cambio, o cancelar la edicion', 2000);
        }

    }

}

function getDepositoReglaPassDataUpdate(){
    var sb = new StringBuilder();
    sb.append("UPDATE deposito_regla SET user_last_updated_id=?, to_deposito_id=?, from_deposito_id=?, ");
    sb.append("last_updated_date= current_timestamp ");
    sb.append("WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosDepositoReglaUpdate();
    passData.argsToSet = JSON.stringify(argsToSet);
    return passData;
}

function getDatosDepositoReglaUpdate(){
    var depositoDesdeId = jQuery("#fromDepositoSelect2Id").val();
    var depositoHastaId = jQuery("#toDepositoSelect2Id").val();
    var userLastUpdatedId = getLoggedUserId();
    var depositoReglaId = getDepositoReglaId();
    /*****/
    var columnsMap = new Map();
    columnsMap.set(1, [userLastUpdatedId      , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(2, [depositoHastaId      , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(3, [depositoDesdeId      , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(4, [depositoReglaId      , DATABASE.DATA_TYPE.BIGINT]);
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;
}