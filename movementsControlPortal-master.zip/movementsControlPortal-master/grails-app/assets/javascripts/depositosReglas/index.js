function goToShowDepositoRegla(depositosReglasId){
    showSpinner();
    goToUrl(window.location, getDepositosReglasShowUrl()+"/"+depositosReglasId);
}

function goToCreateDepositoRegla(){
    showSpinner();
    goToUrl(window.location, getDepositosReglasCreateUrl());
}
