function initJsPage(){
    getDepositosList()
}

async function saveDepositoRegla(){
    var depositoDesdeId = jQuery("#fromDepositoSelect2Id").val();
    var depositoHastaId = jQuery("#toDepositoSelect2Id").val();
    var requiredFieldsOkFlag = validateRequiredFields("createDepositoReglaDivId");
    if(requiredFieldsOkFlag){
        if(depositoDesdeId != depositoHastaId){
            var cantidadExist = await validateExistDepositoRegla(depositoDesdeId, depositoHastaId);
            if(cantidadExist == 0){
                showSpinner();
                var passDataList = [];
                //passDataList.push(getRetornosDetailsPassDataInsert(montoMap))
                //var montoTotal = productPriceMap.get("TOTAL");
                var passData = await getDepositoReglaPassDataInsert();
                passData.details = JSON.stringify(passDataList);
                var urlStr = await getDynamicExecuteUpdateUrl();
                jQuery.ajax({
                    url: urlStr,
                    type: 'PUT',
                    async:false,
                    data: passData,
                    success: function(data) {
                        if(data != ERROR.SERVER_ERROR){
                            goToUrl(getDepositosReglasIndexUrl(), getDepositosReglasShowUrl()+"/"+data, true);
                        }else{
                            alert('No se pudo guardar el retorno: e '+ERROR.SERVER_ERROR);
                            hideSpinner();
                        }
                    },
                    error: function () {
                        hideSpinner();
                        alert('Error, no se pudo guardar el retorno');
                    }
                });
            }else{
                swalNotification('top-center', 'warning', 'No se puede guardar, esta combinacion ya existe', 2000);
            }
        }else{
            swalNotification('top-center', 'warning', 'no puede combinar mismos depositos', 2000);
        }
    }

}
function getDepositoReglaPassDataInsert(){
    var sb = new StringBuilder();
    sb.append("INSERT INTO deposito_regla(id, version, user_last_updated_id, to_deposito_id, from_deposito_id, ");
    sb.append("user_creation_id, creation_date, last_updated_date) ");
    sb.append("VALUES (nextval('deposito_regla_seq'), 0, ?, ?, ?, ?, current_timestamp, current_timestamp) ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosDepositoReglaInsert();
    passData.argsToSet = JSON.stringify(argsToSet);
    return passData;
}

function getDatosDepositoReglaInsert(){
    var depositoDesdeId = jQuery("#fromDepositoSelect2Id").val();
    var depositoHastaId = jQuery("#toDepositoSelect2Id").val();
    var userLastUpdatedId = getLoggedUserId();
    /*****/
    var columnsMap = new Map();
    columnsMap.set(1, [userLastUpdatedId      , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(2, [depositoHastaId      , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(3, [depositoDesdeId      , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(4, [userLastUpdatedId      , DATABASE.DATA_TYPE.BIGINT]);
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;
}