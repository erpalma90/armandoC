function goToEditDepositoRegla(){
    var depositosReglasId = getDepositosReglasId();
    showSpinner();
    goToUrl(window.location, getDepositosReglasEditUrl()+"/"+depositosReglasId);
}
function areYouShureDeleteDepositoRegla(){
    var title = "Estas seguro? ";
    var text = "Estas seguro de eliminar esta regla de Depósito? ";
    var icon = 'warning'
    var confirmButtonText = "Si, eliminar";
    acceptOrCancellModal(title, text ,icon , confirmButtonText, goToDeleteDepositoRegla)
}

function goToDeleteDepositoRegla(){
    showSpinner();
    var passDataList = [];
    var passData = getDepositoReglaPassDataDelete();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                goToUrl(getIndexUrl(), getDepositosReglasIndexUrl(), true);
            }else{
                alert('No se pudo eliminar: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo eliminar');
        }
    });


}

function getDepositoReglaPassDataDelete(){
    var sb = new StringBuilder();
    sb.append("DELETE FROM deposito_regla WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosDepositoReglaDelete();
    passData.argsToSet = JSON.stringify(argsToSet);
    return passData;
}

function getDatosDepositoReglaDelete(){
    /*****/
    var depositosReglasId = getDepositosReglasId();
    var columnsMap = new Map();
    columnsMap.set(1, [depositosReglasId      , DATABASE.DATA_TYPE.BIGINT]);
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;
}