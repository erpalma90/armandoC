function initJsPage(){
    getClientesWhitLimit();
    loadData();
}

async function loadData(){
    var id = getClienteSelectedId();
    var razonSocial = getClienteRazonSocialSelected();
    setOptToSelect2(jQuery("#clienteSelectId"), id+"-"+razonSocial, id);
}