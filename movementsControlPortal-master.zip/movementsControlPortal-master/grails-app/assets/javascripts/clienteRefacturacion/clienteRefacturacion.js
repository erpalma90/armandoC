function getClientesWhitLimit(){
    var url = getGetDataFromQueryAndPsInGCURL();
    var passData = {};
    var sb = new StringBuilder();
    //sb.append("SELECT id, fletero as result FROM gc_fletero ");
    //sb.append("SELECT id, concat(id, '-',razon_social) as result FROM gc_clientes WHERE 1=1 ");
    sb.append("SELECT top 100 [ID Clientes] as id, cast([ID Clientes] as character varying)+'-'+[Razon Social] as result ");
    sb.append("FROM vta_clientes ");
    sb.append("INNER JOIN [VTA_Comprobantes de Ventas] on ");
    sb.append("vta_clientes.[ID Sucursales] = [VTA_Comprobantes de Ventas].[ID Sucursales] and ");
    sb.append("vta_clientes.[Id Comprobantes Ventas] = [VTA_Comprobantes de Ventas].[ID Comprobantes Ventas] ");
    sb.append("WHERE [VTA_Comprobantes de Ventas].[Tipo Comprobante] = 2 ");


    passData.query = sb.toString();
    var select2Element = jQuery('#clienteSelectId');
    setSelect2WhitLimit(select2Element, sb.toString(), setClienteData, getClienteFilterQuery, url)

    select2Element.on('change', function (e) {

    });
}

function setClienteData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}


function getClienteFilterQuery(query, filter){
    if(filter != undefined && filter != null && filter.trim() != ''){
        query = query+" AND cast([ID Clientes] as character varying)+'-'+[Razon Social] like ? "
    }
    return query+" ORDER BY [ID Clientes] asc ";
}

function goToClienteRefacturacionShowFromProductId(id){
    goToUrl(window.location, getClienteRefacturacionShowUrl()+"/"+id, true);
}