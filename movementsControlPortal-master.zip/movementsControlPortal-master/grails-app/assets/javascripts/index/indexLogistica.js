async function initJsPage(){
    await createDepositosButtonsAccess();
}

async function createDepositosButtonsAccess(number){
    var gcSb = new StringBuilder();
    gcSb.append("SELECT DISTINCT (d.[ID Depositos]) as gc_id_deposito, d.[Tipo Deposito] as nombre, ");
    gcSb.append("(select count(*) from STK_Stock d1 join STK_Depositos sd1 ON sd1.[ID Depositos]=d1.[ID Depositos] ");
    gcSb.append("where sd1.[ID Depositos] = d.[ID Depositos]) as cantidad_en_deposito, ");
    gcSb.append("(select count(*) from STK_Stock d1 join STK_Depositos sd1 ON sd1.[ID Depositos]=d1.[ID Depositos] ");
    gcSb.append("where sd1.[ID Depositos] = d.[ID Depositos] AND d1.Cantidad > 0) as cantidad_existente_en_deposito, ");
    gcSb.append("(select count(*) from STK_Stock d1 join STK_Depositos sd1 ON sd1.[ID Depositos]=d1.[ID Depositos] ");
    gcSb.append("where sd1.[ID Depositos] = d.[ID Depositos] AND d1.Cantidad < 0) as cantidad_en_negativo, ");
    gcSb.append("(select sum(d1.cantidad) from STK_Stock d1 join STK_Depositos sd1 ON sd1.[ID Depositos]=d1.[ID Depositos] ");
    gcSb.append("where sd1.[ID Depositos] = d.[ID Depositos]) as cantidad_total_en_deposito, ");
    gcSb.append("(select sum(d1.cantidad) from STK_Stock d1 join STK_Depositos sd1 ON sd1.[ID Depositos]=d1.[ID Depositos] ");
    gcSb.append("join STK_Productos sp on sp.[ID Productos] = d1.[ID Productos] ");
    gcSb.append("where sd1.[ID Depositos] = d.[ID Depositos] AND sp.[Clasificacion 7] = 'SI') as cantidad_total_activos_en_deposito ");
    gcSb.append("FROM STK_Depositos d ");
    gcSb.append("JOIN STK_Stock s ON s.[ID Depositos] = d.[ID Depositos] ");
    gcSb.append("WHERE d.[Tipo Deposito] != 'Fleteros' ");
    gcSb.append("ORDER BY d.[ID Depositos] ASC ");


    var gcUrlStr = getGetDataFromQueryAndPsInGCURL();
    var gcPassData = new Object();
    gcPassData.query = gcSb.toString();
    var gcDtoList = await getDataFromQueryAsyncAjax(gcUrlStr, gcPassData)
    var gcDepositoMap = new Map();
    for(var i = 0; i < gcDtoList.length; i++){
        var depositoDto = gcDtoList[i];
        gcDepositoMap.set(parseInt(depositoDto.gc_id_deposito), depositoDto)
    }

    var urlStr = await getGetDataFromQueryURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT d.*, (select count(*) from deposito_detalle where deposito_id = d.id) as cantidad_en_deposito ");
    sb.append("FROM deposito d WHERE d.nombre != 'FLETERO' ");
    sb.append("AND gc_deposito_id is not null AND gc_deposito_id != 0 ")
    sb.append("order by position asc  ");
    passData.query = sb.toString();
    var dtoList = await getDataFromQueryAsyncAjax(urlStr, passData)
    var parentElement = getById("depositosParentDivId");
    var originalElement = getById("originalBoxId");
    for(var x = 0; x < dtoList.length; x++){
        //gc_deposito_nombre
        var dto = dtoList[x];
        dto.id = dto.id
        dto.cantidad_existente_en_deposito = 0;
        dto.cantidad_en_negativo = 0;
        if(dto.gc_deposito_id != null){
            var gcDepositoDto = gcDepositoMap.get(parseInt(dto.gc_deposito_id));
            if(gcDepositoDto != null && gcDepositoDto != undefined){
                dto.cantidad_en_deposito = gcDepositoDto.cantidad_en_deposito;
                dto.cantidad_existente_en_deposito = gcDepositoDto.cantidad_existente_en_deposito;
                dto.cantidad_en_negativo = gcDepositoDto.cantidad_en_negativo;
                var cantTotalDep = parseInt(gcDepositoDto.cantidad_total_en_deposito);
                dto.cantidad_total_en_deposito = formatSepMiles(cantTotalDep);
                dto.cantidad_total_activos_en_deposito = formatSepMiles(gcDepositoDto.cantidad_total_activos_en_deposito)
            }
        }

        var newElement = originalElement.cloneNode(true);
        newElement.id = "";
        newElement.style.display = "";
        //newTrElement.setAttribute("class", "boxGeneradoClass");
        var childElement = newElement.getElementsByClassName("info-box mb-3 bg-info")[0];
        if(dto.cantidad_existente_en_deposito == 0){

            childElement.classList.remove("bg-info");
            //childElement.classList.add("bg-gray");
            childElement.style.backgroundColor = "#80808045"
        }else{
            if(dto.nombre == 'PTBOD'){
                childElement.classList.remove("bg-info");
                childElement.classList.add("bg-success");
            }
            newElement.setAttribute("onclick", "showAllRetornoDetalleDepositoFromDepositoId("+dto.id+")");
        }
        setDataInTableTd(newElement, dto)
        parentElement.appendChild(newElement)
        //getById("devolucionesTableTrId").style.display = 'none'
    }
}


async function loadDepositosDetalles(){
    try {
        showSpinner();
        var urlStr = await getLoadDepositosDetallesUrl();
        var resultList = await getDataFromQueryAsyncAjax(urlStr, null, reloadThisPage)
    }catch (error){
        console.error("error in loadDepositosDetalles: "+error);
        hideSpinner();
    }
}

function generarTransferencia(){
    var urlStr = getGenerarTransferenciaEntreFilialesURL();
    var passData = new Object();
    ajaxPutData(urlStr, passData, reloadThisPage)
}