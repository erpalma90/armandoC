function initJsPage(){
    loadFleterosSelect2Index();
    loadPendienteDeAprobacionCantidad();
    loadAprobadosCantidad();
    loadRechazadosPorDepositoCantidad();
    loadRetornosCantidadesDepositos();
    loadSobrantesCantidadesDepositos();
    loadActivosSalidaCantidadesDepositos();
    loadActivosEntradaCantidadesDeposito();
}

async function loadRetornosCantidadesDepositos(){
    var urlStr = await getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT ");
    sb.append("re.deposito_estado, ");
    sb.append("count(*) as cantidad ");
    sb.append("FROM retorno r ");
    sb.append("left join retorno_estados re on re.id = r.retorno_estado_id ");
    sb.append("WHERE re.registro_estado != 'PENDIENTE REGISTRO' ");
    sb.append("group by re.registro_estado, re.deposito_estado ");
    passData.query = sb.toString();
    var dtoList = await getDataFromQueryAjax(urlStr, passData);
    var retornosEstadosMap = new Map();
    retornosEstadosMap.set("PENDIENTE DEPOSITO", ["retornoPendienteAprobacionCantidadId", "retornoPendienteAprobacionSumatoriaMontosId"])
    retornosEstadosMap.set("APROBADO DEPOSITO", ["retornosAprobadosPorRegistroCantidadId", "retornosAprobadosSumatoriaMontosId"])
    retornosEstadosMap.set("RECHAZADO DEPOSITO", ["retornosRechazadosCantidadId", "retornosRechazadosSumatoriaMontosId"])
    jQuery("#retornoPendienteAprobacionCantidadId").html("0");
    jQuery("#retornosAprobadosPorRegistroCantidadId").html("0");
    jQuery("#retornosRechazadosCantidadId").html("0");
    var cantidadMap = new Map();
    var sumatoriaMap = new Map();
    for(let i = 0; i < dtoList.length; i++){
        let dto = dtoList[i];
        let cantidadElemenId = retornosEstadosMap.get(dto.deposito_estado)[0];
        jQuery("#"+cantidadElemenId).html(dto.cantidad);
    }
}

async function loadSobrantesCantidadesDepositos(){
    var urlStr = await getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT ");
    sb.append("se.deposito_estado, ");
    sb.append("count(*) as cantidad ");
    sb.append("FROM sobrante s ");
    sb.append("left join sobrante_estados se on se.id = s.sobrante_estados_id ");
    sb.append("WHERE se.registro_estado != 'PENDIENTE REGISTRO' ");
    sb.append("group by se.registro_estado, se.deposito_estado ");
    passData.query = sb.toString();
    var dtoList = await getDataFromQueryAjax(urlStr, passData);
    var retornosEstadosMap = new Map();
    retornosEstadosMap.set("PENDIENTE DEPOSITO", ["sobrantePendienteAprobacionCantidadId", "sobrantePendienteAprobacionSumatoriaMontosId"])
    retornosEstadosMap.set("APROBADO DEPOSITO", ["sobranteAprobadosPorRegistroCantidadId", "sobranteAprobadosSumatoriaMontosId"])
    retornosEstadosMap.set("RECHAZADO DEPOSITO", ["sobranteRechazadosCantidadId", "sobranteRechazadosSumatoriaMontosId"])
    jQuery("#sobrantePendienteAprobacionCantidadId").html("0");
    jQuery("#sobranteAprobadosPorRegistroCantidadId").html("0");
    jQuery("#sobranteRechazadosCantidadId").html("0");
    var cantidadMap = new Map();
    var sumatoriaMap = new Map();
    for(let i = 0; i < dtoList.length; i++){
        let dto = dtoList[i];
        let cantidadElemenId = retornosEstadosMap.get(dto.deposito_estado)[0];
        jQuery("#"+cantidadElemenId).html(dto.cantidad);
    }
}

async function loadActivosSalidaCantidadesDepositos(){
    var urlStr = await getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();

    sb.append("SELECT ase.deposito_estado, count(*) as cantidad FROM activos_salida asa ");
    sb.append("left join activos_salida_estados ase on ase.id = asa.activos_salida_estado_id ");
    sb.append("group by ase.deposito_estado, ase.deposito_estado ");

    passData.query = sb.toString();
    var dtoList = await getDataFromQueryAjax(urlStr, passData);
    var retornosEstadosMap = new Map();
    retornosEstadosMap.set("PENDIENTE DEPOSITO", ["activosSalidaPendienteAprobacionCantidadId", "activosSalidaPendienteAprobacionSumatoriaMontosId"])
    retornosEstadosMap.set("APROBADO DEPOSITO", ["activosSalidaAprobadosPorRegistroCantidadId", "activosSalidaAprobadosSumatoriaMontosId"])
    retornosEstadosMap.set("RECHAZADO DEPOSITO", ["activosSalidaRechazadosCantidadId", "activosSalidaRechazadosSumatoriaMontosId"])
    jQuery("#activosSalidaPendienteAprobacionCantidadId").html("0");
    jQuery("#activosSalidaAprobadosPorRegistroCantidadId").html("0");
    jQuery("#activosSalidaRechazadosCantidadId").html("0");
    var cantidadMap = new Map();
    var sumatoriaMap = new Map();
    for(let i = 0; i < dtoList.length; i++){
        let dto = dtoList[i];
        let cantidadElemenId = retornosEstadosMap.get(dto.deposito_estado)[0];
        jQuery("#"+cantidadElemenId).html(dto.cantidad);
    }
}
async function loadActivosEntradaCantidadesDeposito(){
    var urlStr = await getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT aee.deposito_estado, count(*) as cantidad FROM activos_entrada ae ");
    sb.append("left join activos_entrada_estados aee on aee.id = ae.activos_entrada_estado_id ");
    sb.append("WHERE aee.registro_estado != 'PENDIENTE REGISTRO' ");
    sb.append("group by aee.deposito_estado ");

    passData.query = sb.toString();
    var dtoList = await getDataFromQueryAjax(urlStr, passData);
    var retornosEstadosMap = new Map();
    retornosEstadosMap.set("PENDIENTE DEPOSITO", ["activosEntradaPendienteAprobacionCantidadId", "activosEntradaPendienteAprobacionSumatoriaMontosId"])
    retornosEstadosMap.set("APROBADO DEPOSITO", ["activosEntradaAprobadosPorRegistroCantidadId", "activosEntradaAprobadosSumatoriaMontosId"])
    retornosEstadosMap.set("RECHAZADO DEPOSITO", ["activosEntradaRechazadoPorDepositoCantidadId", "activosEntradaRechazadosSumatoriaMontosId"])
    jQuery("#activosEntradaPendienteAprobacionCantidadId").html("0");
    jQuery("#activosEntradaAprobadosPorRegistroCantidadId").html("0");
    jQuery("#activosEntradaRechazadoPorDepositoCantidadId").html("0");
    var cantidadMap = new Map();
    var sumatoriaMap = new Map();
    for(let i = 0; i < dtoList.length; i++){
        let dto = dtoList[i];
        if(retornosEstadosMap.get(dto.deposito_estado) != null && retornosEstadosMap.get(dto.deposito_estado) != undefined){
            let cantidadElemenId = retornosEstadosMap.get(dto.deposito_estado)[0];
            jQuery("#"+cantidadElemenId).html(dto.cantidad);
        }
    }
}