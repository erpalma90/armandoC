var dataTable = null;
function getFleteros(){
    var urlStr = getFleterosDataURL();
    var role = getCurrentRole();
    jQuery.ajax({
        url: urlStr,
        type: 'GET',

        async:false,
        data: {flag:true, role:role},
        success: function(data) {
            var fleterosList = data;
            var fleteroSelect2Element = document.getElementById("fleteroSelectId");
            for(var x = 0; x < fleterosList.length; x++){
                var fleteroDta = fleterosList[x];
                var optionElement = document.createElement("option")
                optionElement.value = fleteroDta.id;
                optionElement.appendChild(document.createTextNode(fleteroDta.nroMovil+" - "+fleteroDta.fletero));
                fleteroSelect2Element.append(optionElement);
            }
        },
        error: function () {
            console.log('Error, no se pudieron obtener los fleteros');
        }
    });
}

function loadFleteroSelect2(){
    jQuery('#fleteroSelectId').select2();
}

function searchMovements(){
    var fleteroSeleccionadoId = getById("fleteroSelectId").value;
    if(fleteroSeleccionadoId != 'Seleccionar'){
        showSpinner();
        goToUrl(window.location, getShowFleteroMovementsUrl()+"/"+fleteroSeleccionadoId);
    }else{
        swalNotification('top-center', 'warning', 'Seleccionar un fletero para aplicar la búsqueda', 2000);
    }
}

async function loadPendienteDeAprobacionCantidad(){
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var passDataSb = new StringBuilder();
    passDataSb.append("SELECT count(distinct(d.*)), ");
    passDataSb.append("SUM(dd.precio_unitario*(dd.cantidad_documentada-cantidad_verificada)) as suma_monto ");
    passDataSb.append("FROM devolucion d ");
    passDataSb.append("JOIN devolucion_estados de ON de.id = d.devolucion_estado_id ");
    passDataSb.append("LEFT JOIN liquidacion l ON l.id = d.liquidacion_id ");
    passDataSb.append("LEFT JOIN liquidacion_estado le ON le.id = l.liquidacion_estado_id ");
    passDataSb.append("LEFT JOIN devolucion_detalle dd ON dd.devolucion_id = d.id ");
    passDataSb.append("WHERE 1=1 ");
    if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
        passDataSb.append("AND de.codigo = '"+DEVOLUCION.ESTADOS.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO+"' ");
    }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
        passDataSb.append("AND de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO+"' ");
    }else if(CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
        passDataSb.append("AND (le.codigo = '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"' OR le.codigo IS NULL) ");
        passDataSb.append("AND (de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO +"' ");
        passDataSb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.DERRAME_LABORATORIO.CODIGO +"' ");
        passDataSb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.STOCK_LABORATORIO.CODIGO +"') ");
        passDataSb.append("AND dd.cantidad_documentada != dd.cantidad_verificada ");
        passDataSb.append("AND d.transferencia_filial IS NOT TRUE ");
    }
    passDataSb.append("AND fletero_id IS NOT NULL ");
    passData.query = passDataSb.toString();
    console.log("passDataSb.toString(): "+passDataSb.toString())
    var cantidadDevolucionPendienteAprobacionList = await getDataFromQueryAjax(urlStr, passData)
    var cantidad = cantidadDevolucionPendienteAprobacionList[0].count;
    var sumaMonto = cantidadDevolucionPendienteAprobacionList[0].suma_monto;
    jQuery("#pendienteAprobacionCantidadId").html(cantidad);
    jQuery("#pendienteAprobacionSumatoriaMontosId").html(sumaMonto);
}

async function loadAprobadosCantidad(){
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var passDataSb = new StringBuilder();
    passDataSb.append("SELECT count(distinct(d.*)), ");
    passDataSb.append("sum(ld.total) as suma_monto ");
    passDataSb.append("FROM devolucion d ");
    passDataSb.append("JOIN devolucion_estados de ON de.id = d.devolucion_estado_id ");
    passDataSb.append("LEFT JOIN liquidacion l ON l.id = d.liquidacion_id ");
    passDataSb.append("LEFT JOIN liquidacion_estado le ON le.id = l.liquidacion_estado_id ");
    passDataSb.append("LEFT JOIN devolucion_detalle dd ON dd.devolucion_id = d.id ");
    passDataSb.append("LEFT JOIN liquidacion_detalle ld ON ld.devolucion_detalle_id = dd.id ");
    passDataSb.append("WHERE 1=1 ");
    if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
        passDataSb.append("AND (de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO+"' ");
        passDataSb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO+"' ");
        passDataSb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.STOCK_LABORATORIO.CODIGO+"' ");
        passDataSb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.DERRAME_LABORATORIO.CODIGO+"' ");
        passDataSb.append(")");
    }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
        passDataSb.append("AND de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO+"' ");
    }else if(CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
        passDataSb.append("AND le.codigo = '"+LIQUIDACION.ESTADO.APROBADO.CODIGO+"' ");
    }
    passDataSb.append("AND fletero_id IS NOT NULL ");
    passData.query = passDataSb.toString();

    var cantidadDevolucionPendienteAprobacionList = await getDataFromQueryAjax(urlStr, passData)

    var cantidad = cantidadDevolucionPendienteAprobacionList[0].count;
    var sumaMonto = cantidadDevolucionPendienteAprobacionList[0].suma_monto;
    jQuery("#aprobadosSumatoriaMontosId").html(sumaMonto);
    jQuery("#aprobadosPorRegistroCantidadId").html(cantidad);
}

async function loadRechazadosPorDepositoCantidad(){
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var passDataSb = new StringBuilder();
    passDataSb.append("SELECT count(*) FROM devolucion ")
    passDataSb.append("WHERE devolucion_estado_id = ")
    passDataSb.append("(SELECT id FROM devolucion_estados WHERE codigo = '");
    passDataSb.append(DEVOLUCION.ESTADOS.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.LABORATORIO.CODIGO+"') ");
    passDataSb.append("AND fletero_id IS NOT NULL ");
    passData.query = passDataSb.toString();

    var cantidadDevolucionPendienteAprobacionList = await getDataFromQueryAjax(urlStr, passData)
    var cantidad = cantidadDevolucionPendienteAprobacionList[0].count;
    jQuery("#rechazadoPorDepositoCantidadId").html(cantidad);
}


var modalTitleMap = new Map();
modalTitleMap.set(1, "Pendientes")
modalTitleMap.set(2, "Aprobados")
modalTitleMap.set(3, "No registrados")
modalTitleMap.set(4, "Rechazados por Deposito")
async function showResultModalFromStatus(number){

    jQuery("#modalTitleId").html("Devoluciones-"+modalTitleMap.get(number))
    if(dataTable != null){
        dt2.clear();
        dt2.destroy()
        //dataTable.fnDraw(false);
    }
    var cardElement = getById("cardBodyId")
    jQuery(cardElement).children().remove();

    var devolucionesTableElement = getById("devolucionesTableId");
    var newDevolucionesTableElement = devolucionesTableElement.cloneNode(true);
    newDevolucionesTableElement.setAttribute("id", "");
    newDevolucionesTableElement.style.display = "";

    cardElement.appendChild(newDevolucionesTableElement);
    var newTableElement = cardElement.getElementsByTagName("table")[0]
    newTableElement.setAttribute("id", "devolucionesTableId");
    var newTbodyElement = newTableElement.getElementsByTagName("tbody")[0];
    newTbodyElement.setAttribute("id", "devolucionesTbodyId");
    var newOriginalTrElement = newTbodyElement.getElementsByTagName("tr")[0];
    newOriginalTrElement.setAttribute("id", "devolucionesTableTrId");


    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT DISTINCT(d.id), d.fletero_id as fletero_id, concat(f.nro_movil,'-',f.fletero) as fletero, ");
    sb.append("d.cliente_id, concat(c.razon_social,'-',c.calle,'-',c.direccion) as razon_social, c.calle, ");
    sb.append("c.direccion, d.con_snc, ");
    sb.append("d.devolucion_estado_id, ");
    var devolucionEstado = "de.registro_estado"
    if(CURRENT_ROLE == ROLES.ROLE_REGISTRO){
        devolucionEstado = "de.registro_estado"
    }
    if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
        devolucionEstado = "de.deposito_estado"
    }
    sb.append(devolucionEstado+" ");
    sb.append("as devolucion_estado_descripcion, ");
    sb.append("d.metodo_de_carga_id, ");
    sb.append("dmc.descripcion as devolucion_metodo_carga_descripcion, d.fecha, d.snc_nro, d.factura_nro, d.portal_fecha_ultima_actualizacion ");
    sb.append("FROM devolucion d ");
    sb.append("JOIN gc_fletero f ON f.id = d.fletero_id ");
    sb.append("LEFT JOIN gc_clientes c ON d.cliente_id = c.id ");
    sb.append("LEFT JOIN devolucion_estados de ON de.id = d.devolucion_estado_id ");
    sb.append("LEFT JOIN devolucion_metodo_de_carga dmc ON dmc.id = d.metodo_de_carga_id ");
    sb.append("LEFT JOIN liquidacion l ON l.id = d.liquidacion_id ");
    sb.append("LEFT JOIN liquidacion_estado le ON le.id = l.liquidacion_estado_id ");
    sb.append("LEFT JOIN devolucion_detalle dd ON dd.devolucion_id = d.id ")
    if(number == 1){
        if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
            sb.append("WHERE de.codigo = '"+DEVOLUCION.ESTADOS.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO +"' ");
        }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
            sb.append("WHERE de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO +"' ");
        }else if(CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
            sb.append("WHERE 1=1 ");
            sb.append("AND (le.codigo = '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"' OR le.codigo IS NULL) ");
            sb.append("AND (de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO +"' ");
            sb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.DERRAME_LABORATORIO.CODIGO +"' ");
            sb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.STOCK_LABORATORIO.CODIGO +"') ");
            sb.append("AND dd.cantidad_documentada != dd.cantidad_verificada ");
            sb.append("AND d.transferencia_filial IS NOT TRUE ");
        }
    }else if (number == 2){
        var filter1;
        var filter2;
        if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
            filter1 = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO;
            filter2 = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO;
            sb.append("WHERE de.codigo in ('"+filter1+"', '"+filter2+"') ");
        }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
            filter1 = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO;
            sb.append("WHERE de.codigo in ('"+filter1+"') ");
        }else if(CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
            sb.append("WHERE 1=1 ");
            sb.append("AND le.codigo = '"+LIQUIDACION.ESTADO.APROBADO.CODIGO+"' ");
        }

    }else if (number == 3){
        sb.append("WHERE de.codigo = '"+DEVOLUCION.ESTADOS.NO_REGISTRADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO+"' ");
    }else if (number == 4){
        sb.append("WHERE de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.LABORATORIO.CODIGO+"' ");
    }else if(number == 5){
        if(CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
            sb.append("WHERE 1=1 ");
            sb.append("AND (le.codigo = '"+LIQUIDACION.ESTADO.NO_FACTURADO.CODIGO+"') ");
        }
    }
    sb.append("AND d.fecha > cast('01-07-2022' as date) ")
    if(number == 1){
        sb.append("ORDER BY d.fecha DESC ");
    }else{
        sb.append("ORDER BY d.portal_fecha_ultima_actualizacion DESC ");
    }
    passData.query = sb.toString();
    //console.log("passData.query: "+passData.query)
    devolucionesDtoList = await getDataFromQueryAjax(urlStr, passData)
    var tbodyElement = getById("devolucionesTbodyId");
    var originalTrElement = getById("devolucionesTableTrId");
    var formatter= 'DD-MM-YYYY HH:mm';
    for(var x = 0; x < devolucionesDtoList.length; x++){
        var dto = devolucionesDtoList[x];
        var date = new Date(dto.fecha);
        var newFecha = moment(date).format(formatter);
        dto.fecha = newFecha;
        dto.goToShow = dto.id;
        if(dto.con_snc == true){
            dto.con_snc = "Si"
        }else{
            dto.con_snc = "No"
        }
        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.id = "";
        newTrElement.style.display = "";
        newTrElement.setAttribute("class", "devolucionTrGeneradoClass");
        setDataInTableTd(newTrElement, dto)
        tbodyElement.appendChild(newTrElement)
        getById("devolucionesTableTrId").style.display = 'none'
    }
    dt2 = jQuery("#devolucionesTableId").DataTable({
        "order": [],
        "columnDefs": [ {
            "targets"  : 'no-sort',
            "orderable": false,
        }]
    });
    jQuery("#showApprovedPendingModalId").modal();
}


var genericModalTitleMap = new Map();
genericModalTitleMap.set(1, "Pendientes")
genericModalTitleMap.set(2, "Aprobados")
genericModalTitleMap.set(3, "Rechazados por Deposito")
genericModalTitleMap.set(4, "Pendientes")
genericModalTitleMap.set(5, "Aprobados")
genericModalTitleMap.set(6, "Rechazados por Deposito")
genericModalTitleMap.set(7, "Pendientes")
genericModalTitleMap.set(8, "Aprobados")
genericModalTitleMap.set(9, "No Facturados")

var liquidacionDataTable
var dt2Liquidacion = null;
async function showRetornoResultModalFromStatus(numero){
    if(liquidacionDataTable != null){
        dt2Liquidacion.clear();
        dt2Liquidacion.destroy()
        //liquidacionDataTable.fnDraw(false);
    }

    var urlStr = getGetIndexModalTemplateURL();
    var passData = new Object();

    if(numero == ROLE_OPTIONS.REGISTRO.RETORNO.PENDIENTE.NUMERO){
        passData.retornoEstado = "'"+RETORNO.ESTADO.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.REGISTRO.RETORNO.APROBADO.NUMERO){
        passData.retornoEstado = "'"+RETORNO.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"','"+
            RETORNO.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.REGISTRO.RETORNO.RECHAZADO_DEPOSITO.NUMERO){
        passData.retornoEstado = "'"+RETORNO.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO+"'";
    }else if(numero == ROLE_OPTIONS.DEPOSITO.RETORNO.PENDIENTE.NUMERO){
        passData.retornoEstado = "'"+RETORNO.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.DEPOSITO.RETORNO.APROBADO.NUMERO){
        passData.retornoEstado = "'"+RETORNO.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.DEPOSITO.RETORNO.RECHAZADO_DEPOSITO.NUMERO){
        passData.retornoEstado = "'"+RETORNO.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.LIQUIDACION.RETORNO.PENDIENTE.NUMERO){
        passData.retornoEstado = "'"+RETORNO.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"'";
        passData.liquidacionEstado = LIQUIDACION.ESTADO.PENDIENTE.CODIGO;
    }else if(numero == ROLE_OPTIONS.LIQUIDACION.RETORNO.FACTURADO.NUMERO){
        passData.retornoEstado = "'"+RETORNO.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"'";
        passData.liquidacionEstado = LIQUIDACION.ESTADO.APROBADO.CODIGO;
    }else if(numero == ROLE_OPTIONS.LIQUIDACION.RETORNO.NO_FACTURADO.NUMERO){
        passData.retornoEstado = "'"+RETORNO.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"'";
        passData.liquidacionEstado = LIQUIDACION.ESTADO.NO_FACTURADO.CODIGO;
    }
    var dataToReturn = null;
    var title = "Retornos-"+genericModalTitleMap.get(numero);

    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:false,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            jQuery("#containerId").html(data);
            jQuery("#retornoModalTitleId").html(title)
            jQuery("#retornoModalId").modal();
        },
        error: function () {
            alert("error")
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });

    dt2Liquidacion = jQuery("#retornosTableId").DataTable({
        "order": [],
        "columnDefs": [ {
            "targets"  : 'no-sort',
            "orderable": false,
        }]
    });

}



//var liquidacionDataTable
//var dt2Liquidacion = null;
async function showDynamicalResultModalFromStatus(numero, movimientoCodigo){
    if(liquidacionDataTable != null){
        dt2Liquidacion.clear();
        dt2Liquidacion.destroy()
        //liquidacionDataTable.fnDraw(false);
    }

    var urlStr = null;
    var passData = new Object();
    var title = "";
    if(movimientoCodigo == MOVIMIENTOS.SOBRANTE.CODIGO){
        urlStr = getGetIndexSobranteModalTemplateURL();
        setUrlAndPassDataSobrante(passData, numero);
        title = "Sobrantes-"+genericModalTitleMap.get(numero);
    }else if(movimientoCodigo == MOVIMIENTOS.ACTIVOS_SALIDA.CODIGO){
        urlStr = getGetIndexActivosSalidaModalTemplateURL();
        setUrlAndPassDataActivosSalida(passData, numero);
        title = "Activos Salida-"+genericModalTitleMap.get(numero);
    }else if(movimientoCodigo == MOVIMIENTOS.ACTIVOS_ENTRADA.CODIGO){
        urlStr = getGetIndexActivosEntradaModalTemplateURL();
        setUrlAndPassDataActivosEntrada(passData, numero);
        title = "Activos Entrada-"+genericModalTitleMap.get(numero);
    }

    var dataToReturn = null;


    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:false,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            jQuery("#containerId").html(data);
            jQuery("#retornoModalTitleId").html(title)
            jQuery("#retornoModalId").modal();
        },
        error: function () {
            alert("error")
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });

    dt2Liquidacion = jQuery("#retornosTableId").DataTable({
        "order": [],
        "columnDefs": [ {
            "targets"  : 'no-sort',
            "orderable": false,
        }]
    });

}

function setUrlAndPassDataSobrante(passData, numero){

    if(numero == ROLE_OPTIONS.REGISTRO.SOBRANTE.PENDIENTE.NUMERO){
        passData.sobranteEstado = "'"+SOBRANTE.ESTADO.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.REGISTRO.SOBRANTE.APROBADO.NUMERO){
        passData.sobranteEstado = "'"+SOBRANTE.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"','"+
            SOBRANTE.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.REGISTRO.SOBRANTE.RECHAZADO_DEPOSITO.NUMERO){
        passData.sobranteEstado = "'"+SOBRANTE.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO+"'";
    }else if(numero == ROLE_OPTIONS.DEPOSITO.SOBRANTE.PENDIENTE.NUMERO){
        passData.sobranteEstado = "'"+SOBRANTE.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.DEPOSITO.SOBRANTE.APROBADO.NUMERO){
        passData.sobranteEstado = "'"+SOBRANTE.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.DEPOSITO.SOBRANTE.RECHAZADO_DEPOSITO.NUMERO){
        passData.sobranteEstado = "'"+SOBRANTE.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.LIQUIDACION.SOBRANTE.PENDIENTE.NUMERO){
        passData.sobranteEstado = "'"+SOBRANTE.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"'";
        passData.liquidacionEstado = LIQUIDACION.ESTADO.PENDIENTE.CODIGO;
    }else if(numero == ROLE_OPTIONS.LIQUIDACION.SOBRANTE.FACTURADO.NUMERO){
        passData.sobranteEstado = "'"+SOBRANTE.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"'";
        passData.liquidacionEstado = LIQUIDACION.ESTADO.APROBADO.CODIGO;
    }else if(numero == ROLE_OPTIONS.LIQUIDACION.SOBRANTE.NO_FACTURADO.NUMERO){
        passData.sobranteEstado = "'"+SOBRANTE.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"'";
        passData.liquidacionEstado = LIQUIDACION.ESTADO.NO_FACTURADO.CODIGO;
    }
    passData.estado = passData.sobranteEstado;
}


function setUrlAndPassDataActivosSalida(passData, numero){
    if(numero == ROLE_OPTIONS.DEPOSITO.ACTIVOS_SALIDA.PENDIENTE.NUMERO){
        passData.estado = "'"+ACTIVOS_SALIDA.ESTADO.PENDIENTE_DEPOSITO.CODIGO+"'"
    }else if(numero == ROLE_OPTIONS.DEPOSITO.ACTIVOS_SALIDA.APROBADO.NUMERO){
        passData.estado = "'"+ACTIVOS_SALIDA.ESTADO.APROBADO_DEPOSITO.CODIGO+"'";
    }
}

function setUrlAndPassDataActivosEntrada(passData, numero){
    var list = [];
    //REGISTRO
    if(numero == ROLE_OPTIONS.REGISTRO.ACTIVOS_ENTRADA.PENDIENTE.NUMERO){
        list.push(ACTIVOS_ENTRADA.ESTADO.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.CODIGO)
    }else if(numero == ROLE_OPTIONS.REGISTRO.ACTIVOS_ENTRADA.APROBADO.NUMERO){
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO);
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO);
    }else if(numero == ROLE_OPTIONS.REGISTRO.ACTIVOS_ENTRADA.RECHAZADO_DEPOSITO.NUMERO){
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO);
    }
    //DEPOSITO
    if(numero == ROLE_OPTIONS.DEPOSITO.ACTIVOS_ENTRADA.PENDIENTE.NUMERO){
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO)
    }else if(numero == ROLE_OPTIONS.DEPOSITO.ACTIVOS_ENTRADA.APROBADO.NUMERO){
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO);
    }else if(numero == ROLE_OPTIONS.DEPOSITO.ACTIVOS_ENTRADA.RECHAZADO_DEPOSITO.NUMERO){
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO);
    }
    //LIQUIDACION
    if(numero == ROLE_OPTIONS.LIQUIDACION.ACTIVOS_ENTRADA.PENDIENTE.NUMERO){
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO)
        passData.liquidacionEstado = LIQUIDACION.ESTADO.PENDIENTE.CODIGO;
    }else if(numero == ROLE_OPTIONS.LIQUIDACION.ACTIVOS_ENTRADA.APROBADO.NUMERO){
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO);
        passData.liquidacionEstado = LIQUIDACION.ESTADO.APROBADO.CODIGO;
    }else if(numero == ROLE_OPTIONS.LIQUIDACION.ACTIVOS_ENTRADA.RECHAZADO_DEPOSITO.NUMERO){
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO);
        passData.liquidacionEstado = LIQUIDACION.ESTADO.NO_FACTURADO.CODIGO;
    }
    passData.estado = getListToString(list);

}

