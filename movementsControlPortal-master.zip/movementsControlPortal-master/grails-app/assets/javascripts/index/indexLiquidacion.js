async function initJsPage(){
    await getFleterosLiquidacionSelect2();
    await loadPendienteDeAprobacionCantidad();
    await loadAprobadosCantidad();
    await loadNoFacturadosCantidad();
    await loadRetornosCantidadesLiquidacion();
    await loadActivosEntradaCantidadesLiquidacion();
    await formatPageDataFromTags("attr-money-format");

}

async function loadNoFacturadosCantidad(){
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var passDataSb = new StringBuilder();
    passDataSb.append("SELECT count(distinct(d.*)), ");
    passDataSb.append("sum(ld.total) as suma_monto ")
    passDataSb.append("FROM devolucion d ");
    passDataSb.append("JOIN devolucion_estados de ON de.id = d.devolucion_estado_id ");
    passDataSb.append("LEFT JOIN liquidacion l ON l.id = d.liquidacion_id ");
    passDataSb.append("LEFT JOIN liquidacion_estado le ON le.id = l.liquidacion_estado_id ");
    passDataSb.append("LEFT JOIN devolucion_detalle dd ON dd.devolucion_id = d.id ");
    passDataSb.append("LEFT JOIN liquidacion_detalle ld ON ld.devolucion_detalle_id = dd.id ");
    passDataSb.append("WHERE 1=1 ");
    passDataSb.append("AND le.codigo = '"+LIQUIDACION.ESTADO.NO_FACTURADO.CODIGO+"' ");
    passDataSb.append("AND fletero_id IS NOT NULL ");
    passData.query = passDataSb.toString();
    console.log("no facturado: "+passDataSb.toString())
    var cantidadDevolucionPendienteAprobacionList = await getDataFromQueryAjax(urlStr, passData)

    var cantidad = cantidadDevolucionPendienteAprobacionList[0].count;
    var sumaMonto = cantidadDevolucionPendienteAprobacionList[0].suma_monto;
    jQuery("#noFacturadosSumatoriaMontosId").html(sumaMonto);
    jQuery("#nofacturadosCantidadId").html(cantidad);
}


async function loadRetornosCantidadesLiquidacion(){
    var urlStr = await getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT CASE WHEN le.id is null THEN (SELECT le1.id FROM liquidacion_estado le1 WHERE le1.codigo = '01') ELSE le.id END, ");
    sb.append("CASE WHEN le.descripcion is null THEN (SELECT le1.descripcion FROM liquidacion_estado le1 WHERE le1.codigo = '01') ELSE le.descripcion END, ");
    sb.append("CASE WHEN le.codigo is null THEN '01' ELSE le.codigo END as liquidacion_estado_codigo, ");
    sb.append("count(*) as cantidad, sum(r.monto_total) as monto ");
    sb.append("FROM retorno r join retorno_estados re on re.id = r.retorno_estado_id ");
    sb.append("left join liquidacion l on l.id = r.liquidacion_id ");
    sb.append("left join liquidacion_estado le on le.id = l.liquidacion_estado_id ");
    sb.append("WHERE 1=1 ");
    sb.append("AND re.codigo = '"+RETORNO.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"' ");
    sb.append("GROUP BY le.id, le.codigo,le.descripcion order by le.id asc ");

    passData.query = sb.toString();
    var dtoList = await getDataFromQueryAjax(urlStr, passData);
    var retornosEstadosMap = new Map();
    retornosEstadosMap.set(LIQUIDACION.ESTADO.PENDIENTE.CODIGO, ["retornoPendienteAprobacionCantidadId", "retornoPendienteAprobacionSumatoriaMontosId"])
    retornosEstadosMap.set(LIQUIDACION.ESTADO.APROBADO.CODIGO, ["retornosAprobadosPorRegistroCantidadId", "retornosAprobadosSumatoriaMontosId"])
    retornosEstadosMap.set(LIQUIDACION.ESTADO.NO_FACTURADO.CODIGO, ["retornosNofacturadosCantidadId", "retornosNoFacturadosSumatoriaMontosId"])
    var cantidadMap = new Map();
    var sumatoriaMap = new Map();
    jQuery("#retornoPendienteAprobacionCantidadId").html("0");
    jQuery("#retornoPendienteAprobacionSumatoriaMontosId").html("0");
    jQuery("#retornosAprobadosPorRegistroCantidadId").html("0");
    jQuery("#retornosAprobadosSumatoriaMontosId").html("0");
    jQuery("#retornosNofacturadosCantidadId").html("0");
    jQuery("#retornosNoFacturadosSumatoriaMontosId").html("0");

    for(let i = 0; i < dtoList.length; i++){
        let dto = dtoList[i];
        if(dto.id == null && dto.descripcion == null && dto.liquidacion_estado_codigo == null){
            dto.liquidacion_estado_codigo = LIQUIDACION.ESTADO.PENDIENTE.CODIGO;
            dto.cantidad = parseInt(cantidadMap.get(LIQUIDACION.ESTADO.PENDIENTE.CODIGO))+parseInt(dto.cantidad)
            dto.monto = parseFloat(sumatoriaMap.get(LIQUIDACION.ESTADO.PENDIENTE.CODIGO))+parseFloat(dto.monto)
        }

        let cantidadElemenId = retornosEstadosMap.get(dto.liquidacion_estado_codigo)[0];
        let sumatoriaElemenId = retornosEstadosMap.get(dto.liquidacion_estado_codigo)[1];
        cantidadMap.set(dto.liquidacion_estado_codigo, dto.cantidad)
        sumatoriaMap.set(dto.liquidacion_estado_codigo, dto.monto);

        jQuery("#"+cantidadElemenId).html(parseInt(cantidadMap.get(dto.liquidacion_estado_codigo)));
        jQuery("#"+sumatoriaElemenId).html(parseInt(sumatoriaMap.get(dto.liquidacion_estado_codigo)));
    }
}


function getFleteroQuery(){
    var sb = new StringBuilder();
    sb.append("SELECT distinct(f.id), f.version, f.fletero, f.sucursal_id, f.nro_movil, concat(f.nro_movil,'-',f.fletero)  as result, ae.gc_fletero_id ");
    sb.append("FROM gc_fletero f ");
    sb.append("LEFT JOIN devolucion d ON d.fletero_id = f.id AND d.transferencia_filial is not true ");
    sb.append("LEFT JOIN devolucion_estados de ON de.id = d.devolucion_estado_id ");
    sb.append("LEFT JOIN liquidacion l ON l.id = d.liquidacion_id ");
    sb.append("LEFT JOIN liquidacion_estado le ON le.id = l.liquidacion_estado_id ");
    sb.append("LEFT JOIN devolucion_detalle dd ON dd.devolucion_id = d.id ");
    sb.append("LEFT JOIN retorno r ON r.gc_fletero_id = f.id ");
    sb.append("LEFT JOIN retorno_estados re ON re.id = r.retorno_estado_id ");
    sb.append("LEFT JOIN liquidacion lr ON lr.id = r.liquidacion_id ");
    sb.append("LEFT JOIN liquidacion_estado ler ON ler.id = lr.liquidacion_estado_id ");
    sb.append("LEFT JOIN activos_entrada ae ON ae.gc_fletero_id = f.id ");
    sb.append("LEFT JOIN activos_entrada_detalle aed ON aed.activos_entrada_id = ae.id ");
    sb.append("LEFT JOIN activos_entrada_estados aee ON aee.id = ae.activos_entrada_estado_id ");
    sb.append("LEFT JOIN liquidacion lae ON lae.activos_entrada_id = ae.id ");
    sb.append("LEFT JOIN liquidacion_estado leae ON leae.id = lae.liquidacion_estado_id ");
    sb.append("WHERE 1=1 ");
    sb.append("AND ( ");
    sb.append("(le.codigo = '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"' OR le.codigo IS NULL) ");
    sb.append("AND ( ");
    sb.append("(de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.DERRAME_LABORATORIO.CODIGO+"' ");
    sb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.STOCK_LABORATORIO.CODIGO+"' ");
    sb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO+"') ");
    sb.append("AND dd.cantidad_documentada != dd.cantidad_verificada ");
    sb.append(") ");
    sb.append(") OR ( ");
    sb.append("ler.codigo = '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"' OR ler.codigo IS NULL ");
    sb.append("AND re.codigo = '"+RETORNO.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"' ");
    sb.append(") OR ( ");
    sb.append("(leae.codigo = '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"' OR leae.codigo IS NULL) ");
    sb.append("AND aee.codigo = '"+ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"' AND aed.cantidad_documentada > aed.cantidad_verificada_deposito ");
    sb.append(") ");
    sb.append("ORDER BY f.nro_movil asc ");
    return sb.toString();
}

async function getFleterosLiquidacionSelect2(){
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    passData.query = getFleteroQuery();
    var resultList = await getDataFromQueryAjax(urlStr, passData)
    var retornosMotivosSelect2Element = document.getElementById("fleteroSelectId");
    var columnsList = ["result"];
    setResultListInSelect2(retornosMotivosSelect2Element, resultList, columnsList)
}

async function loadActivosEntradaCantidadesLiquidacion(){
    var urlStr = await getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();

    sb.append("SELECT CASE WHEN le.id is null THEN (SELECT le1.id FROM liquidacion_estado le1 WHERE le1.codigo = '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"') ELSE le.id END, ");
    sb.append("CASE WHEN le.descripcion is null THEN (SELECT le1.descripcion FROM liquidacion_estado le1 WHERE le1.codigo = '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"') ");
    sb.append("ELSE le.descripcion END, ");
    sb.append("CASE WHEN le.codigo is null THEN '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"' ELSE le.codigo END as liquidacion_estado_codigo, ");
    sb.append("count(*) as cantidad ");
    sb.append("FROM activos_entrada ae ");
    sb.append("join activos_entrada_estados aee on aee.id = ae.activos_entrada_estado_id ");
    sb.append("left join liquidacion l on l.id = ae.liquidacion_id ");
    sb.append("left join liquidacion_estado le on le.id = l.liquidacion_estado_id ");
    sb.append("LEFT JOIN ");
    sb.append("(SELECT aed1.activos_entrada_id, count(aed1.*) as cant_dif ");
    sb.append("FROM activos_entrada_detalle aed1 where aed1.cantidad_documentada > aed1.cantidad_verificada_deposito ");
    sb.append("group by aed1.activos_entrada_id) t1 ON t1.activos_entrada_id = ae.id ");
    sb.append("WHERE 1=1 ");
    sb.append("AND aee.codigo = '"+ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"' ");
    sb.append("AND t1.cant_dif > 0 ");
    sb.append("GROUP BY le.id, le.codigo, le.descripcion order by le.id asc ");

    console.log("THIS: sb.toString()_: "+sb.toString());
    passData.query = sb.toString();
    var dtoList = await getDataFromQueryAjax(urlStr, passData);
    var retornosEstadosMap = new Map();
    retornosEstadosMap.set(LIQUIDACION.ESTADO.PENDIENTE.CODIGO, ["activosEntradaPendienteAprobacionCantidadId", "activosEntradaPendienteAprobacionSumatoriaMontosId"])
    retornosEstadosMap.set(LIQUIDACION.ESTADO.APROBADO.CODIGO, ["activosEntradaAprobadosPorRegistroCantidadId", "activosEntradaAprobadosSumatoriaMontosId"])
    retornosEstadosMap.set(LIQUIDACION.ESTADO.NO_FACTURADO.CODIGO, ["activosEntradaRechazadosCantidadId", "activosEntradaRechazadosSumatoriaMontosId"])
    jQuery("#activosEntradaPendienteAprobacionCantidadId").html("0");
    jQuery("#activosEntradaAprobadosPorRegistroCantidadId").html("0");
    jQuery("#activosEntradaRechazadosCantidadId").html("0");
    var cantidadMap = new Map();
    for(let i = 0; i < dtoList.length; i++){
        let dto = dtoList[i];
        if(dto.id == null && dto.descripcion == null && dto.liquidacion_estado_codigo == null){
            dto.liquidacion_estado_codigo = LIQUIDACION.ESTADO.PENDIENTE.CODIGO;
            dto.cantidad = parseInt(cantidadMap.get(LIQUIDACION.ESTADO.PENDIENTE.CODIGO))+parseInt(dto.cantidad)
        }
        let cantidadElemenId = retornosEstadosMap.get(dto.liquidacion_estado_codigo)[0];
        cantidadMap.set(dto.liquidacion_estado_codigo, dto.cantidad)

        jQuery("#"+cantidadElemenId).html(parseInt(cantidadMap.get(dto.liquidacion_estado_codigo)));
    }
}