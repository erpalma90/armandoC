function initJsPage(){
    // loadFleterosSelect2Index();
    loadPendienteDeAprobacionCantidad();
    loadAprobadosCantidad();
    loadRechazadosCantidad();
    loadRechazadosPorDepositoCantidad();
    loadRetornosCantidadesRegistro();
    loadSobrantesCantidadesRegistro();
    loadActivosEntradaCantidadesRegistro();

    $("#showApprovedPendingModalId").on('hidden.bs.modal', function() {
        //alert("Cerrado")
        //dataTable.clear();
        //dataTable = null;
    });

}

function loadSiteWrapper(){
    let siteWrapperList = [];
    siteWrapperList.push("indexView")
    /*
    siteWrapperList.push("control-sidebar");
    siteWrapperList.push("main-footer");
    siteWrapperList.push("mainSidebarContainer");
    siteWrapperList.push("nav-bar");
    siteWrapperList.push("content-wrapper");
    */
    var path =window.location.pathname;
    let basePath = "web-app/views/indexView"
    for(var x = 0; x < siteWrapperList.length; x++){
        let currentWrapperElement = siteWrapperList[x];
        let currentPath = basePath+"/"+currentWrapperElement+".html";

        jQuery.get(currentPath, function(currentHtml) {
            jQuery("#"+currentWrapperElement).html(currentHtml);
        });
    }
}





var devolucionesDtoList = null;

var devolucionesMap = new Map();
devolucionesMap.set(1, null);
devolucionesMap.set(2, null);





async function loadRechazadosCantidad(){
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var passDataSb = new StringBuilder();
    passDataSb.append("SELECT count(*) FROM devolucion ")
    passDataSb.append("WHERE devolucion_estado_id = ")
    passDataSb.append("(SELECT id FROM devolucion_estados WHERE codigo = '");
    passDataSb.append(DEVOLUCION.ESTADOS.NO_REGISTRADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO+"') ");
    passDataSb.append("AND fletero_id IS NOT NULL ");
    passData.query = passDataSb.toString();

    var cantidadDevolucionPendienteAprobacionList = await getDataFromQueryAjax(urlStr, passData)
    var cantidad = cantidadDevolucionPendienteAprobacionList[0].count;
    jQuery("#rechazadoPorRegistroCantidadId").html(cantidad);
}



var dt2 = null;
function showRechazados(){
    //jQuery("#tbId").children().remove();
    if(dt2 != null){
        //Table1 = $('#timesheet-table').DataTable({})
        dt2.clear();
        dt2.destroy()


    }
    var tBodyElement = getById("tbId")
    for(var x = 0; x < 12; x++){
        var newTr = document.createElement("tr");
        var newTd = document.createElement("td")
        newTr.appendChild(newTd)
        newTd.appendChild(document.createTextNode(x));
        tBodyElement.appendChild(newTr)
    }
    /*
    if(dt2 == null){
        //jQuery.noConflict();
        dt2 = jQuery("#dtId").DataTable()
    }
    */
    dt2 = jQuery("#dtId").DataTable()
    //dt2.draw();
    jQuery("#showRechazadosModalId").modal();
}

async function loadRetornosCantidadesRegistro(){
    var urlStr = await getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select registro_estado, sum(cantidad1) as cantidad from ( ");
    sb.append("SELECT ");
    sb.append("CASE WHEN re.estado_actual = 'RECHAZADO DEPOSITO' THEN 'RECHAZADO DEPOSITO' ELSE re.registro_estado END, count(*) as cantidad1 ");
    sb.append("FROM retorno r ");
    sb.append("left join retorno_estados re on re.id = r.retorno_estado_id ");
    sb.append("group by re.registro_estado, re.estado_actual ");
    sb.append(") test group by registro_estado ");



    passData.query = sb.toString();
    var dtoList = await getDataFromQueryAjax(urlStr, passData);
    var retornosEstadosMap = new Map();
    retornosEstadosMap.set("PENDIENTE REGISTRO", ["retornoPendienteAprobacionCantidadId"])
    retornosEstadosMap.set("APROBADO REGISTRO", ["retornosAprobadosPorRegistroCantidadId"])
    retornosEstadosMap.set("RECHAZADO DEPOSITO", ["retornosRechazadosCantidadId"])
    jQuery("#retornoPendienteAprobacionCantidadId").html("0");
    jQuery("#retornosAprobadosPorRegistroCantidadId").html("0");
    jQuery("#retornosRechazadosCantidadId").html("0");
    var cantidadMap = new Map();
    var sumatoriaMap = new Map();
    for(let i = 0; i < dtoList.length; i++){
        let dto = dtoList[i];
        let cantidadElemenId = retornosEstadosMap.get(dto.registro_estado)[0];
        jQuery("#"+cantidadElemenId).html(dto.cantidad);
    }
}

async function loadSobrantesCantidadesRegistro(){
    var urlStr = await getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select registro_estado, sum(cantidad1) as cantidad from ( ");
    sb.append("SELECT ");
    sb.append("CASE WHEN se.estado_actual = 'RECHAZADO DEPOSITO' THEN 'RECHAZADO DEPOSITO' ELSE se.registro_estado END, count(*) as cantidad1 ");
    sb.append("FROM sobrante s ");
    sb.append("left join sobrante_estados se on se.id = s.sobrante_estados_id ");
    sb.append("group by se.registro_estado, se.estado_actual ");
    sb.append(") test group by registro_estado ");


    passData.query = sb.toString();
    var dtoList = await getDataFromQueryAjax(urlStr, passData);
    var sobrantesEstadosMap = new Map();
    sobrantesEstadosMap.set("PENDIENTE REGISTRO", ["sobrantePendienteAprobacionCantidadId"])
    sobrantesEstadosMap.set("APROBADO REGISTRO", ["sobranteAprobadosPorRegistroCantidadId"])
    sobrantesEstadosMap.set("RECHAZADO DEPOSITO", ["sobranteRechazadosCantidadId"])
    jQuery("#sobrantePendienteAprobacionCantidadId").html("0");
    jQuery("#sobranteAprobadosPorRegistroCantidadId").html("0");
    jQuery("#sobranteRechazadosCantidadId").html("0");
    var cantidadMap = new Map();
    var sumatoriaMap = new Map();
    for(let i = 0; i < dtoList.length; i++){
        let dto = dtoList[i];
        if(sobrantesEstadosMap.get(dto.registro_estado) != null && sobrantesEstadosMap.get(dto.registro_estado) != undefined){
            let cantidadElemenId = sobrantesEstadosMap.get(dto.registro_estado)[0];
            jQuery("#"+cantidadElemenId).html(dto.cantidad);
        }

    }
}


async function loadActivosEntradaCantidadesRegistro(){
    var urlStr = await getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();

    sb.append("select registro_estado, sum(cantidad1) as cantidad from ( ")
    sb.append("SELECT ");
    sb.append("CASE WHEN aee.estado_actual = 'RECHAZADO DEPOSITO' THEN 'RECHAZADO DEPOSITO' ELSE aee.registro_estado END, count(*) as cantidad1 ");
    sb.append("FROM activos_entrada ae ");
    sb.append("left join activos_entrada_estados aee on aee.id = ae.activos_entrada_estado_id ");
    sb.append("group by aee.registro_estado, aee.estado_actual) test group by registro_estado ");


    passData.query = sb.toString();
    var dtoList = await getDataFromQueryAjax(urlStr, passData);
    var retornosEstadosMap = new Map();
    retornosEstadosMap.set("PENDIENTE REGISTRO", ["activosEntradaPendienteAprobacionCantidadId", "activosEntradaPendienteAprobacionSumatoriaMontosId"])
    retornosEstadosMap.set("APROBADO REGISTRO", ["activosEntradaAprobadosPorRegistroCantidadId", "activosEntradaAprobadosSumatoriaMontosId"])
    retornosEstadosMap.set("RECHAZADO DEPOSITO", ["activosEntradaRechazadosCantidadId", "activosEntradaRechazadosSumatoriaMontosId"])
    jQuery("#activosEntradaPendienteAprobacionCantidadId").html("0");
    jQuery("#activosEntradaAprobadosPorRegistroCantidadId").html("0");
    jQuery("#activosEntradaRechazadosCantidadId").html("0");
    var cantidadMap = new Map();
    var sumatoriaMap = new Map();
    for(let i = 0; i < dtoList.length; i++){
        let dto = dtoList[i];
        if(retornosEstadosMap.get(dto.registro_estado) != null && retornosEstadosMap.get(dto.registro_estado) != undefined){
            let cantidadElemenId = retornosEstadosMap.get(dto.registro_estado)[0];
            jQuery("#"+cantidadElemenId).html(dto.cantidad);
        }
    }
}