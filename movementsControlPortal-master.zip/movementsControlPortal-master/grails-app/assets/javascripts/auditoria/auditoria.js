

function insertarAuditoria(data){
    var sb = new StringBuilder();
    sb.append("INSERT INTO auditoria(id, version, fecha_auditoria, accion, dominio_id, observacion, dominio, user_id, datos, estado) ");
    sb.append("VALUES (nextval('auditoria_seq'), 0, current_timestamp, ?, ?, ?, ?, ?, ?, ?) ")

    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosInsertarAuditoria(data);
    passData.argsToSet = JSON.stringify(argsToSet);
    var urlStr = getDynamicExecuteUpdateUrl();
    postDataFromQueryAjax(urlStr, passData, null);
}

function getDatosInsertarAuditoria(data){
    let columnsMap = new Map();
    columnsMap.set(1, [data.action, DATABASE.DATA_TYPE.VARCHAR])
    columnsMap.set(2, [data.dominioId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(3, [data.observacion, DATABASE.DATA_TYPE.VARCHAR])
    columnsMap.set(4, [data.dominio, DATABASE.DATA_TYPE.VARCHAR])
    columnsMap.set(5, [data.userId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(6, [data.datos, DATABASE.DATA_TYPE.VARCHAR])
    columnsMap.set(7, [data.estado, DATABASE.DATA_TYPE.VARCHAR])
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;
}