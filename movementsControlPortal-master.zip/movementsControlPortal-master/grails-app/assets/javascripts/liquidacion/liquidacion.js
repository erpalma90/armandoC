function modalConfirmFacturarRetorno(){
    //todo acenturion
    var stockRegresoIsEqualFlag = validateExistDiffStockRegreso();
    var title;
    var text;
    var icon;
    var confirmButtonText;
    if(stockRegresoIsEqualFlag == true){
        title = "Estas seguro? "
        text = "Estas seguro de cambiar el estado a Facturado?";
        icon = 'warning';
        confirmButtonText = "Si, facturado";
    }else{
        title = "Existen productos con cantidades no coincidentes"
        text = "Estas seguro de cambiar el estado a Facturado?. Esta acción sera notificada al Jefe inmediato.";
        icon = 'error';
        confirmButtonText = "Si, facturado";
    }

    acceptOrCancellModal(title, text ,icon , confirmButtonText, retornoFacturado);
}

function retornoFacturado(){
    liquidacionChangeStatusRetorno(LIQUIDACION.ESTADO.APROBADO.CODIGO);
}



async function liquidacionChangeStatusRetorno(newStatus, observation){
    showSpinner();
    var preciosUnit = document.getElementsByClassName("precioUnitarioClass");
    var urlStr = getUpdateRetornoLiquidacionStatusURL();
    var passData = new Object();
    passData.id = getRetornoId();
    passData.liquidacionEstadoCodigo = newStatus;
    if(observation == null || observation == undefined){
        observation = "";
    }
    passData.observacion = observation.trim();
    await ajaxPutData(urlStr, passData, reloadThisPage);
}

function validacionDeNoFacturarRetorno(){
    jQuery("#noFacturarModalRetornoId").modal();
    var correoDepositoSupervisor = getConfigurationValueFromKey("liquidacion.supervisor.correo.destinatario");
    jQuery("#correoNotificacionDivId").html(correoDepositoSupervisor);
    //actualizacionDeEstado(2);
}


async function noFacturarRetornoYEnviarCorreo(){
    var motivoRec = getById("motivoNoFacturadoLiquidacion").value
    if(motivoRec != null && motivoRec != ""){
        showSpinner();
        liquidacionChangeStatusRetorno(LIQUIDACION.ESTADO.NO_FACTURADO.CODIGO, motivoRec);
    }else{
        toastTr('warning', 'Advertencia', 'Debe describir el motivo de la no facturacion');
    }
}

function loadCantidadesRetornadasInformeGC(){
    var dtoList = getCantidadesStockRegresoGC();
    for(var i =0; i < dtoList.length; i++){
        var dto = dtoList[i];
        //alert(dto.producto_id+" - "+dto.cantidad_retornada)
        var element = getById("cantidadRetornoGcId-"+dto.producto_id);
        if(element != null && element != undefined){
            var cantidadStockDeRegresoGc = element.getAttribute("attr-cantidadStockDeRegresoGc")
            if(cantidadStockDeRegresoGc != null && cantidadStockDeRegresoGc != undefined &&
                cantidadStockDeRegresoGc.trim() != ""){
                dto.cantidad_retornada = cantidadStockDeRegresoGc;
            }
            jQuery(element).html(dto.cantidad_retornada);
            var retornoDetalleId = element.getAttribute("attr-retornoDetalleId");
            var cantidadDocumentadaRet = element.getAttribute("attr-cantidadDocumentadaRet");
            if(parseInt(cantidadDocumentadaRet) != parseInt(dto.cantidad_retornada)){
                //var trElement = getById(retornoDetalleId)
                //trElement.classList.add("bg-danger");
                element.classList.add("bg-danger")
                swalNotification('top-center', 'warning', 'Existen productos con cantidades no coincidentes.', 2000);
            }
        }
    }
}
function getCantidadesStockRegresoGC(){
    var fleteroId = getFleteroId();
    var sb = new StringBuilder();
    sb.append("SELECT d.Descripcion as Fletero, s.[ID Productos] as producto_id, s.Cantidad as cantidad_retornada ");
    sb.append("FROM stk_stock s ");
    sb.append("INNER JOIN STK_Depositos d ON s.[ID Sucursales] = d.[ID Sucursales] AND s.[ID Depositos] = d.[ID Depositos] ");
    sb.append("INNER JOIN VTA_Fleteros vf ON vf.[Id Depositos] = d.[ID Depositos] ");
    sb.append("WHERE 1=1 ");
    sb.append("AND d.[Tipo Deposito] = 'Fleteros' ");
    sb.append("AND (s.[Cantidad Descargada] - s.Cantidad <> 0 OR s.[Cantidad Descargada] = s.Cantidad) ");
    sb.append("AND vf.[Id Fleteros] = "+fleteroId+" ");
    sb.append("AND d.[ID Sucursales] = 1 ");
    sb.append("AND s.Cantidad <> 0 ")
    sb.append("ORDER BY d.Descripcion, s.[ID Productos] ");

    //jQuery("#facturaNroSelect2Id").val()
    var urlStr = getGetDataFromQueryAndPsInGCURL();
    var passData = new Object();
    passData.query = sb.toString();
    var dtoList = getDataFromQueryAjax(urlStr, passData)
    return dtoList;
}
function validateExistDiffStockRegreso(){
    var dtoList = getCantidadesStockRegresoGC();
    var map = new Map();
    for(var x = 0; x < dtoList.length; x++){
        var dto = dtoList[x];
        map.set(dto.producto_id, dto.cantidad_retornada);
    }

    var cantidadesElementsList = document.getElementsByClassName("cantidadesClass");
    var equals = true;
    for(var i =0; i < cantidadesElementsList.length; i++){
        var element = cantidadesElementsList[i];
        var cantidadDocumentadaRet = element.getAttribute("attr-cantidadDocumentadaRet");
        var cantidadStockDeRegresoGc = map.get(element.getAttribute("attr-gcProductosId"));
        if(parseInt(cantidadDocumentadaRet) != parseInt(cantidadStockDeRegresoGc)){
            equals = false;
            break;
        }
    }
    return equals;
}


document.querySelector("#buscar").onkeyup = function(){
    $TableFilter("#tabla", this.value);
}

$TableFilter = function(id, value){
    var rows = document.querySelectorAll(id + ' tbody tr');

    for(var i = 0; i < rows.length; i++){
        var showRow = false;

        var row = rows[i];
        row.style.display = 'none';

        for(var x = 0; x < row.childElementCount; x++){
            if(row.children[x].textContent.toLowerCase().indexOf(value.toLowerCase().trim()) > -1){
                showRow = true;
                break;
            }
        }

        if(showRow){
            row.style.display = null;
        }
    }
}

function editFleteroRetornos(retornoId, nroCamion){
    jQuery("#reassign-fletero-liquidacion-modal-id").modal();

}
function editFechaAsignacionRetorno(){
    jQuery("#reassign-fechaAsignacion-liquidacion-modal-id").modal();
}
function getFleterosPendientesDeRendicionSobrantesWhereNroCamionWhitLimit(){
    var url = getGetDataFromQueryAndPsInGCURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT TOP 300 f.[Id Fleteros] as id, cast(f.[Numero Camion] as varchar)+'-'+cast(f.nombre as varchar) AS result  ");
    sb.append("FROM [VTA_C Comprobantes de Ventas] cv ");
    sb.append("INNER JOIN vta_fleteros f ON ");
    sb.append("cv.[id sucursales] = f.[id sucursales] AND ");
    sb.append("cv.[id fleteros] = f.[id fleteros] ");
    sb.append("WHERE cv.Status = '00' AND cv.[Fecha] > '01/01/2021' ");
    sb.append("AND cv.[fecha cierre] IS NULL ");
    passData.query = sb.toString();
    var fleteroSelect2Element = jQuery('#reassignFleteroSelect2Id');
    setSelect2WhitLimit(fleteroSelect2Element, sb.toString(), setLiquidacionReassignFleteroData, getLiquidacionReassignFleteroFilterQuery, url)
    fleteroSelect2Element.on('change', function (e) {

    });
}

function setLiquidacionReassignFleteroData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getLiquidacionReassignFleteroFilterQuery(query, filter){
    var numeroCamion = getNroCamion();
    query = query + "AND f.[Numero Camion] = "+numeroCamion+" ";
    if(filter != undefined && filter != null && filter.trim() != ''){
        query = query+" AND cast(f.[Numero Camion] as varchar)+'-'+cast(f.nombre as varchar) like ? "
    }
    return query+" GROUP BY f.[Id Fleteros], f.[Numero Camion], f.nombre ORDER BY result ASC ";
}



function updateRetornoFleteroInLiquidacion(){
    var newGcFleteroId = jQuery("#reassignFleteroSelect2Id").val();
    var currentGcFleteroId = getFleteroId();
    if(newGcFleteroId != null && newGcFleteroId != undefined && newGcFleteroId.trim() != ""){
        if(newGcFleteroId != currentGcFleteroId){
            var fechaAsignacion = getFechaAsignacion();
            fechaAsignacion = formatterDate(fechaAsignacion, 'DD/MM/yyyy')
            var gcFleteroId = jQuery("#reassignFleteroSelect2Id").val();
            var passData = getRetornoFleteroPassDataUpdate(gcFleteroId, fechaAsignacion);
            var urlStr = getDynamicExecuteUpdateUrl();
            ajaxPutData(urlStr, passData, reloadThisPage)
        }else{
            swalNotification('top-center', 'warning', 'El fletero seleccionado, es el actual del retorno.', 2000);
        }
    }else{
        swalNotification('top-center', 'warning', 'Seleccionar fletero para reasignar', 2000);
    }


}

function getRetornoFleteroPassDataUpdate(gcFleteroId, fechaAsignacion){
    var sb = new StringBuilder();
    sb.append("UPDATE retorno SET gc_fletero_id=?, user_last_updated_date=current_timestamp, ");
    sb.append("user_last_updated_id=?, ");
    sb.append("fecha_asignacion=? ")
    sb.append("WHERE id = ? ");

    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosSobranteUpdate(gcFleteroId, fechaAsignacion);
    passData.argsToSet = JSON.stringify(argsToSet);

    return passData;
}

function getDatosSobranteUpdate(gcFleteroId, fechaAsignacion){
    var retornoId = getRetornoId();
    var currentUserId = getLoggedUserId();


    var columnsMap = new Map();
    columnsMap.set(1, [gcFleteroId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(2, [currentUserId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(3, [fechaAsignacion, DATABASE.DATA_TYPE.TIMESTAMP]);
    columnsMap.set(4, [retornoId, DATABASE.DATA_TYPE.BIGINT]);
    obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;
}



function updateRetornoFechaAsignacionInLiquidacion(){
    var fechaAsignacion = getFechaAsignacion();
    fechaAsignacion = formatterDate(fechaAsignacion, 'DD/MM/yyyy')
    //var newFechaAsignacion = getById("fechaAsignacionDateId").value;
    var newFechaAsignacion = getFechaAsignacionFromGC();
    if(newFechaAsignacion != null){
        newFechaAsignacion = formatterDate(newFechaAsignacion, 'DD/MM/yyyy')
        if(newFechaAsignacion != null && newFechaAsignacion != undefined && newFechaAsignacion.trim() != ""){
            if(newFechaAsignacion != fechaAsignacion){
                var fleteroId = getFleteroId();
                var passData = getRetornoFleteroPassDataUpdate(fleteroId, newFechaAsignacion);
                var urlStr = getDynamicExecuteUpdateUrl();
                ajaxPutData(urlStr, passData, reloadThisPage)
            }else{
                swalNotification('top-center', 'warning', 'La fecha seleccionada, es la actual asignada al retorno.', 2000);
            }
        }else{
            swalNotification('top-center', 'warning', 'Seleccionar fecha para reasignar', 2000);
        }
    }else{
        swalNotification('top-center', 'warning', 'No se encuentra alguna fecha pendiente de liquidacion para este fletero.', 3000);
    }

}

function mostrarNotificacionDiferenciaCantidades(){
    var elementsList = document.getElementsByClassName("tdCantidadClassExistDiff-true");
    if(elementsList.length > 0){
        swalNotification('top-center', 'warning', 'Existen productos con cantidades no coincidentes.', 2000);
    }
}

function areYouShureUpdateFechaAsignacion(){
    var title = "Estas seguro? ";
    var text = "Estas seguro de actualizar la fecha de asignacion? ";
    var icon = 'warning'
    var confirmButtonText = "Si, actualizar";
    acceptOrCancellModal(title, text ,icon , confirmButtonText, updateRetornoFechaAsignacionInLiquidacion)

}

function getFechaAsignacionFromGC(){

    var fleteroId = jQuery("#fleteroSelectId").val();
    var sb = new StringBuilder();
    sb.append("SELECT cv.fecha, cv.[Id Fleteros], sr.Status ");
    sb.append("FROM [VTA_C Comprobantes de Ventas] cv ");
    sb.append("LEFT JOIN STK_Stock_Regreso_C sr ON ");
    sb.append("cv.[id sucursales] = sr.[id sucursales] AND ");
    sb.append("cv.[id depositos] = sr.[id depositos] AND ");
    sb.append("cv.Fecha = sr.[fecha] ");
    sb.append("WHERE cv.fecha BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()-1), 0) ");
    sb.append("AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE()-1)+1,0)) ");
    sb.append("AND cv.[Fecha Cierre] IS NULL ");
    sb.append("AND (sr.Status <> '00' or sr.Status is NULL) ");
    sb.append("AND cv.[Id Fleteros] = "+getFleteroId()+" ");
    sb.append("GROUP BY cv.fecha, cv.[Id Fleteros],sr.Status ");
    sb.append("ORDER BY cv.fecha ASC ");
    console.log("sb: "+sb.toString());
    var urlStr = getGetDataFromQueryInGCURL();
    var passData = new Object();
    passData.query = sb.toString();
    var list = getDataFromQueryAjax(urlStr, passData);
    var fecha = null;
    if(list[0] != null && list[0] != undefined){
        fecha = list[0].fecha
    }
    return fecha;
}

function revertirRetorno(){
    var motivoRevertirRetornoText = getById("revertirRetornoMovitoElementId").value;
    if(motivoRevertirRetornoText != null && motivoRevertirRetornoText != undefined && motivoRevertirRetornoText.trim() != ""){
        showSpinner();
        var urlStr = getRevertirRetornoUrl();
        var passData = new Object();
        passData.retornoId = getRetornoId();
        passData.motivoRevertirRetornoText = motivoRevertirRetornoText;
        ajaxGetData(urlStr, passData, resolveRevertirRetorno);
    }else{
        swalNotification('top-center', 'warning', 'El motivo no puede estar vacío', 2000);
    }
}

function resolveRevertirRetorno(data){
    var resumenComprobanteStockDto = JSON.parse(data);
    if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        //swalNotification('top-center', 'success', 'Realizado', 2000);
        reloadThisPage()
    }else if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_ERROR){
        hideSpinner();
        swalNotification('top-center', 'error', 'NO SE PUEDE EJECUTAR, CONSULTAR CON TI', 2000);
    }else{
        hideSpinner();
        swalNotification('top-center', 'warning', resumenComprobanteStockDto.message, 7000)
    }
}

function validacionDeRevertirRetorno(){
    jQuery("#revertirRetornoModalId").modal();
    //var correoDepositoSupervisor = getConfigurationValueFromKey("liquidacion.supervisor.correo.destinatario");
    //jQuery("#correoNotificacionDivId").html(correoDepositoSupervisor);
    //actualizacionDeEstado(2);
}