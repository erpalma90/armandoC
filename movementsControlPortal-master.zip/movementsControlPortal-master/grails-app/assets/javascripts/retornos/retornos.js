
//getGetDataFromQueryAndPsInGCURL
async function retornosMotivosSelect2(){
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    passData.query = "SELECT * FROM gc_motivo_retorno";
    var resultList = await getDataFromQueryAjax(urlStr, passData)
    var retornosMotivosSelect2Element = document.getElementById("retornosMotivosSelectId");
    var columnsList = ["descripcion"];
    setResultListInSelect2(retornosMotivosSelect2Element, resultList, columnsList)
}



function getFleteroWhitLimit(){
    //var url = getGetDataFromQueryAndPsInGCURL();
    var url = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    /*sb.append("SELECT TOP 300 f.[Id Fleteros] as id, cast(f.[Numero Camion] as varchar)+'-'+cast(f.nombre as varchar) AS result  ");
    sb.append("FROM [VTA_C Comprobantes de Ventas] cv ");
    sb.append("INNER JOIN vta_fleteros f ON ");
    sb.append("cv.[id sucursales] = f.[id sucursales] AND ");
    sb.append("cv.[id fleteros] = f.[id fleteros] ");
    sb.append("WHERE cv.Status = '00' AND cv.[Fecha] > '01/01/2021' ");
    sb.append("AND cv.[fecha cierre] IS NULL ");
    */

    sb.append("select f.id as id, fo.license_plate, fo.name, concat(fo.license_plate,'-',fo.name,'-',f.fletero) as result ");
    sb.append("from od_freight_order fo ");
    sb.append("join gc_fletero f on f.fletero = fo.driver_name ");
    sb.append("WHERE 1=1 ");


    passData.query = sb.toString();
    var fleteroSelect2Element = jQuery('#fleteroSelectId');
    setSelect2WhitLimit(fleteroSelect2Element, sb.toString(), setFleteroData, getFleteroFilterQuery, url)

    fleteroSelect2Element.on('change', function (e) {
        jQuery('#facturaNroSelect2Id').val(null).trigger('change');
    });
}





function getFacturaNroSelect2IdWhitLimit(){
    var url = getGetDataFromQueryAndPsInGCURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT TOP 100 ");
    sb.append("cast(cv.Origen as varchar)+'-'+cast(cv.[Id Sucursales] as varchar)+'-'+cast(cv.[Id Vendedores] as varchar) ");
    sb.append("+'-'+cast(cv.[Id Comprobantes Ventas] as varchar)+'-'+cast(cv.Numero as varchar) as id, ");
    sb.append("cast(cv.Numero as varchar) as result ");
    sb.append("FROM dbo.[VTA_C Comprobantes de Ventas] cv ");
    sb.append("INNER JOIN vta_fleteros f ON cv.[id sucursales] = f.[id sucursales] AND cv.[id fleteros] = f.[id fleteros] ");
    sb.append("WHERE 1=1 ");
    sb.append("AND cv.Status = '00' AND cv.[Fecha] > '01/01/2021' ");
    sb.append("AND cv.[fecha cierre] is null ");

    passData.query = sb.toString();

    var facturaSelect2Element = jQuery('#facturaNroSelect2Id');
    setSelect2WhitLimit(facturaSelect2Element, sb.toString(), setGCFacturaData, getGcFacturaFilterQuery, url)

    facturaSelect2Element.on('change', async function (e) {
        $('#productMultiSelect2Id').val(0).trigger('change');
        jQuery(".new-retorno-product").remove();

        let existRetornoProduct = document.getElementsByClassName("productsSelectedHiddenClass");
        for(let i = 0; i < existRetornoProduct.length; i++){
            let trElement = existRetornoProduct[i];
            let productoId = trElement.getAttribute("attr-product-id");
            await removeTrFromTrId("product-tr-id-"+productoId, productoId);
            console.log(i)
        }
    });
}


function setGCFacturaData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getGcFacturaFilterQuery(query, filter){
    var fleteroSelectedId = jQuery('#fleteroSelectId').val();

    if(fleteroSelectedId != null && fleteroSelectedId != undefined && fleteroSelectedId.trim() != ""){
        query = query+" AND f.[Id Fleteros] = "+fleteroSelectedId+" ";
    }
    if(filter != undefined && filter != null && filter.trim() != ''){
        query = query+" AND cv.Numero like ? "
    }

    return query+" ORDER BY cv.fecha ASC ";
}





var currentStepNumberVal = 1;
function nextRetornoBtnClicked(btnElement, nextStep){
    var currentStepNumber = currentStepNumberVal;
    var currentBodyStep = getById("bodyStep"+currentStepNumber+"Id");
    //attr-required
    var parentElementId = "bodyStep"+currentStepNumber+"Id";
    var requiredFieldsOkFlag = true;
    if(nextStep == true){
        requiredFieldsOkFlag = validateRequiredFields(parentElementId);
    }

    if(requiredFieldsOkFlag){
        currentBodyStep.style.display = "none";
        if(currentStepNumber == 1){

            //loadDatosDeFactura();
            //getFacturaDetalleMultiSelect2();
            getOrdenDeTransporteDetalle();
            //hideSpinner();
        }
        var stepMap = getNextOrPrevousStep(currentStepNumber)
        var newStepNumber
        if(nextStep){
            newStepNumber = stepMap.get("nextStep");
            getById("previousBtnId").style.display = ""
        }else{
            newStepNumber = stepMap.get("previousStep");
            if(newStepNumber == 1){
                btnElement.style.display = "none" //Se oculta el boton de atras cuando estamos en la primera parte
            }
        }
        var newBodyStep = getById("bodyStep"+newStepNumber+"Id");
        newBodyStep.style.display = "";
        var newStepMap =  getNextOrPrevousStep(newStepNumber)
        var title = newStepMap.get("title");
        jQuery("#stepsTitleId").html(title);

        stepLine(newStepNumber);
        btnElement.setAttribute("current-step", newStepNumber)
        currentStepNumberVal = newStepNumber;
    }

}
function getNextOrPrevousStep(currentStep){
    var nextStep = 1;
    var previousStep = 1;
    var title = "Identificacion"
    switch(currentStep) {
        case 1:
            nextStep = 2;
            previousStep = 1;
            title = "Identificacion"
            break;
        case 2:
            nextStep = 3
            previousStep = 1;
            title = "Productos"
            break;
        case 3:
            nextStep = 4
            previousStep = 2;
            title = "Observacion"
            break;
        default:
            alert("default nextStep")
    }
    var returnMap = new Map();
    returnMap.set("nextStep", nextStep)
    returnMap.set("previousStep", previousStep);
    returnMap.set("title", title);
    return returnMap;
}

function stepLine(currentStep){
    var disabledList;
    var stepElement = getById("step"+currentStep+"Id");
    stepElement.removeAttribute("disabled");
    stepElement.classList.remove("btn-default");
    stepElement.classList.add("btn-success");
    switch(currentStep) {
        case 1:
            getById("nextBtnId").style.display = ""
            getById("saveBtnId").style.display = "none"
            getById("updateBtnId").style.display = "none"
            disabledList = ["step2Id", "step3Id", "step4Id"];
            break;
        case 2:
            getById("nextBtnId").style.display = ""
            getById("saveBtnId").style.display = "none"
            getById("updateBtnId").style.display = "none"
            disabledList = ["step3Id", "step4Id"];
            break;
        case 3:
            getById("nextBtnId").style.display = "none"
            if(currentRetornoPageName()=='create'){
                getById("saveBtnId").style.display = ""
            }else if (currentRetornoPageName() == 'edit'){
                getById("updateBtnId").style.display = ""
            }
            break;
        default:
            alert("default nextStep")
    }
    if(disabledList != null && disabledList != undefined){
        for(var i = 0; i < disabledList.length; i++){
            var disabledId = disabledList[i];
            var element = getById(disabledId);
            if(element != null && element != undefined){
                element.setAttribute("disabled", "disabled");
                element.classList.remove("btn-success");
                element.classList.add("btn-default");
            }
        }
    }
}

function loadDatosDeFactura(){
    var facturaId = jQuery("#facturaNroSelect2Id").val();
    var dto = getGCFacturaFromFacturaId(facturaId)
    dto.Fecha = formatterDate(dto.Fecha, "DD-MM-YYYY")
    setDataInElementFromDto(dto);
    //loadDatosDeFacturaDetalles()
}

function getGCFacturaFromFacturaId(facturaId){
    var dto = null;
    try {
        var sb = new StringBuilder();
        sb.append("SELECT cv.Numero, cv.Fecha, ");
        sb.append("c.propietario, c.[ID Clientes] as codigo_cliente, c.[Razon Social], c.[Clasificacion 2] as zona, c.Ruc, c.[ID Vendedores], ");
        sb.append("v.Nombre as nombre_vendedor, c.[Calle]+'-'+c.[Entre Calle] as direccion, ");
        sb.append("c.[Clasificacion 6] as localidad, c.[Clasificacion 1] as distrito ");
        sb.append("FROM [VTA_C Comprobantes de Ventas] cv ");
        sb.append("INNER JOIN VTA_Clientes c ON c.[ID Clientes] = cv.[Id Clientes] ");
        sb.append("INNER JOIN VTA_Vendedores v ON v.[ID Vendedores] = cv.[ID Vendedores] ")
        sb.append("WHERE 1=1 ");
        sb.append("AND cv.Status = '00' AND cv.[Fecha] > '01/01/2021' ");
        sb.append("AND cv.[fecha cierre] is null ");
        //sb.append("AND cv.Numero = 14488 AND cv.[Id Clientes] = 76434 ");
        sb.append("AND cast(cv.Origen as varchar)+'-'+cast(cv.[Id Sucursales] as varchar)+'-'+cast(cv.[Id Vendedores] as varchar) ");
        sb.append("+'-'+cast(cv.[Id Comprobantes Ventas] as varchar)+'-'+cast(cv.Numero as varchar) = '"+facturaId+"' ");

        //jQuery("#facturaNroSelect2Id").val()
        var urlStr = getGetDataFromQueryAndPsInGCURL();
        var passData = new Object();
        passData.query = sb.toString();
        var dtoList = getDataFromQueryAjax(urlStr, passData)
        dto = dtoList[0];
    }catch (error){
        log.error("No se puede obtener la factura de GC")
        alert("No se puede obtener la factura de GC")
    }
    return dto;
}

function getFacturaDetalleGCQueryOld() {
    var facturaId = jQuery("#facturaNroSelect2Id").val();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT top 50 ");
    sb.append("cvd.[Id Productos] as id, ");
    //sb.append("p.[Clasificacion 3] as Tipo, p.[Clasificacion 4] as Sabor, ");
    sb.append("cvd.[Cantidad Envase] as cantidad_envase, um.[descripcion] as unidad_medida, um.[ID Unidades Medidas] as unidad_medida_id, ");
    sb.append("CAST(cvd.[Id Productos] as varchar)+'-'+p.Descripcion as result, ")
    sb.append("ump.Cantidad as cantidad_por_unidad_medida_minima, ");
    sb.append("cvd.[Total Linea ML] as total_linea_ml, cvd.[Importe Impuesto ML] as importe_impuesto, ");
    sb.append("cvd.[Precio Venta ML] as precio_venta_ml ");
    sb.append("FROM [VTA_C Comprobantes de Ventas] cv ");
    sb.append("INNER JOIN [VTA_D Comprobantes de Ventas] cvd ON ");
    sb.append("cv.Origen = cvd.Origen AND ");
    sb.append("cv.[Id Sucursales] = cvd.[Id Sucursales] AND ");
    sb.append("cv.[Id Vendedores] = cvd.[Id Vendedores] AND ");
    sb.append("cv.[Id Comprobantes Ventas] = cvd.[Id Comprobantes Ventas] AND ");
    sb.append("cv.Numero = cvd.Numero ");
    sb.append("INNER JOIN STK_Productos p ON ");
    sb.append("cvd.[Id Sucursales] = p.[ID Sucursales] AND cvd.[Id Productos] = p.[ID Productos] ");
    sb.append("INNER JOIN [STK_unidades de Medidas] um ON ");
    sb.append("cvd.[Id Sucursales] = um.[ID Sucursales] AND ");
    sb.append("cvd.[Id Unidades Medidas] = um.[ID Unidades Medidas] ");
    sb.append("LEFT JOIN [stk_um de productos] ump ON ump.[ID Productos] = p.[ID Productos] AND  ump.[ID Unidades Medidas] = um.[ID Unidades Medidas] ");
    sb.append("WHERE 1=1 ");
    sb.append("AND cv.Status = '00' AND cv.[Fecha] > '01/01/2021' ");
    sb.append("AND cv.[fecha cierre] is null ");
    //sb.append("AND cv.Numero = 14488 AND cv.[Id Clientes] = 76434 ");
    sb.append("AND cast(cv.Origen as varchar)+'-'+cast(cv.[Id Sucursales] as varchar)+'-'+cast(cv.[Id Vendedores] as varchar) ");
    sb.append("+'-'+cast(cv.[Id Comprobantes Ventas] as varchar)+'-'+cast(cv.Numero as varchar) = '"+facturaId+"' ");
    return sb.toString();
}
function setFacturaDetalleMultiSelect2Data(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}
function getFacturaDetalleMultiSelect2FilterQuery(query, filter){
    var selectedProducts = jQuery('#productMultiSelect2Id').val().toString()
    if(selectedProducts != undefined && selectedProducts != null && selectedProducts.trim() != ''){
        query = query+" AND CAST(cvd.[Id Productos] as varchar) NOT IN ("+selectedProducts+") ";
    }
    if(filter != undefined && filter != null && filter.trim() != ''){
        query = query+" AND CAST(cvd.[Id Productos] as varchar)+'-'+p.Descripcion like ? "
    }
    query = query+"GROUP BY cvd.[Id Productos], CAST(cvd.[Id Productos] as varchar)+'-'+p.Descripcion "
    query = query+"order by cvd.[Id Productos] asc ";
    console.log("query: "+query.toString())
    return query//+" GROUP BY f.[Id Fleteros], f.[Numero Camion], f.nombre ORDER BY result ASC ";
}

async function addProductsSelectedInRetornoTable(productId, sumaCantidadTotal, sumaPrecioUnitarioFacturado, sumaPrecioTotalFacturado){
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    //passData.query = "SELECT p.* FROM gc_productos p WHERE id in ("+idProductosSeleccionados+")";
    var sb = new StringBuilder();

    //todo acenturion
    sb.append("SELECT p.*, um_bot.unidad_medida as medida_und, um_caj.unidad_medida as medida_pack, ump.id as unidad_medida_producto ");
    sb.append("FROM gc_unidad_medida_productos ump ");
    sb.append("JOIN gc_productos p on p.id = ump.gc_productos_id ");
    sb.append("LEFT JOIN gc_unidad_medidas um_bot ON um_bot.id = ump.gc_unidad_medidas_id AND um_bot.unidad_medida IN ('Bot', 'Und', 'Lat', 'Tet') ");
    sb.append("LEFT JOIN gc_unidad_medidas um_caj ON um_caj.id = ump.gc_unidad_medidas_id AND um_caj.unidad_medida IN ('Caj', 'Pack') ");
    sb.append("WHERE 1=1 ");
    sb.append("AND p.id = "+productId+" ");
    sb.append("ORDER BY p.id ASC, um_bot.unidad_medida NULLS LAST ");
    sb.append("LIMIT 1 ");

    //sb.append("SELECT p.* FROM gc_productos p ");
    //sb.append("JOIN gc_unidad_medida_productos ump ON ump.gc_productos_id = p.id ");
    //sb.append("WHERE p.id in ("+productId+") ");
    //sb.append("AND gc_unidad_medidas_id = "+unidadDeMedidaIdFacturada);
    passData.query = sb.toString();
    var productList = await getDataFromQueryAjax(urlStr, passData)
    var productTableElement = getById("productTableBodyId");
    var originalTrElement = getById("productTableTrId");
    for(var x = 0; x < productList.length; x++){
        var dto = productList[x];
        var productoId = dto.id;
        //var unidadMedidaProductoIdFacturada = dto.unidad_medida_producto_id
        dto.removeId = "product-tr-id-"+productoId
        dto.cantidad = 0;
        dto.cantidadEnvase = sumaCantidadTotal;
        dto.precioUnitario = sumaPrecioUnitarioFacturado;
        dto.precioTotalFacturado = sumaPrecioTotalFacturado;
        dto.unidadDeMedidaSelect = "um-select"
        var productTr = getById("product-tr-id-"+productoId);
        if(productTr == null || productTr == undefined){
            var newTrElement = originalTrElement.cloneNode(true);
            newTrElement.style.display = "";
            newTrElement.setAttribute("attr-product-id", productoId)
            newTrElement.setAttribute("id", "product-tr-id-"+productoId);
            newTrElement.setAttribute("attr-cantidadEnvaseFacturada", dto.cantidadEnvase);
            newTrElement.setAttribute("attr-precioUnitarioFacturado", dto.precioUnitario);
            newTrElement.setAttribute("attr-precioTotalFacturado", dto.precioTotalFacturado)
            newTrElement.setAttribute("attr-unidadMedidaProductoIdFacturada", dto.unidad_medida_producto)
            newTrElement.setAttribute("class", "new-retorno-product")
            setDataInTableTd(newTrElement, dto)
            productTableElement.appendChild(newTrElement)

            var subProducto1 = dto.sub_producto1;
            var relacion1 = dto.relacion1;
            if(subProducto1 != null && subProducto1 != undefined && subProducto1.trim() != ""){
                var sumaCantidadTotalSubProducto1 = parseInt(sumaCantidadTotal)/parseInt(relacion1);
                await addProductsSelectedInRetornoTable(subProducto1, sumaCantidadTotalSubProducto1, 0, 0);
                await loadSelectUnidadDeMedida(subProducto1)
            }
            var subProducto2 = dto.sub_producto2;
            var relacion2 = dto.relacion2;
            if(subProducto2 != null && subProducto2 != undefined && subProducto2.trim() != ""){
                var sumaCantidadTotalSubProducto2 = parseInt(sumaCantidadTotal)/parseInt(relacion2);
                await addProductsSelectedInRetornoTable(subProducto2, sumaCantidadTotalSubProducto2, 0, 0);
                await loadSelectUnidadDeMedida(subProducto2)
            }
        }

    }
    //formatPageDataFromTags("attr-money-format");
}



function saveRetorno(){
    //var existFleteroRetornoEnFechaFlag = validateRetornoFleteroFechaExist();
    var existFleteroRetornoEnFechaFlag = 0;
    if(parseInt(existFleteroRetornoEnFechaFlag) == 0){
        showSpinner();
        var passDataList = [];
        var productoPrecioTotal = 0;
        var montoMap = new Map();
        montoMap.set("montoTotal", 0);
        passDataList.push(getRetornosDetailsPassDataInsert(montoMap))
        //var montoTotal = productPriceMap.get("TOTAL");
        var passData = getRetornoPassDataInsert(montoMap);
        passData.details = JSON.stringify(passDataList);
        var urlStr = getDynamicExecuteUpdateUrl();
        jQuery.ajax({
            url: urlStr,
            type: 'PUT',
            async:false,
            data: passData,
            success: function(data) {
                if(data != ERROR.SERVER_ERROR){
                    goToUrl(getIndexUrl(), getRetornoShowUrl()+"/"+data, true);
                }else{
                    alert('No se pudo guardar el retorno: e '+ERROR.SERVER_ERROR);
                    hideSpinner();
                }
            },
            error: function () {
                hideSpinner();
                alert('Error, no se pudo guardar el retorno');
            }
        });
    }else{
        var txtSb = new StringBuilder();
        txtSb.append("No se puede guardar este retorno, el fletero ya cuenta con un retorno creado en ");
        txtSb.append("la fecha.")
        swalNotification('top-center', 'warning', txtSb.toString(), 3000);
    }

}

function getRetornoPassDataInsert(montoMap){
    var sb = new StringBuilder();
    sb.append("INSERT INTO retorno(id, version, gc_fletero_id, ");
    sb.append("fecha_retorno, gc_cliente_id, factura_fecha, factura_nro, retorno_estado_id, ");
    sb.append("gc_motivo_retorno_id, user_creation_id, monto_total, user_creation_date, ");
    sb.append("observacion, gc_factura_id_concat, fecha_asignacion, od_freight_order_id) ");
    sb.append("VALUES (nextval('retorno_seq'), 0, ?, current_timestamp, ?, ?, ?, ?, ?, ?, ?, current_timestamp, ?, " +
        "?, current_date, ?) ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosRetornoInsert(montoMap);
    passData.argsToSet = JSON.stringify(argsToSet);
    return passData;
}

function getRetornosDetailsPassDataInsert(montoMap){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("INSERT INTO retorno_detalle(id, version, precio_unitario_ret, gc_unidad_medida_producto_ret_id, ");
    sb.append("retorno_id, precio_total_ret, gc_productos_id, gc_motivo_retorno_id, cantidad_documentada_ret, cantidad_facturada, ");
    sb.append("gc_unidad_medida_producto_facturado_id, precio_unitario_facturado, precio_total_facturado) ");
    sb.append("VALUES (nextval('retorno_detalle_seq'), 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosRetornoDetalleInsert(montoMap);
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosRetornoInsert(montoMap){
    var orderDeTransporteId = jQuery("#ordenTransporteSelectId").val();
    var facturaId = jQuery("#facturaNroSelect2Id").val();
    var gcFacturaDto = getGCFacturaFromFacturaId(facturaId);

    var userLastUpdatedId = getLoggedUserId();
    var gcFleteroId = getById("fleteroSeleccionadoId").value;
    var retornoEstadoPendienteId = getOneValueFromTableAndCode("id", "retorno_estados",
        RETORNO.ESTADO.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.CODIGO);
    var userCreationId = getLoggedUserId();
    var observacion = getById("observacionId").value;
    //var gcFacturaConcatId = facturaId;
    /*****/

    var montoTotal = redondeoMonedaLocal(montoMap.get("montoTotal"));
    var columnsMap = new Map();
    columnsMap.set(1, [gcFleteroId      , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(2, [null      , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(3, [null, DATABASE.DATA_TYPE.TIMESTAMP]);
    columnsMap.set(4, [null      , DATABASE.DATA_TYPE.VARCHAR]);
    columnsMap.set(5, [retornoEstadoPendienteId , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(6, [null , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(7, [userCreationId , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(8, [montoTotal , DATABASE.DATA_TYPE.DOUBLE]);
    columnsMap.set(9, [observacion , DATABASE.DATA_TYPE.VARCHAR]);
    columnsMap.set(10, [null, DATABASE.DATA_TYPE.VARCHAR]);
    columnsMap.set(11, [orderDeTransporteId, DATABASE.DATA_TYPE.BIGINT]);
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;

}

function getDatosRetornoDetalleInsert(montoMap){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let trProductosAgregados = document.getElementsByClassName("new-retorno-product");
    let devolucionDetallesList = [];
    for(let i = 0; i < trProductosAgregados.length; i++){
        var trProductElement = trProductosAgregados[i]
        let productId = trProductElement.getAttribute("attr-product-id")
        var precioUnitarioFacturado = parseFloat(trProductElement.getAttribute("attr-precioUnitarioFacturado"));
        var unidadMedidaProductoIdFacturada = trProductElement.getAttribute("attr-unidadMedidaProductoIdFacturada");
        var cantidadFacturada = trProductElement.getAttribute("attr-cantidadEnvaseFacturada");
        var precioTotalFacturado = trProductElement.getAttribute("attr-precioTotalFacturado");
        var precioUnitarioRetornado = precioUnitarioFacturado;
        var options = getById("unidadDeMedidaSelect-"+productId).options;
        var unidadDeMedidaText     = options[options.selectedIndex].text;
        var cantidadRetornada = parseInt(getById("cantidad-"+productId).value);
        if( unidadDeMedidaText.toUpperCase() == 'CAJ' ||
            unidadDeMedidaText.toUpperCase() == 'PACK'){
            cantidadRetornada = cantidadRetornada*options[options.selectedIndex].attributes[1].value
        }



        var precioTotalRet = parseFloat(cantidadRetornada*precioUnitarioRetornado);
        //var retornoMotivoId = jQuery("#retornosMotivosSelectId").val();
        let columnsMap = new Map();
        columnsMap.set(1, [precioUnitarioRetornado,         DATABASE.DATA_TYPE.DOUBLE]);
        columnsMap.set(2, [unidadMedidaProductoIdFacturada, DATABASE.DATA_TYPE.VARCHAR]);
        columnsMap.set(3, ['parentId',                      DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(4, [precioTotalRet,                  DATABASE.DATA_TYPE.DOUBLE])
        columnsMap.set(5, [productId,                       DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(6, [null,                            DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(7, [cantidadRetornada,               DATABASE.DATA_TYPE.INTEGER])
        columnsMap.set(8, [cantidadFacturada,               DATABASE.DATA_TYPE.INTEGER])
        columnsMap.set(9, [unidadMedidaProductoIdFacturada, DATABASE.DATA_TYPE.VARCHAR])
        columnsMap.set(10, [precioUnitarioFacturado,        DATABASE.DATA_TYPE.DOUBLE])
        columnsMap.set(11, [precioTotalFacturado,           DATABASE.DATA_TYPE.DOUBLE])
        montoMap.set("montoTotal", montoMap.get("montoTotal")+precioTotalRet);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        devolucionDetallesList.push(obj);
    }

    return devolucionDetallesList;

}




function loadSelectUnidadDeMedida(productId){
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    var sb = new StringBuilder();
    sb.append("SELECT ump.id, um.id as unidad_medida_id, um.unidad_medida, ump.cantidad as cantidad FROM gc_unidad_medida_productos ump ");
    sb.append("JOIN gc_unidad_medidas um ON um.id = ump.gc_unidad_medidas_id ");
    sb.append("WHERE ump.gc_productos_id = "+productId+" ");
    sb.append("order by um.unidad_medida asc ");
    passData.query = sb.toString();
    var list = getDataFromQueryAjax(urlStr, passData)
    var selectElement = getById("unidadDeMedidaSelect-"+productId);
    jQuery(selectElement).children().remove();
    for(var x = 0; x < list.length; x++){
        var dto = list[x];
        var unidadMedidaProductoId = dto.id;
        var unidadMedida = dto.unidad_medida;
        var cantidad = dto.cantidad;
        var unidadMedidaId = dto.unidad_medida_id
        var optionElement = document.createElement("option");
        optionElement.appendChild(document.createTextNode(unidadMedida));
        optionElement.value = unidadMedidaProductoId;
        optionElement.setAttribute("cantidad", cantidad);
        //document.getElementById("orange").selected = true;
        if(unidadMedida.toUpperCase() == 'BOT' || unidadMedida.toUpperCase() == 'TET' ||
            unidadMedida.toUpperCase() == 'LAT' || unidadMedida.toUpperCase() == 'UND'){
            optionElement.selected = true;
        }
        selectElement.append(optionElement);
    }
}

function maxProductQuantityValidity(element){
    var productoId = element.getAttribute("attr-id");
    var trElement = getById("product-tr-id-"+productoId)
    var cantidadEnvaseMinFacturada = trElement.getAttribute("attr-cantidadEnvaseFacturada");
    var currentValue = element.value;
    var cantUnidMedSelectedElement = getById("unidadDeMedidaSelect-"+productoId);
    var cantUnidMedSelectedValue = cantUnidMedSelectedElement[cantUnidMedSelectedElement.selectedIndex].getAttribute("cantidad");
    if((parseInt(currentValue)*parseInt(cantUnidMedSelectedValue)) > parseInt(cantidadEnvaseMinFacturada)){
        // element.value = "";
        // toastTr('warning', 'Alerta', "La cantidad retornada, no puede superar a la cantidad facturada");
    }
}
function changeUnidMedSelect(element){
    var productId = element.getAttribute("attr-id");
    var options = element.options;
    var unidadDeMedidaCantidad = options[options.selectedIndex].getAttribute("cantidad");
    console.log(unidadDeMedidaCantidad);
    maxProductQuantityValidity(getById("cantidad-"+productId));
}
/*
function addAllProductsInRetorno(){
    var url = getGetDataFromQueryAndPsInGCURL();
    var query = getFacturaDetalleGCQuery();
    var passData = new Object();
    passData.query = query;
    var data = ajaxGetData(url, passData, null);
    alert(data);
}
*/

function removeTrFromTrId(elementId, id){
    var productTrElement = document.getElementById(elementId);
    jQuery(productTrElement).remove();
    if(id != null && id != undefined){
        //jQuery('#productMultiSelect2Id').val(id).trigger("change");
        jQuery("#productMultiSelect2Id option[value='"+id+"']").remove();
    }
    if(productTrElement.classList.contains('existing-product')){
        retornoDetalleToDeleteList.push(productTrElement.getAttribute("attr-retorno-detalle-id"))
    }
}

async function actualizacionDeRetornoEstado(value, retornoId){
    showSpinner();
    try {
        var passData = new Object();
        passData.checkedList = retornoId;
        var newStatus = "";
        if(value == ACCION_APROBAR){
            if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
                newStatus = RETORNO.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO;
            }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
                newStatus = RETORNO.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO;
            }
        }else if(value == 3){ //ACCION_NO_REGISTRAR
            if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
                newStatus = DEVOLUCION.ESTADOS.NO_REGISTRADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO;
            }
        }else if(value == ACCION_RECHAZAR){
            if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
                newStatus = null;
            }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
                newStatus = RETORNO.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO;
            }
        }
        passData.nuevoEstadoRetorno = newStatus;
        var returnActualizacionDeEstado = await postDataFromQueryAjax(updateRetornoEstadoUrl(), passData, reloadThisPage);
        if(returnActualizacionDeEstado != ERROR.AJAX_RETURN){
            var obs = "";
            if(getById("motivoRechazoDeposito") != null){
                obs = getById("motivoRechazoDeposito").value;
            }else if(getById("motivoNoRegistroRegistroId") != null){
                obs = getById("motivoNoRegistroRegistroId").value;
            }
            let obj = new Object();
            obj.estado = passData.nuevoEstadoRetorno;
            obj.observacion = obs;
            await saveInAuditoria(retornoId, JSON.stringify(obj), passData.nuevoEstadoRetorno, "U", obs);



        }
    }catch (error){
        hideSpinner();
        alert("Error accionAprobar: "+error)
    }
}
function saveInAuditoria(id, estadoRetornoJson, estado, action, observation){
    var data = new Object();
    data.action = action;
    data.dominioId = id;
    data.observacion = observation;
    data.dominio = "Retorno"
    data.userId = getLoggedUserId();
    data.estado = estado;
    data.datos = estadoRetornoJson;
    insertarAuditoria(data);
}


function areYouShureRetornoAprovvedModalInShow(){
    var retornoId = getRetornoId();
    if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
        acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la aprobacion del retorno?" ,'warning' ,
            "Si, aprobar", function () {return actualizacionDeRetornoEstado(ACCION_APROBAR, retornoId)});
    }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
        acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la aprobacion del retorno?" ,'warning' ,
            "Si, aprobar", function () {return validateRetornosCantidadesVerificadas()});
    }
}

function validateRetornosCantidadesVerificadas(){
    var retornoId = getRetornoId();
    var cantidadesVerificadas = document.getElementsByClassName("cantidadVerificadaRetDepositoClass");
    var resultMap = new Map();
    if(cantidadesVerificadas != undefined && cantidadesVerificadas != null){
        for(var x = 0; x < cantidadesVerificadas.length; x++){
            var elemento = cantidadesVerificadas[x];
            var cantidadVerificadaRegistro = elemento.getAttribute("attr-cantidadDocumentadaRet");
            var cantidadVerificadaDeposito = elemento.getAttribute("attr-cantidadVerificadaRet");
            var retornoDetalleId = elemento.getAttribute("attr-retornoDetalleId");
            if(cantidadVerificadaRegistro != cantidadVerificadaDeposito){
                resultMap.set(retornoDetalleId, "Registro: "+cantidadVerificadaRegistro+" - Deposito: "+cantidadVerificadaDeposito);
            }
        }
    }
    if(resultMap.size == 0){
        swalNotification('top-center', "success", "Cantidades Coicidentes con Registro", 7000);
        actualizacionDeRetornoEstado(ACCION_APROBAR, retornoId);
    }else{
        //alert("Existe diferencia")
        var title = "La cantidad no coincide con la verificacion de Registro, favor volver a realizar el conteo, o aplicar rechazo del movimiento";
        swalNotification('top-center', "warning",
            title, 7000);
    }
}


function actualizarCantidadVerificadaRetornoDeposito(){
    //todo acenturion
    showSpinner();
    var cantVerificadaRetDepositoList = document.getElementsByClassName("cantidadVerificadaRetDepositoClass");
    var existChangeFlag = false;
    if(cantVerificadaRetDepositoList != undefined && cantVerificadaRetDepositoList != null){
        for(var x = 0; x < cantVerificadaRetDepositoList.length; x++){
            var elemento = cantVerificadaRetDepositoList[x];
            var cantidadNuevo = elemento.value
            var cantidadVerificadaDepositoActual = elemento.getAttribute("attr-cantidadVerificadaRet");
            var retornoDetalleId = elemento.getAttribute("attr-retornoDetalleId");
            var gcProductoId = elemento.getAttribute("attr-gcProductoId");
            var unidadDeMedidaProductoRet = elemento.getAttribute("attr-unidadMedidaProductoRet");
            var unidadDeMedidaSelectedElement = getById("unidadDeMedidaSelect-"+gcProductoId)
            var unidadDeMedidaSelectedValue = unidadDeMedidaSelectedElement.value;
            if(cantidadNuevo != null && cantidadNuevo != "" && parseInt(cantidadNuevo) >= 0){
                if((cantidadNuevo.toString() != cantidadVerificadaDepositoActual.toString()) ||
                    (unidadDeMedidaProductoRet != unidadDeMedidaSelectedValue)){
                    var options = unidadDeMedidaSelectedElement.options;
                    var unidadDeMedidaText     = options[options.selectedIndex].text;
                    var unidadDeMedidaId     = options[options.selectedIndex].value;
                    if(unidadDeMedidaId.toString() != unidadDeMedidaProductoRet.toString()){
                        //ESTE CALCULO DE UNIDAD DE MEDIDA POR CANTIDAD SOLO SE HARA CUANDO SEA DIFERENTE LA UNID RETORNOADO CON LO QUE SE FERIFICA
                        // EJ SOLO SI CAMBIE DE BOT A CAJ
                        //ESTO PARA CONTEMPLAR EL CASO DE CAJAS QUE POR DEFECTO SE TOMA EN MEDIDA CAJ
                        if( unidadDeMedidaText.toUpperCase() == 'CAJ' ||
                            unidadDeMedidaText.toUpperCase() == 'PACK'){
                            var cantidadVerif = parseInt(cantidadNuevo)*parseInt(options[options.selectedIndex].attributes[0].value);
                            cantidadNuevo = cantidadVerif;
                        }
                    }

                    updateVerificacionRetornoDetalle(retornoDetalleId, cantidadNuevo, "cantidad_verificada_ret", existChangeFlag);
                    existChangeFlag = true;
                }
            }
        }
    }
    if(!existChangeFlag){
        jQuery('#verificacion-deposito-modal-id').modal('toggle');
        hideSpinner();
    }
}

function updateVerificacionRetornoDetalle(retornoDetalleId, cantidad, columnToUpdate, existChangeFlag){
    var passData = new Object(); //getDevolucionDetailVerificacionUpdateData(devolucionDetalleId, cantidad, columnToUpdate);
    var passDataList = []
    if(!existChangeFlag){
        passDataList.push(getRetornoUpdateLastUserModified());
    }
    passDataList.push(getRetornoDetailVerificacionUpdateData(retornoDetalleId, cantidad, columnToUpdate));
    passData.parentId = getRetornoId();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                var urlStr = window.location;
                window.location = urlStr;
                //location.href = getDevolucionesShowUrl()+"/"+data;
            }else{
                alert('No se pudo guardar la devolucion: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo guardar la devolucion');
        }
    });
}

function getRetornoUpdateLastUserModified(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("UPDATE retorno SET user_last_updated_id = ?, user_last_updated_date = current_timestamp ");
    sb.append("WHERE id = ? ")
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosRetornoActualizacion();
    passData.argsToSet = argsToSet;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        passData = null;
    }
    return JSON.stringify(passData);
}

function getDatosRetornoActualizacion(){
    let detallesList = [];
    let columnsMap = new Map();
    var retornoId = getRetornoId();
    columnsMap.set(1, [getLoggedUserId(), DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(2, [retornoId,      DATABASE.DATA_TYPE.BIGINT])

    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    detallesList.push(obj);
    return detallesList;

}

function getRetornoDetailVerificacionUpdateData(retornoDetalleId, cantidad, columnToUpdate){
    var sb = new StringBuilder();
    sb.append("UPDATE retorno_detalle SET "+columnToUpdate+" = ? WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosActualizarRetornoVerificacion(retornoDetalleId, cantidad);
    passData.argsToSet = argsToSet;
    return JSON.stringify(passData);
}

function getDatosActualizarRetornoVerificacion(retornoDetalleId, cantidad){
    var list = [];
    var columnsMap = new Map();
    columnsMap.set(1, [cantidad, DATABASE.DATA_TYPE.INTEGER])
    columnsMap.set(2, [retornoDetalleId, DATABASE.DATA_TYPE.BIGINT])
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    list.push(obj)
    return list;
}

var dataTable = null;
async function showRetornoAudit(retornoId){
    if(dataTable != null){
        dt2.clear();
        dt2.destroy()
        //dataTable.fnDraw(false);
    }
    var cardElement = getById("cardBodyId")
    jQuery(cardElement).children().remove();

    var devolucionesTableElement = getById("auditoriaTableId");
    var newDevolucionesTableElement = devolucionesTableElement.cloneNode(true);
    newDevolucionesTableElement.setAttribute("id", "");
    newDevolucionesTableElement.style.display = "";

    cardElement.appendChild(newDevolucionesTableElement);
    var newTableElement = cardElement.getElementsByTagName("table")[0]
    newTableElement.setAttribute("id", "auditoriaTableId");
    var newTbodyElement = newTableElement.getElementsByTagName("tbody")[0];
    newTbodyElement.setAttribute("id", "auditoriaTbodyId");
    var newOriginalTrElement = newTbodyElement.getElementsByTagName("tr")[0];
    newOriginalTrElement.setAttribute("id", "auditoriaTableTrId");


    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select aj.*, u.username, r.authority from audit_json aj ");
    sb.append("join users u on u.id = aj.user_id ")
    sb.append("join users_roles ur on ur.users_id = u.id ");
    sb.append("join roles r on ur.roles_id = r.id ");
    sb.append("WHERE aj.table_id = '"+retornoId+"' AND table_name = 'retorno'  order by aj.date desc");

    passData.query = sb.toString();
    devolucionesDtoList = await getDataFromQueryAjax(urlStr, passData)
    var tbodyElement = getById("auditoriaTbodyId");
    var originalTrElement = getById("auditoriaTableTrId");
    var formatter= 'DD-MM-YYYY HH:mm';
    for(var x = 0; x < devolucionesDtoList.length; x++){
        var dto = devolucionesDtoList[x];
        dto.date = formatterDate(dto.date, "DD-MM-YYYY HH:mm:ss");
        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.id = "";
        newTrElement.style.display = "";
        newTrElement.setAttribute("class", "auditoriaTrGeneradoClass");
        setDataInTableTd(newTrElement, dto)
        tbodyElement.appendChild(newTrElement)
        getById("auditoriaTableTrId").style.display = 'none'
    }
    dt2 = jQuery("#auditoriaTableId").DataTable({
        "order": [],
        "columnDefs": [ {
            "targets"  : 'no-sort',
            "orderable": false,
        }]
    });
    jQuery("#showDevolucionAuditId").modal();
}

function getFacturaDetalleMultiSelect2(){
    //var url = getGetDataFromQueryAndPsInGCURL();
    var query = getFacturaDetalleGCQuery();
    var fleteroSelect2Element = jQuery('#productMultiSelect2Id');
    setSelect2WhitLimit(fleteroSelect2Element, query, setFacturaDetalleMultiSelect2Data, getFacturaDetalleMultiSelect2FilterQuery, url);
    fleteroSelect2Element.on("select2:select", async function (e) {
        var data = e.params.data.text;
        var productId = e.params.data.queryData.producto_id;
        var sumaCantidadTotal = e.params.data.queryData.sum_cantidad_total;
        var sumaPrecioUnitarioFacturado = e.params.data.queryData.sum_precio_unitario_facturado;
        var sumaPrecioTotalFacturado = e.params.data.queryData.sum_precio_total_facturado;

        await addProductsSelectedInRetornoTable(productId, sumaCantidadTotal, sumaPrecioUnitarioFacturado, sumaPrecioTotalFacturado);
        await loadSelectUnidadDeMedida(productId)
    });
    fleteroSelect2Element.on("select2:unselect", function (e) {
        var id = e.params.data.id;
        removeTrFromTrId("product-tr-id-"+id)
    });
}

function getFacturaDetalleGCQuery() {
    var fleteroId = jQuery("#fleteroSelectId").val();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT top 100 ");
    sb.append("cvd.[Id Productos] as producto_id, ");
    sb.append("cvd.[Id Productos] as id, ");
    sb.append("CAST(cvd.[Id Productos] as varchar)+'-'+p.Descripcion as result, ");
    sb.append("sum(cvd.[Cantidad Envase]*cvd.[Unidad Envase]) AS sum_cantidad_total, ");
    sb.append("(sum(cvd.[Importe Impuesto ML] + cvd.[Total Linea ML])/sum(cvd.[Cantidad Envase]*cvd.[Unidad Envase])) AS sum_precio_unitario_facturado, ")
    sb.append("sum(cvd.[Importe Impuesto ML] + cvd.[Total Linea ML]) AS sum_precio_total_facturado ");
    sb.append("FROM [VTA_C Comprobantes de Ventas] cv ");
    sb.append("INNER JOIN [VTA_D Comprobantes de Ventas] cvd ON cv.Origen = cvd.Origen AND cv.[Id Sucursales] = cvd.[Id Sucursales] AND ");
    sb.append("cv.[Id Vendedores] = cvd.[Id Vendedores] AND cv.[Id Comprobantes Ventas] = cvd.[Id Comprobantes Ventas] AND cv.Numero = cvd.Numero ");
    sb.append("INNER JOIN STK_Productos p ON cvd.[Id Sucursales] = p.[ID Sucursales] AND cvd.[Id Productos] = p.[ID Productos] ");
    sb.append("INNER JOIN VTA_Fleteros f ON cv.[Id Sucursales] = f.[Id Sucursales] AND cv.[Id Fleteros] = f.[Id Fleteros] ");
    sb.append("WHERE 1=1 ");
    sb.append("AND cv.Status = '00' AND cv.[Fecha] > '01/01/2021' AND cv.[Fecha Cierre] IS NULL ");
    sb.append("AND cv.[Id Fleteros] = "+fleteroId+" ");
    return sb.toString();
}

function getUnidadMinimaExistenteProducto(productoId){
    var sb = new StringBuilder();
    sb.append("SELECT p.id, p.producto, um_bot.unidad_medida as und, um_caj.unidad_medida as pack ");
    sb.append("FROM gc_unidad_medida_productos ump ");
    sb.append("JOIN gc_productos p on p.id = ump.gc_productos_id ");
    sb.append("LEFT JOIN gc_unidad_medidas um_bot ON um_bot.id = ump.gc_unidad_medidas_id AND um_bot.unidad_medida IN ('Bot', 'Und', 'Lat', 'Tet') ");
    sb.append("LEFT JOIN gc_unidad_medidas um_caj ON um_caj.id = ump.gc_unidad_medidas_id AND um_caj.unidad_medida IN ('Caj', 'Pack') ");
    sb.append("WHERE 1=1 ");
    sb.append("AND p.id = "+productoId+" ");
    sb.append("ORDER BY p.id ASC, um_bot.unidad_medida NULLS LAST ");
    sb.append("LIMIT 1 ");
}

function validateRetornoFleteroFechaExist(){
    var fleteroId = jQuery("#fleteroSelectId").val();
    var sb = new StringBuilder();
    sb.append("SELECT count(*) FROM retorno WHERE gc_fletero_id = "+fleteroId+" AND cast(fecha_retorno as DATE) = current_date ");
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    passData.query = sb.toString();
    var list = getDataFromQueryAjax(urlStr, passData);
    return list[0].count
}


function loadOrdenDeTransporte(){
    var url = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select fo.id as id, fo.license_plate, fo.name, ");
    sb.append("concat(fo.license_plate,'-',fo.name,'-',f.fletero) as result, ");
    sb.append("f.id as fletero_id, r.id as retorno_id ");
    sb.append("from od_freight_order fo ");
    sb.append("join gc_fletero f on f.fletero = fo.driver_name ");
    sb.append("left join retorno r on r.od_freight_order_id = fo.id ");
    sb.append("WHERE 1=1 ");
    sb.append("and r.id is null ");
    passData.query = sb.toString();
    var ordenDeTransporteSelect2Element = jQuery('#ordenTransporteSelectId');
    setSelect2WhitLimit(ordenDeTransporteSelect2Element, sb.toString(), setOrdenTransporteData, getOrdenDeTransporteFilterQuery, url)

    /*ordenDeTransporteSelect2Element.on('change', function (e) {
        jQuery('#facturaNroSelect2Id').val(null).trigger('change');
        var fleteroId = e.params.data.queryData.fletero_id;
        alert(fleteroId)
        getById("fleteroSeleccionadoId").value = fleteroId
    });*/

    ordenDeTransporteSelect2Element.on("select2:select", async function (e) {
        jQuery('#facturaNroSelect2Id').val(null).trigger('change');
        var fleteroId = e.params.data.queryData.fletero_id;
        getById("fleteroSeleccionadoId").value = fleteroId
    });

}

function setOrdenTransporteData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getOrdenDeTransporteFilterQuery(query, filter){
    if(filter != undefined && filter != null && filter.trim() != ''){
        query = query+" AND concat(fo.license_plate,'-',fo.name,'-',f.fletero) ilike ? "
    }
    query  = query+" limit 5 "
    return query;
}

function getOrdenDeTransporteDetalle(){
    var orderDeTransporteId = jQuery("#ordenTransporteSelectId").val();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select foo.id, foo.gc_productos_id, foo.product_qty as qty, ");
    sb.append("concat(p.id,' - ',p.producto) as result ");
    sb.append("from od_freight_order_detail foo ");
    sb.append("join od_freight_order fo on fo.id = foo.od_freight_order_id ")
    sb.append("join gc_productos p on p.id = foo.gc_productos_id ")
    sb.append("where fo.id  = '"+orderDeTransporteId+"' ");
    //var query = getFacturaDetalleGCQuery();
    var query = sb.toString();
    var ordenDeTranposrteDetalleSelect2Element = jQuery('#ordenDeTransporteDetalleMultiSelect2Id');
    setSelect2WhitLimit(ordenDeTranposrteDetalleSelect2Element, query, setOrdenDeTransporteDetalleData,
        getOrdenDeTransporteDetalleFilterQuery, getGetDataFromQueryAndPsURL());

    ordenDeTranposrteDetalleSelect2Element.on("select2:select", async function (e) {
        var data = e.params.data.text;
        var productId = e.params.data.queryData.gc_productos_id;
        var sumaCantidadTotal = e.params.data.queryData.qty;
        var sumaPrecioUnitarioFacturado = 0;
        var sumaPrecioTotalFacturado = 0;

        await addProductsSelectedInRetornoTable(productId, sumaCantidadTotal,
            sumaPrecioUnitarioFacturado, sumaPrecioTotalFacturado);
        await loadSelectUnidadDeMedida(productId)
    });
    ordenDeTranposrteDetalleSelect2Element.on("select2:unselect", function (e) {
        var id = e.params.data.id;
        removeTrFromTrId("product-tr-id-"+id)
    });
}
function setOrdenDeTransporteDetalleData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}
function getOrdenDeTransporteDetalleFilterQuery(query, filter){
    var selectedProducts = jQuery('#ordenDeTransporteDetalleMultiSelect2Id').val().toString()
    if(selectedProducts != undefined && selectedProducts != null && selectedProducts.trim() != ''){
        //query = query+" AND CAST(cvd.[Id Productos] as varchar) NOT IN ("+selectedProducts+") ";
    }
    query = query+" AND p.active_odoo is true "
    if(filter != undefined && filter != null && filter.trim() != ''){
        query = query+" AND concat(p.id,' - ',p.producto) ilike ? "
    }
    query = query+" limit 1 "
    console.log("query: "+query.toString())
    return query
}