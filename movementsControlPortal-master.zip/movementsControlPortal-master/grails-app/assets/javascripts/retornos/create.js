async function initJsPage(){
    await retornosMotivosSelect2();
    //await getFleteroWhitLimit()
    await loadOrdenDeTransporte();
    //await getFacturaNroSelect2IdWhitLimit();
}