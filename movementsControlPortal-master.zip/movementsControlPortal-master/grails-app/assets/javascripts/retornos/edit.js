var retornoDetalleToDeleteList = [];
async function initJsPage(){
    await retornosMotivosSelect2();
    await loadRetornosData();
    await loadOrdenDeTransporte()
    // await getFacturaNroSelect2IdWhitLimit();
}



async function loadRetornosData(){
    jQuery("#retornosMotivosSelectId").trigger('change');
    setOptToSelect2(jQuery("#ordenTransporteSelectId"), getFreightOrderData(), getFreightOrderId());

    var productsElementsList = document.getElementsByClassName("productsSelectedHiddenClass")
    var productsSelect2 = jQuery("#ordenDeTransporteDetalleMultiSelect2Id")
    for(let x = 0; x < productsElementsList.length; x++){
        let productHiddenElement = productsElementsList[x];
        let productId = productHiddenElement.value;
        let productDescription = productHiddenElement.getAttribute("attr-product-descr")
        let opt = new Option(productDescription, productId, true, true);
        productsSelect2.append(opt).trigger('change');
        let unidadDeMedidaIdFacturada = productHiddenElement.getAttribute("attr-product-unidadMedidaRet");
        await loadSelectUnidadDeMedida(productId)

    }
    getById("observacionId").value = getObservacion();
}

function updateRetorno(){
    let montoTotal = 0;
    var montoMap = new Map();
    montoMap.set("montoTotal", 0);
    var passDataList = []
    var devolucionDetailsPassDataUpdate = getRetornoDetailsPassDataUpdate(montoMap);
    if(devolucionDetailsPassDataUpdate != null){
        passDataList.push(devolucionDetailsPassDataUpdate);
    }

    var retornoDetailsPassDataInsert = getRetornosDetailsPassDataInsert(montoMap)
    if(retornoDetailsPassDataInsert != null){
        passDataList.push(retornoDetailsPassDataInsert)
    }

    var retornoDetailsPassDataDelete = getRetornoDetailsPassDataDelete()
    if(retornoDetailsPassDataDelete != null){
        passDataList.push(retornoDetailsPassDataDelete)
    }
    /*
    var detailChangeFlag = false;
    if(passDataList != null && passDataList != [] && passDataList.length > 0){
        detailChangeFlag = true;
    }
    */
    //var montoTotal =  Math.round(productPriceMap.get("TOTAL"));

    var passData = getRetornoPassDataUpdate(montoMap, true);
    passData.parentId = getRetornoId();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                goToBackUrl()
            }else{
                alert('No se pudo guardar el retorno: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo guardar el retorno');
        }
    });
}

function getRetornoPassDataUpdate(montoMap, detailChangeFlag){
    var sb = new StringBuilder();
    sb.append("UPDATE retorno SET user_last_updated_date=current_timestamp, user_last_updated_id=?, ");
    sb.append("gc_fletero_id=?, gc_motivo_retorno_id=?, fecha_retorno=current_timestamp, gc_cliente_id=?, ");
    sb.append("factura_fecha=?, factura_nro=?, gc_factura_id_concat=?, retorno_estado_id=?, ");
    sb.append("observacion=?, monto_total=?, fecha_asignacion = current_date, od_freight_order_id=? ");
    sb.append("WHERE id = ? ");

    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosRetornoUpdate(montoMap, detailChangeFlag);
    passData.argsToSet = JSON.stringify(argsToSet);

    return passData;
}

function getDatosRetornoUpdate(montoMap, detailChangeFlag){
    var orderDeTransporteId = jQuery("#ordenTransporteSelectId").val();
    var currentUserId = getLoggedUserId();
    var gcFleteroId = getById("fleteroSeleccionadoId").value;
    var retornoEstadoPendienteId = getOneValueFromTableAndCode("id", "retorno_estados",
        RETORNO.ESTADO.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.CODIGO);
    var observacion = getById("observacionId").value;

    var montoTotal = redondeoMonedaLocal(montoMap.get("montoTotal"));

    let obj = null;
    if(1==1){
        var columnsMap = new Map();
        columnsMap.set(1, [currentUserId, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(2, [gcFleteroId, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(3, [null, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(4, [null, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(5, [null, DATABASE.DATA_TYPE.TIMESTAMP]);
        columnsMap.set(6, [null, DATABASE.DATA_TYPE.VARCHAR]);
        columnsMap.set(7, [null, DATABASE.DATA_TYPE.VARCHAR]);
        columnsMap.set(8, [retornoEstadoPendienteId, DATABASE.DATA_TYPE.BIGINT]);
        columnsMap.set(9, [observacion, DATABASE.DATA_TYPE.VARCHAR]);
        columnsMap.set(10, [montoTotal, DATABASE.DATA_TYPE.DOUBLE]);
        columnsMap.set(11, [orderDeTransporteId, DATABASE.DATA_TYPE.BIGINT]);
        columnsMap.set(12, [getRetornoId(), DATABASE.DATA_TYPE.BIGINT]);
        obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
    }

    return obj;
}

function getRetornoDetailsPassDataUpdate(montoMap){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("UPDATE retorno_detalle SET cantidad_documentada_ret=?, ");
    sb.append("gc_motivo_retorno_id=?, ");
    sb.append("precio_unitario_ret=?, precio_total_ret=? ");
    sb.append("WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosRetornoDetalleUpdate(montoMap);
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosRetornoDetalleUpdate(montoMap){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let trProductosAgregados = document.getElementsByClassName("existing-product");
    let detallesList = [];
    for(let i = 0; i < trProductosAgregados.length; i++){
        var trProductElement = trProductosAgregados[i]
        var retornoDetalleId = trProductElement.getAttribute("attr-retorno-detalle-id");
        let productId = trProductElement.getAttribute("attr-product-id")

        var options = getById("unidadDeMedidaSelect-"+productId).options;
        var unidadDeMedidaText     = options[options.selectedIndex].text;
        var cantidadDocumentadaRet = parseInt(getById("cantidad-"+productId).value);
        if( unidadDeMedidaText.toUpperCase() == 'CAJ' ||
            unidadDeMedidaText.toUpperCase() == 'PACK'){
            cantidadDocumentadaRet = cantidadDocumentadaRet*options[options.selectedIndex].attributes[1].value
        }


        //var cantidadDocumentadaRet  = parseInt(getById("cantidad-"+productId).value);
        //var retornoMotivoId = jQuery("#retornosMotivosSelectId").val();
        var precioUnitarioRetornado = parseFloat(trProductElement.getAttribute("attr-product-precioUnitarioFacturado"));
        var precioTotalRet          = parseFloat(cantidadDocumentadaRet*precioUnitarioRetornado);
        montoMap.set("montoTotal", precioTotalRet+montoMap.get("montoTotal"));

        let columnsMap = new Map();
        columnsMap.set(1, [cantidadDocumentadaRet,      DATABASE.DATA_TYPE.INTEGER]);
        columnsMap.set(2, [null,             DATABASE.DATA_TYPE.BIGINT]);
        columnsMap.set(3, [precioUnitarioRetornado,     DATABASE.DATA_TYPE.DOUBLE]);
        columnsMap.set(4, [Math.round(precioTotalRet),              DATABASE.DATA_TYPE.DOUBLE]);
        columnsMap.set(5, [retornoDetalleId,            DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        detallesList.push(obj);
    }

    return detallesList;

}


function getRetornoDetailsPassDataDelete(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("DELETE FROM retorno_detalle WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosRetornoDetalleDelete();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosRetornoDetalleDelete(){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let devolucionDetallesList = [];
    for(let i = 0; i < retornoDetalleToDeleteList.length; i++){
        let devolucionDetalleId = retornoDetalleToDeleteList[i]
        let columnsMap = new Map();
        columnsMap.set(1, [devolucionDetalleId, DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        devolucionDetallesList.push(obj);
    }
    return devolucionDetallesList;
}

