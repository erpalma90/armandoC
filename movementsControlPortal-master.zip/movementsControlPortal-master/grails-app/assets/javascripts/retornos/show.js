function initJsPage(){
    getLastAuditoriaObservacionRetorno();
    if(getCurrentRole() == ROLES.ROLE_LIQUIDACION){
        //loadCantidadesRetornadasInformeGC();
        mostrarNotificacionDiferenciaCantidades();
        getFleterosPendientesDeRendicionSobrantesWhereNroCamionWhitLimit();
        var fechaElemento = getById("fechaAsignacionDateId")
        //loadDatePicker(fechaElemento, 0);
    }
}
function editRetorno(){
    showSpinner();
    var retornoId = getRetornoId();
    goToUrl(window.location, getRetornoEditUrl()+"/"+retornoId);
}

function verificacionCantidadesRetornoDeposito(){
    var cantidadesModal = document.getElementsByClassName("cantidadVerificadaRetDepositoClass");
    for(var x = 0; x < cantidadesModal.length; x++){
        var element = cantidadesModal[x]
        console.log("Cantidad verificada registro: "+element.getAttribute("attr-cantidadDocumentadaRet"))
    }
    jQuery("#verificacion-retorno-deposito-modal-id").modal();
}

function validacionDeRechazoRetorno(){
    jQuery("#rechazar-modal-id").modal();
    var correoDepositoSupervisor = getConfigurationValueFromKey("deposito.supervisor.correo.destinatario");
    jQuery("#correoNotificacionDivId").html(correoDepositoSupervisor);
    var rechazarBtnElement = getById("rechazarYEnviarCorreoBtnId");
    rechazarBtnElement.setAttribute("onclick", "rechazarRetornoEnDeposito()")
    //actualizacionDeEstado(2);
}
function rechazarRetornoEnDeposito(){
    var retornoId = getRetornoId();
    var motivoRec = getById("motivoRechazoDeposito").value
    if(motivoRec != null && motivoRec != ""){
        showSpinner();
        var urlStr = getSendMailURL();
        var passData = new Object();
        passData.mailTo = getConfigurationValueFromKey("deposito.supervisor.correo.destinatario");
        passData.subject = "Retorno Rechazado en Deposito"
        var element = getById("bodyHtmlId");
        var htmlContent = element.innerHTML;
        var motivoRechazoDeposito = rechazoHtml(getRetornoId());
        passData.body = motivoRechazoDeposito+htmlContent
        getDataFromQueryAjaxJson(urlStr, passData, null);
        actualizacionDeRetornoEstado(ACCION_RECHAZAR, retornoId);
    }else{
        toastTr('warning', 'Advertencia', 'Debe describir el motivo del rechazo');
    }
}


async function getLastAuditoriaObservacionRetorno(){
    var retornoId = getRetornoId();
    var sb = new StringBuilder();
    sb.append("SELECT concat(u.id,'-',u.username) as userdata, u.username, ");
    sb.append("a.observacion, re.estado_actual  FROM auditoria a ");
    sb.append("JOIN users u ON u.id = a.user_id ");
    sb.append("JOIN users_roles ur ON ur.users_id = u.id ");
    sb.append("JOIN roles r ON r.id = ur.roles_id ");
    sb.append("JOIN retorno_estados re ON re.codigo = a.estado ");
    sb.append("WHERE a.dominio_id = '"+retornoId+"' ");
    sb.append("ORDER BY a.fecha_auditoria DESC LIMIT 1 ");
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    passData.query = sb.toString();
    var auditStatusDtoList = await getDataFromQueryAjax(urlStr, passData)
    for(var x = 0; x < auditStatusDtoList.length; x++){
        var dto = auditStatusDtoList[x];
        if(dto.observacion != null && dto.observacion.trim() != ""){
            var divElement = getById("auditDivID");
            divElement.style.display = "";
            var htmlSb = new StringBuilder();
            htmlSb.append("<span style = 'color:red;'> ");
            htmlSb.append(dto.username+": "+dto.observacion);
            htmlSb.append("</span>");
            jQuery(divElement).html(htmlSb.toString());
        }
    }
}

function printDocumentRetorno(retornoId, fletero){
    var d = moment().format('DD MM YYYY HH:mm');
    document.title="RETORNO_"+retornoId+"_"+fletero+"_"+d;
    window.print();
    return false;
}