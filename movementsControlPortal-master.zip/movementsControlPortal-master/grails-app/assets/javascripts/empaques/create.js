var empaqueDetalleToDeleteList = [];
function initJsPage(){
    getGcProductosPromoList();
    getProductsForEmpaqueMultiSelect();
    getById("addProductAndAccesorioDivId").style.display = "";
}