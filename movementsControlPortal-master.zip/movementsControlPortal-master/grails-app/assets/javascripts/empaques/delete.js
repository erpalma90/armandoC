
function deleteEmpaque(){
    var trueToDelete = getTrueToEditOrDelete(2);
    if(trueToDelete){
        var empaqueId = getEmpaqueId();
        areYouShureEmpaqueDeleteModal(empaqueId);
    }
}

function areYouShureEmpaqueDeleteModal(){
    var trueToDelete = getTrueToEditOrDelete(2);
    if(trueToDelete){
        acceptOrCancellModal("Estas seguro? ", "Estas seguro que deseas eliminar el empaque?" ,'warning' ,
            "Si, eliminar", function () {return executeEmpaqueDelete()});
    }

}

function executeEmpaqueDelete(){
    var passDataList = [];

    var empaqueDetailsPassDataDelete = getEmpaquesDetailsPassDataDeleteFromEmpaqueId()
    if(empaqueDetailsPassDataDelete != null){
        passDataList.push(empaqueDetailsPassDataDelete)
    }

    var empaquePassDataDelete = getEmpaquePassDataDelete()
    if(empaquePassDataDelete != null){
        passDataList.push(empaquePassDataDelete)
    }


    var passData = new Object()//getEmpaquePassDataDelete();
    passData.parentId = getEmpaqueId();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    var trueToDelete = getTrueToEditOrDelete(2);
    if(trueToDelete){
        jQuery.ajax({
            url: urlStr,
            type: 'PUT',
            async:false,
            data: passData,
            success: function(data) {
                if(data != ERROR.SERVER_ERROR){
                    goToBackUrl()
                }else{
                    alert('No se pudo actualizar el empaque: e '+ERROR.SERVER_ERROR);
                    hideSpinner();
                }
            },
            error: function () {
                hideSpinner();
                alert('Error, no se pudo actualizar el empaque');
            }
        });
    }

}

function getEmpaquesDetailsPassDataDeleteFromEmpaqueId(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("DELETE FROM empaque_detalle WHERE empaque_id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosEmpaqueDetalleDeleteFromEmpaqueId();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosEmpaqueDetalleDeleteFromEmpaqueId(){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let detallesList = [];

    let empaqueId = getEmpaqueId();
    let columnsMap = new Map();
    columnsMap.set(1, [empaqueId, DATABASE.DATA_TYPE.BIGINT]);
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    detallesList.push(obj);

    return detallesList;
}

function getEmpaquePassDataDelete(){
    var sb = new StringBuilder();
    sb.append("DELETE FROM empaque WHERE id = ?  ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosEmpaqueDelete();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}


function getDatosEmpaqueDelete(){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let detallesList = [];

    let empaqueId = getEmpaqueId();
    let columnsMap = new Map();
    columnsMap.set(1, [empaqueId, DATABASE.DATA_TYPE.BIGINT]);
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    detallesList.push(obj);

    return detallesList;
}