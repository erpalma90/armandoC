function initJsPage(){
    hideAndEnableElements();
}
function hideAndEnableElements(){
    jQuery(".cantidad").prop( "disabled", true );
    jQuery(".removeIconClass").remove();
}


function entradaDeProducto(){
    getById("acceptGenerateComprobanteStockBtnId").setAttribute("onclick", "acceptComprobanteStock(1)")
    jQuery("#movimientoDepositoModalTitleId").html("Entrada de Producto");
    jQuery("#movimientoDepositoModalId").modal();
}

function salidaDeProducto(){
    getById("acceptGenerateComprobanteStockBtnId").setAttribute("onclick", "acceptComprobanteStock(2)")
    jQuery("#movimientoDepositoModalTitleId").html("Salida de Producto");
    jQuery("#movimientoDepositoModalId").modal();
}

function acceptComprobanteStock(action){
    var productId = getEmpaqueProductId();
    var cantidadCab = getById("cantidadTotalId").value;
    var depositoToId = getById("depositoSelectId").value
    if(depositoToId != null && depositoToId != undefined && depositoToId != 'null'){
        var requiredFieldsOkFlag = validateRequiredFields("movimientoDepositoModalId");
        if(requiredFieldsOkFlag){
            showSpinner();
            var dataObject = new Object();
            if(action == 1){
                dataObject.depositoEmisorId = null;
                dataObject.depositoReceptorId = depositoToId;
            }else if(action == 2){
                dataObject.depositoEmisorId = depositoToId;
                dataObject.depositoReceptorId = null;
            }
            dataObject.comprobanteStock = action;

            var detailDataObj;
            detailDataObj = new Object();
            detailDataObj.cantidad = cantidadCab;
            detailDataObj.productId = productId;

            var objList = [];
            objList.push(detailDataObj);

            var urlStr = getCreateComprobantesDeStockURL();
            var passData = new Object();
            passData.dataObject = JSON.stringify(dataObject);
            passData.retornosDetallesDepositosObjList = JSON.stringify(objList);
            if(objList != null){
                jQuery.ajax({
                    url: urlStr,
                    type: 'GET',
                    async:true,
                    //dataType: 'json',
                    data: passData,
                    success: function(data) {
                        var resumenComprobanteStockDto = JSON.parse(data);
                        if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
                            //reloadThisPage();
                            showAllRetornoDetalleDepositoFromDepositoId(depositoToId)
                        }else if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_ERROR){
                            swalNotification('top-center', 'error', 'NO SE PUEDE EJECUTAR, CONSULTAR CON TI', 2000);
                        }else{
                            hideSpinner();
                            swalNotification('top-center', 'warning', data.msgRtrn, 2000)
                        }
                    },
                    error: function (dataError) {
                        swalNotification('top-center', 'error', dataError.responseText, 2000);
                        console.log(dataError.responseText);
                        dataToReturn = ERROR.AJAX_RETURN;
                    }
                });
            }
        }
    }else{
        hideSpinner();
        swalNotification('top-center', 'warning', 'No se seleccionó un depósito', 2000);
    }
}

function editEmpaque(){
    var trueToEdit = getTrueToEditOrDelete(1);
    if(trueToEdit){
        showSpinner();
        var empaqueId = getEmpaqueId();
        goToUrl(window.location, getEmpaqueEditUrl()+"/"+empaqueId);
    }
}


function getTrueToEditOrDelete(comesFrom){
    var continueEditFlag = true;
    jQuery(".new-element").remove();
    var empaqueId = getEmpaqueId();
    var urlStr = getGetDataFromQueryInGCURL();
    var passData = {};

    var sb = new StringBuilder();
    sb.append("SELECT sd.[Tipo Deposito] as tipo_deposito, ss.[ID Productos] as id_producto, sp.[Codigo Barra] as codigo_barra, ");
    sb.append("sp.Descripcion as producto_descripcion, ss.Cantidad as cantidad FROM STK_Stock ss ");
    sb.append("JOIN STK_Depositos sd ON sd.[ID Depositos] = ss.[ID Depositos] ");
    sb.append("JOIN STK_Productos sp ON sp.[ID Productos] = ss.[ID Productos] ");
    sb.append("WHERE ss.[ID Sucursales] = "+ID_SUCURSAL+" ");
    sb.append("AND Cantidad > 0 ");
    sb.append("AND ss.[ID Productos] = "+getEmpaqueProductId()+" ");
    if(comesFrom == 1){
        sb.append("AND sd.Descripcion != '"+DEPOSITOS.REEMP.NOMBRE+"' ");
    }

    passData.query = sb.toString();
    var list = getDataFromQueryAjax(urlStr, passData);


    var tableElement = getById("tableBodyId");
    var originalTrElement = getById("tableTrId");
    for(var x = 0; x < list.length; x++){
        var dto = list[x];
        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.style.display = "";
        newTrElement.setAttribute("class", "new-element")
        if(dto.tipo_deposito == 'Central'){
            dto.tipo_deposito = 'PTBOD'
        }
        setDataInTableTd(newTrElement, dto)
        tableElement.appendChild(newTrElement)
        continueEditFlag = false;
    }
    if(!continueEditFlag){
        jQuery("#stopEditModalId").modal();
    }
    return continueEditFlag;
}
