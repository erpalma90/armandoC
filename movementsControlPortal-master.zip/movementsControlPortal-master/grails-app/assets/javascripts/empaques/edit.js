var empaqueDetalleToDeleteList = [];
function initJsPage(){
    //getGcProductosPromoList()
    getProductsForEmpaqueMultiSelect();
    loadEmpaquesData();
}

async function loadEmpaquesData(){
    var productId = getEmpaqueProductId();
    var productName = getProductName();
    setOptToSelect2(jQuery("#productosSelectId"), productId+'-'+productName, productId);
    var productsElementsList = document.getElementsByClassName("productsSelectedHiddenClass")
    var productsSelect2 = jQuery("#productMultiSelect2Id")
    for(let x = 0; x < productsElementsList.length; x++){
        let productHiddenElement = productsElementsList[x];
        let productId = productHiddenElement.value;
        let productDescription = productHiddenElement.getAttribute("attr-product-descr")
        let opt = new Option(productDescription, productId, true, true);
        productsSelect2.append(opt).trigger('change');
    }
}


function updateEmpaque(){
    var passDataList = []
    var empaqueDetailsPassDataUpdate = getEmpaqueDetailsPassDataUpdate();
    if(empaqueDetailsPassDataUpdate != null){
        passDataList.push(empaqueDetailsPassDataUpdate);
    }

    var empaqueDetailsPassDataInsert = getEmpaquesDetailsPassDataInsert()
    if(empaqueDetailsPassDataInsert != null){
        passDataList.push(empaqueDetailsPassDataInsert)
    }
    var empaqueDetailsPassDataDelete = getEmpaquesDetailsPassDataDelete()
    if(empaqueDetailsPassDataDelete != null){
        passDataList.push(empaqueDetailsPassDataDelete)
    }
    var passData = getEmpaquePassDataUpdate();
    //passData.parentId = getRetornoId();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                goToBackUrl()
            }else{
                alert('No se pudo actualizar el empaque: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo actualizar el empaque');
        }
    });
}



function getEmpaqueDetailsPassDataUpdate(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("UPDATE empaque_detalle SET accesorio_descripcion=?, cantidad=?, ");
    sb.append("gc_producto_id=? ");
    sb.append(" WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosEmpaqueDetalleUpdate();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}


function getDatosEmpaqueDetalleUpdate(){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let trProductosAgregados = document.getElementsByClassName("existing-product");
    let detallesList = [];
    for(let i = 0; i < trProductosAgregados.length; i++){
        var trProductElement = trProductosAgregados[i]
        var empaqueDetalleId = trProductElement.getAttribute("attr-empaque-detalle-id");
        let productId = trProductElement.getAttribute("attr-product-id")
        var cantidad = parseInt(getById("cantidad-"+productId).value);
        var accesorioDescripcion = trProductElement.getAttribute("attr-accesorio-descripcion");

        let columnsMap = new Map();
        columnsMap.set(1, [accesorioDescripcion,DATABASE.DATA_TYPE.VARCHAR]);
        columnsMap.set(2, [cantidad,            DATABASE.DATA_TYPE.INTEGER]);
        columnsMap.set(3, [productId,           DATABASE.DATA_TYPE.BIGINT]);
        columnsMap.set(4, [empaqueDetalleId,    DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        detallesList.push(obj);
    }

    return detallesList;

}

function getEmpaquePassDataUpdate(){
    var sb = new StringBuilder();

    sb.append("UPDATE empaque SET user_last_updated_date= current_timestamp, user_last_updated_id=? ");
    sb.append("WHERE id = ? ");

    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosEmpaqueUpdate();
    passData.argsToSet = JSON.stringify(argsToSet);

    return passData;
}

function getDatosEmpaqueUpdate(){
    var userId = getLoggedUserId();
    var productoId = jQuery("#productosSelectId").val();
    var empaqueId = getEmpaqueId();
    let obj = null;
    var columnsMap = new Map();
    columnsMap.set(1, [userId, DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(2, [empaqueId, DATABASE.DATA_TYPE.BIGINT]);
    obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});

    return obj;
}

function getEmpaquesDetailsPassDataInsert(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("INSERT INTO empaque_detalle(id, version, accesorio_descripcion, cantidad, gc_producto_id, empaque_id) ");
    sb.append("VALUES (nextval('empaque_detalle_seq'), 0, ?, ?, ?, ?) ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosEmpaquesDetalleInsert();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}


function getDatosEmpaquesDetalleInsert(){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let trProductosAgregados = document.getElementsByClassName("new-product-empaque");
    let detallesList = [];
    for(let i = 0; i < trProductosAgregados.length; i++){
        var trProductElement = trProductosAgregados[i];
        var productId = trProductElement.getAttribute("attr-product-id");
        var campoAccesorio = trProductElement.getAttribute("attr-campoaccesorio");
        var cantidad = getById("cantidad-"+productId).value;

        if(campoAccesorio != null && campoAccesorio != undefined){
            productId = null;
        }
        if(productId != null && productId != undefined){
            campoAccesorio = null;
        }

        var empaqueId = getEmpaqueId();
        let columnsMap = new Map();
        columnsMap.set(1, [campoAccesorio, DATABASE.DATA_TYPE.VARCHAR]);
        columnsMap.set(2, [cantidad, DATABASE.DATA_TYPE.INTEGER]);
        columnsMap.set(3, [productId, DATABASE.DATA_TYPE.BIGINT]);
        columnsMap.set(4, [empaqueId, DATABASE.DATA_TYPE.BIGINT]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        detallesList.push(obj);
    }

    return detallesList;

}



function getEmpaquesDetailsPassDataDelete(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("DELETE FROM empaque_detalle WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosEmpaqueDetalleDelete();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}


function getDatosEmpaqueDetalleDelete(){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let detallesList = [];
    for(let i = 0; i < empaqueDetalleToDeleteList.length; i++){
        let empaqueDetalleId = empaqueDetalleToDeleteList[i]
        let columnsMap = new Map();
        columnsMap.set(1, [empaqueDetalleId, DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        detallesList.push(obj);
    }
    return detallesList;
}