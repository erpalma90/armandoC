
function getGcProductosPromoList(){
    var url = getGetDataFromQueryAndPsInGCURL();
    var passData = {};
    var sb = new StringBuilder();

    sb.append("SELECT p.[ID Productos] as id, ");
    sb.append("cast(p.[ID Productos] as varchar)+CASE WHEN p.[Codigo Barra] is not null THEN '-'+p.[Codigo Barra] ELSE '' END+'-'+");
    sb.append("p.Descripcion as result FROM STK_Productos p ");
    sb.append("LEFT JOIN STK_Stock ss ON ss.[ID Productos] = p.[ID Productos] ");
    sb.append("LEFT JOIN STK_Depositos sd ON sd.[ID Depositos] = ss.[ID Depositos] ");
    sb.append("WHERE p.[clasificacion 9] = 'Promo' AND [Clasificacion 7] = 'SI' ");
    sb.append("AND (ss.Cantidad = 0 OR ss.[ID Productos] is null) AND sd.[ID Depositos] is null ");


    passData.query = sb.toString();
    var select2Element = jQuery('#productosSelectId');
    setSelect2WhitLimit(select2Element, sb.toString(), setProductData, getProductFilterQuery, url)

    select2Element.on('change', function (e) {
        $('#facturaNroSelect2Id').val(null).trigger('change');
    });
}

function setProductData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getProductFilterQuery(query, filter){
    var queryFilter = new StringBuilder();
    queryFilter.append(query.toString()+" ");

    var selectedProducts = jQuery('#productMultiSelect2Id').val().toString()
    if(selectedProducts != undefined && selectedProducts != null && selectedProducts.trim() != ''){
        queryFilter.append(" AND CAST(p.[ID Productos] as varchar) NOT IN ("+selectedProducts+") ");
    }


    if(filter != undefined && filter != null && filter.trim() != ''){
        //" AND cast(p.id as varchar)+CASE WHEN p.codigo_barra is not null THEN '-'+p.codigo_barra END, p.producto like ? "
        queryFilter.append("AND cast(p.[ID Productos] as varchar)+");
        queryFilter.append("CASE WHEN p.[Codigo Barra] is not null THEN '-'+p.[Codigo Barra] ELSE '' END +'-'+p.Descripcion like ? ");
        //query = query+" AND cast(f.[Numero Camion] as varchar)+'-'+cast(f.nombre as varchar) like ? "
    }
    return queryFilter.toString()+" ORDER BY p.Descripcion ASC";
}

function getProductsForEmpaqueMultiSelect(){
    var url = getGetDataFromQueryAndPsInGCURL();
    var query = getProductosGCQuery();
    var select2Element = jQuery('#productMultiSelect2Id');
    setSelect2WhitLimit(select2Element, query, setProductData, getProductFilterQuery, url)
    select2Element.on("select2:select", async function (e) {
        var id = e.params.data.id;
        await addProductsSelectedInEmpaqueTable(id);
    });
    select2Element.on("select2:unselect", function (e) {
        var id = e.params.data.id;
        removeTrFromTrId("product-tr-id-"+id)
    });
}
function getProductosGCQuery() {
    var sb = new StringBuilder();
    sb.append("SELECT p.[ID Productos] as id,  ");
    sb.append("cast(p.[ID Productos] as varchar)+CASE WHEN p.[Codigo Barra] is not null THEN '-'+p.[Codigo Barra] ELSE '' END+'-'+p.Descripcion as result ")
    sb.append("FROM STK_Productos p WHERE p.[clasificacion 9] != 'Promo' AND [Clasificacion 7] = 'SI' ");
    return sb.toString();
}

async function addProductsSelectedInEmpaqueTable(productId, campoAccesorio){
    //var idProductosSeleccionados = jQuery("#productMultiSelect2Id").select2("val");
    var productList = [];
    if(productId != null){
        var idProductosSeleccionados = productId;
        var urlStr = getGetDataFromQueryURL();
        var passData = new Object();
        passData.query = "SELECT * FROM gc_productos WHERE id in ("+idProductosSeleccionados+")";
        productList = await getDataFromQueryAjax(urlStr, passData)
    }else if (campoAccesorio != null && campoAccesorio != undefined && campoAccesorio.trim() != ''){
        //AGREGAR UN CAMPO ACCESORIO
        var accData = new Object();
        accData.id = campoAccesorio+"Id";
        accData.codigo_barra = "-";
        accData.producto = campoAccesorio;
        productList.push(accData);
    }

    var productTableElement = getById("productTableBodyId");
    var originalTrElement = getById("productTableTrId");
    for(var x = 0; x < productList.length; x++){
        var dto = productList[x];
        var trId = "product-tr-id-"+dto.id
        if(getById(trId) == null || getById(trId) == undefined){
            dto.removeId = trId;
            dto.cantidad = 0;
            var productTr = getById("product-tr-id-"+dto.id);
            if(productTr == null || productTr == undefined){
                var newTrElement = originalTrElement.cloneNode(true);
                newTrElement.style.display = "";
                newTrElement.setAttribute("attr-product-id", dto.id)
                newTrElement.setAttribute("id", "product-tr-id-"+dto.id);
                if(campoAccesorio != null && campoAccesorio != undefined && campoAccesorio != ""){
                    newTrElement.setAttribute("attr-campoAccesorio", campoAccesorio);
                }
                newTrElement.setAttribute("class", "new-product-empaque")
                setDataInTableTd(newTrElement, dto)
                productTableElement.appendChild(newTrElement)
            }
        }else{
            swalNotification('top-center', 'warning', 'El item ya existe en este empaque!!!', 2000)
        }
    }
}

function removeTrFromTrId(elementId, id){
    var productTrElement = document.getElementById(elementId);
    jQuery(productTrElement).remove();
    if(id != null && id != undefined){
        //jQuery('#productMultiSelect2Id').val(id).trigger("change");
        jQuery("#productMultiSelect2Id option[value='"+id+"']").remove();
    }
    if(productTrElement.classList.contains('existing-product')){
        empaqueDetalleToDeleteList.push(productTrElement.getAttribute("attr-empaque-detalle-id"))
    }
}

function addCampoAccesorio(){
    var requiredFieldsOkFlag = validateRequiredFields("campoAccesorioDivId");
    if(requiredFieldsOkFlag){
        var campoAccesorio = getById("campoAccesorioId").value;
        addProductsSelectedInEmpaqueTable(null, campoAccesorio.trim())
        getById("campoAccesorioId").value = "";
    }
}

function saveEmpaque(){
    showSpinner();
    var requiredFieldsOkFlag = validateRequiredFields("asd");
    if(requiredFieldsOkFlag){
        var empaqueData = new Object();
        empaqueData.gcProductoId = jQuery("#productosSelectId").val();
        empaqueData.empaquetado = false;


        var empaqueDetailsElements = document.getElementsByClassName("new-product-empaque");
        var empaqueDetailDataObj = new Object();
        var empaqueDetailDataObjList = [];
        for(var x = 0; x < empaqueDetailsElements.length; x++){
            empaqueDetailDataObj = new Object();
            var currentElement = empaqueDetailsElements[x];

            if(!currentElement.hasAttribute("attr-campoAccesorio")){ //SE VALIDA QUE NO TENGA ESTE ATRIBUTO PARA ASUMIR QUE TIENE PROD ID
                empaqueDetailDataObj.gcProductoId = currentElement.getAttribute("attr-product-id");
            }else{
                empaqueDetailDataObj.gcProductoId = null;
            }

            if(currentElement.hasAttribute("attr-campoAccesorio")){
                empaqueDetailDataObj.accesorioDescripcion = currentElement.getAttribute("attr-campoAccesorio");
            }else{
                empaqueDetailDataObj.accesorioDescripcion = null;
            }
            var id = currentElement.getAttribute("attr-product-id")
            empaqueDetailDataObj.cantidad = getById("cantidad-"+id).value;
            console.log(empaqueDetailDataObj);
            empaqueDetailDataObjList.push(JSON.stringify(empaqueDetailDataObj));
        }
        console.log("empaqueDetailDataObjList: "+empaqueDetailDataObjList)
        var passData = new Object();
        passData.empaqueData = JSON.stringify(empaqueData);

        var urlStr = getSaveEmpaquesAndDetailsUrl();
        passData.empaqueDetailDataObjList = JSON.stringify(empaqueDetailDataObjList);
        //ajaxPutData(urlStr, passData, null)
        jQuery.ajax({
            url: urlStr,
            type: 'POST',
            async:false,
            //dataType: 'json',
            data: passData,
            success: function(data) {
                if(data.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
                    goToUrl(window.location.search, getEmpaquesShowUrl()+"/"+data.id, true);
                    hideSpinner();
                }else{
                    hideSpinner();
                    swalNotification('top-center', 'warning', data.msgRtrn, 2000)
                }
            },
            error: function (dataError) {
                alert("dataError: "+dataError)
            }
        });

    }
}
