function ajaxPutData(urlStr, passData, goToFunction){
    let dataToReturn = null;
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:true,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                if(goToFunction != undefined && goToFunction != null){
                    goToFunction(data);
                }else{
                    dataToReturn = data;
                }
            }else if(data == ERROR.SERVER_ERROR){
                swalNotification('top-center', 'error', data.responseText, 2000);
            }
        },
        error: function (dataError) {
            swalNotification('top-center', 'error', dataError.responseText, 2000);
            console.log(dataError.responseText);
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
    return dataToReturn;
}

function ajaxGetData(urlStr, passData, goToFunction){
    let dataToReturn = null;
    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:true,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                if(goToFunction != undefined && goToFunction != null){
                    goToFunction(data);
                }else{
                    dataToReturn = data;
                }
            }
        },
        error: function (dataError) {
            swalNotification('top-center', 'error', dataError.responseText, 2000);
            console.log(dataError.responseText);
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
    return dataToReturn;
}

async function ajaxPutDataAsync(urlStr, passData, goToFunction){
    let dataToReturn = null;
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:true,
        //dataType: 'json',
        data: passData,
        success: async function(data) {
            if(data != ERROR.SERVER_ERROR){
                if(goToFunction != undefined && goToFunction != null){
                    await goToFunction(data);
                }else{
                    dataToReturn = data;
                }
            }else if(data == ERROR.SERVER_ERROR){
                await swalNotification('top-center', 'error', data.responseText, 2000);
            }
        },
        error: async function (dataError) {
            await swalNotification('top-center', 'error', dataError.responseText, 2000);
            console.log(dataError.responseText);
            dataToReturn = ERROR.AJAX_RETURN;
            hideSpinner()
        }
    });
    return dataToReturn;
}
