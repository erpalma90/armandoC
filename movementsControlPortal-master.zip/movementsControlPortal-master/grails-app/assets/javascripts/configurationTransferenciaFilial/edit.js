function initJsPage(){
    loadConfiguracionTransferenciaFilialData();
    getClientesList();
    getSucursalList();
    getFleteroList();
    getMotivoDevolucionList();
}

async function loadConfiguracionTransferenciaFilialData(){
    setOptToSelect2(jQuery("#clienteSelectId"), getClienteData(), getClienteId());
    setOptToSelect2(jQuery("#fleteroSelectId"), getFleteroData(), getFleteroId());
    setOptToSelect2(jQuery("#motivoDevolucionSelectId"), getMotivoDevolucionData(), getMotivoDevolucionId());
    setOptToSelect2(jQuery("#sucursalSelectId"), getSucursalData(), getSucursalId());
}
