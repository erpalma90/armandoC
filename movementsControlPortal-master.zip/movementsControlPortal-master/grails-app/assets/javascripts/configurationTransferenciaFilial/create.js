function initJsPage(){
    getClientesList();
    getSucursalList();
    getFleteroList();
    getMotivoDevolucionList();
    //getProductsForEmpaqueMultiSelect();
    //getById("addProductAndAccesorioDivId").style.display = "";
}