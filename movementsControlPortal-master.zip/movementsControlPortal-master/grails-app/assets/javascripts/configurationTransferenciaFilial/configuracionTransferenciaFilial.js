function getClientesList(){
    var url = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select id, concat(id,'-',razon_social) as result from gc_clientes ");
    sb.append("WHERE 1=1 ");

    passData.query = sb.toString();
    var select2Element = jQuery('#clienteSelectId');
    setSelect2WhitLimit(select2Element, sb.toString(), setClienteData, getClienteFilterQuery, url)

    select2Element.on('change', function (e) {
        $('#facturaNroSelect2Id').val(null).trigger('change');
    });
}

function setClienteData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}


function getClienteFilterQuery(query, filter){
    var queryFilter = new StringBuilder();
    queryFilter.append(query.toString()+" ");

    var selectedIds = jQuery('#clienteSelectId').val().toString()
    if(selectedIds != undefined && selectedIds != null && selectedIds.trim() != ''){
        queryFilter.append(" AND id != "+selectedIds);
    }

    if(filter != undefined && filter != null && filter.trim() != ''){
        queryFilter.append("AND concat(id,'-',razon_social) ilike ? ");
    }
    return queryFilter.toString()+' order by id asc limit 100';
}

/*---------------------------------------------------------------------------------*/
function getSucursalList(){
    var url = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select id, concat(id,'-',nombre) as result from sucursal ");
    sb.append("WHERE 1=1 ");

    passData.query = sb.toString();
    var select2Element = jQuery('#sucursalSelectId');
    setSelect2WhitLimit(select2Element, sb.toString(), setSucursalData, getSucursalFilterQuery, url)

}

function setSucursalData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getSucursalFilterQuery(query, filter){
    var queryFilter = new StringBuilder();
    queryFilter.append(query.toString()+" ");

    var selectedIds = jQuery('#sucursalSelectId').val().toString()
    if(selectedIds != undefined && selectedIds != null && selectedIds.trim() != ''){
        queryFilter.append(" AND id != "+selectedIds);
    }

    if(filter != undefined && filter != null && filter.trim() != ''){
        queryFilter.append("AND concat(id,'-',nombre) ilike ? ");
    }
    return queryFilter.toString()+' order by id asc limit 100';
}
/*---------------------------------FLETERO------------------------------------------------*/
function getFleteroList(){
    var url = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select id, concat(id,'-',nro_movil,'-',fletero) as result from gc_fletero ");
    sb.append("WHERE 1=1 ");

    passData.query = sb.toString();
    var select2Element = jQuery('#fleteroSelectId');
    setSelect2WhitLimit(select2Element, sb.toString(), setFleteroData, getFleteroFilterQuery, url)

}

function setFleteroData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getFleteroFilterQuery(query, filter){
    var queryFilter = new StringBuilder();
    queryFilter.append(query.toString()+" ");

    var selectedIds = jQuery('#fleteroSelectId').val().toString()
    if(selectedIds != undefined && selectedIds != null && selectedIds.trim() != ''){
        queryFilter.append(" AND id != "+selectedIds);
    }

    if(filter != undefined && filter != null && filter.trim() != ''){
        queryFilter.append("AND concat(id,'-',nro_movil,'-',fletero) ilike ? ");
    }
    return queryFilter.toString()+' order by id asc limit 100';
}
/*---------------------------------MOTIVO DEVOLUCION------------------------------------------------*/
function getMotivoDevolucionList(){
    var url = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select id, concat(id,'-',devolucion_motivo) as result from devolucion_motivos  ");
    sb.append("WHERE 1=1 ");

    passData.query = sb.toString();
    var select2Element = jQuery('#motivoDevolucionSelectId');
    setSelect2WhitLimit(select2Element, sb.toString(), setDevolucionMotivoData, getDevolucionMotivoFilterQuery, url)

}

function setDevolucionMotivoData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getDevolucionMotivoFilterQuery(query, filter){
    var queryFilter = new StringBuilder();
    queryFilter.append(query.toString()+" ");

    var selectedIds = jQuery('#fleteroSelectId').val().toString()
    if(selectedIds != undefined && selectedIds != null && selectedIds.trim() != ''){
        queryFilter.append(" AND id != "+selectedIds);
    }

    if(filter != undefined && filter != null && filter.trim() != ''){
        queryFilter.append("AND concat(id,'-',devolucion_motivo) ilike ? ");
    }
    return queryFilter.toString()+' order by id asc limit 100';
}