const ERROR = {
    AJAX_RETURN : -1,
    SERVER_ERROR : -501,
    SERVER_SUCCESS_TRANSACTION : 100
}
const SERVER_RESPONSE = {
    SERVER_SUCCESS_TRANSACTION : 100,
    SERVER_ERROR : -501,
    AJAX_RETURN : -1,
    SERVER_STOP_TRANSACTION :205
}
const ROLES = {
    ROLE_ADMIN          : "ROLE_ADMIN",
    ROLE_REGISTRO       : "ROLE_REGISTRO",
    ROLE_DEPOSITO       : "ROLE_DEPOSITO",
    ROLE_LIQUIDACION    : "ROLE_LIQUIDACION",
    ROLE_REGISTRO_FILIAL: "ROLE_REGISTRO_FILIAL"
}
const CUENTAS_CORRIENTES =  {
    ESTADOS : {
        PENDIENTE : {
            CODIGO : "01",
            ESTADO : "PENDIENTE_CUENTAS_CORRIENTES"
        },
        APROBADO : {
            CODIGO : "02",
            ESTADO : "APROBADO_CUENTAS_CORRIENTES"
        },
        LIBERADO : {
            CODIGO : "03",
            ESTADO : "LIBERADO_CUENTAS_CORRIENTES"
        }
    }
}
const DEVOLUCION = {
    ESTADOS : {
        PENDIENTE_REGISTRO : {
            PENDIENTE_DEPOSITO : {
                LABORATORIO : {
                    CODIGO      : "01"
                }
            }
        },
        NO_REGISTRADO_REGISTRO : {
            PENDIENTE_DEPOSITO: {
                LABORATORIO: {
                    CODIGO  : '02'
                }
            }
        },
        APROBADO_REGISTRO : {
            PENDIENTE_DEPOSITO : {
                LABORATORIO : {
                    CODIGO : '03'
                }
            },
            APROBADO_DEPOSITO : {
                LABORATORIO : {
                    CODIGO : '04'
                },
                STOCK_LABORATORIO : {
                    CODIGO : '06'
                },
                DERRAME_LABORATORIO : {
                    CODIGO : '07'
                }
            },
            RECHAZADO_DEPOSITO : {
                LABORATORIO : {
                    CODIGO : "05"
            }
        }
        }
    },
    TIPOS : {
        CON_SNC : {
            CODIGO: "01",
            DESCRIPCION: "Con SNC"
        },
        SIN_SNC : {
            CODIGO: "02",
            DESCRIPCION: "Sin SNC"
        }
    },
    METODO_DE_CARGA : {
        MANUAL : {
            CODIGO:"01",
            DESCRIPCION:"Manual"
        },
        SIEDI : {
            CODIGO:"02",
            DESCRIPCION:"Siedi"
        }
    }
}

const ACCION_APROBAR   = 1;
const ACCION_RECHAZAR  = 2;

const VAR_PENDIENTE_REGISTRO       = "PENDIENTE REGISTRO";
const VAR_APROBADO_REGISTRO        = "APROBADO REGISTRO";
const VAR_NO_REGISTRADO_REGISTRO   = "NO REGISTRADO REGISTRO";
const VAR_PENDIENTE_DEPOSITO       = "PENDIENTE DEPOSITO";
const VAR_APROBADO_DEPOSITO        = "APROBADO DEPOSITO";
const VAR_RECHAZADO_DEPOSITO       = "RECHAZADO DEPOSITO";
const VAR_FINALIZADO               = "FINALIZADO";
const VAR_RECHAZADO_REGISTRO       = "RECHAZADO REGISTRO";
const RETORNO = {
    ESTADO : {

        PENDIENTE_REGISTRO : {
            PENDIENTE_DEPOSITO : {
                CODIGO           : "01",
                REGISTRO_ESTADO  : VAR_PENDIENTE_REGISTRO,
                DEPOSITO_ESTADO  : VAR_PENDIENTE_DEPOSITO,
                ESTADO_ACTUAL    : VAR_PENDIENTE_REGISTRO
            }
        },
        APROBADO_REGISTRO : {
            PENDIENTE_DEPOSITO : {
                CODIGO           : "02",
                REGISTRO_ESTADO  : VAR_APROBADO_REGISTRO,
                DEPOSITO_ESTADO  : VAR_PENDIENTE_DEPOSITO,
                ESTADO_ACTUAL    : VAR_PENDIENTE_DEPOSITO
            },
            APROBADO_DEPOSITO : {
                CODIGO           : "03",
                REGISTRO_ESTADO  : VAR_APROBADO_REGISTRO,
                DEPOSITO_ESTADO  : VAR_APROBADO_DEPOSITO,
                ESTADO_ACTUAL    : VAR_FINALIZADO
            },
            RECHAZADO_DEPOSITO : {
                CODIGO           : "04",
                REGISTRO_ESTADO  : VAR_APROBADO_REGISTRO,
                DEPOSITO_ESTADO  : VAR_RECHAZADO_DEPOSITO,
                ESTADO_ACTUAL    : VAR_RECHAZADO_DEPOSITO
            }
        },
        NO_REGISTRADO_REGISTRO : {
            PENDIENTE_DEPOSITO : {
                CODIGO : "05",
                REGISTRO_ESTADO : VAR_NO_REGISTRADO_REGISTRO,
                DEPOSITO_ESTADO : VAR_PENDIENTE_DEPOSITO,
                ESTADO_ACTUAL : VAR_NO_REGISTRADO_REGISTRO
            }
        }
    }
}

const SESSION = {
    USUARIO : {
        ID: "1"
    }
}

const LIQUIDACION = {
    ESTADO : {
        PENDIENTE : {
            CODIGO: "01",
            DESCRIPCION: "PENDIENTE"
        },
        APROBADO : {
            CODIGO: "02",
            DESCRIPCION: "APROBADO"
        },
        NO_FACTURADO : {
            CODIGO: "03",
            DESCRIPCION: "NO FACTURADO"
        }
    }
}

const DATABASE = {
    DATA_TYPE : {
        BIGINT: -5,
        BOOLEAN: 16,
        DATE: 91,
        DOUBLE: 8,
        INTEGER: 4,
        NULL: 0,
        VARCHAR: 12,
        TIMESTAMP_WHIT_TIMEZONE: 2014,
        TIMESTAMP: 93,
        ARRAY: 2003,
        BINARY: -2,
        BIT: -7,
        BLOB: 2004,
        CHAR: 1,
        DECIMAL: 3,
        FLOAT: 6,
        NCHAR: -15,
        NCLOB: 2011,
        VARBINARY: -3,
        TIME: 92,
        STRUCT: 2002,
        SQL_XML: 2009,
        NVARCHAR: -9,
        NUMERIC: 2,
        TINYINT: -6,
    }
}
const MOVIMIENTOS = {
    DEVOLUCION : {
        CODIGO : 1,
        NOMBRE : "DEVOLUCION"
    },
    RETORNO : {
        CODIGO : 2,
        NOMBRE : "RETORNO"
    },
    SOBRANTE : {
        CODIGO : 3,
        NOMBRE : "SOBRANTE"
    },
    ACTIVOS_SALIDA : {
        CODIGO  : 4,
        NOMBRE  : "ACTIVOS SALIDA"
    },
    ACTIVOS_ENTRADA : {
        CODIGO  : 5,
        NOMBRE  : "ACTIVOS ENTRADA"
    }

}
const CURRENT_ROLE = getCurrentRole();

const DEPOSITOS = {
    REEMP : {
        POSITION : 4,
        NOMBRE : "REEMP"
    },
    VUELTA_MATRIZ : {
        NOMBRE : "VUELTA MATRIZ"
    }
}

const ID_SUCURSAL = 1;


const ROLE_OPTIONS = {
    REGISTRO : {
        RETORNO : {
            PENDIENTE : {
                NUMERO : 1
            },
            APROBADO : {
                NUMERO : 2
            },
            RECHAZADO_DEPOSITO : {
                NUMERO : 3
            }
        },
        SOBRANTE : {
            PENDIENTE : {
                NUMERO : 1
            },
            APROBADO : {
                NUMERO : 2
            },
            RECHAZADO_DEPOSITO : {
                NUMERO : 3
            }
        },
        ACTIVOS_ENTRADA : {
            PENDIENTE : {
                NUMERO : 1
            },
            APROBADO : {
                NUMERO : 2
            },
            RECHAZADO_DEPOSITO : {
                NUMERO : 3
            }
        }
    },

    DEPOSITO : {
        RETORNO : {
            PENDIENTE : {
                NUMERO : 4
            },
            APROBADO : {
                NUMERO : 5
            },
            RECHAZADO_DEPOSITO : {
                NUMERO : 6
            }
        },
        SOBRANTE : {
            PENDIENTE : {
                NUMERO : 4
            },
            APROBADO : {
                NUMERO : 5
            },
            RECHAZADO_DEPOSITO : {
                NUMERO : 6
            }
        },
        ACTIVOS_SALIDA : {
            PENDIENTE : {
                NUMERO : 4
            },
            APROBADO : {
                NUMERO : 5
            }
        },
        ACTIVOS_ENTRADA : {
            PENDIENTE : {
                NUMERO : 4
            },
            APROBADO : {
                NUMERO : 5
            },
            RECHAZADO_DEPOSITO : {
                NUMERO : 6
            }
        }
    },

    LIQUIDACION : {
        RETORNO : {
            PENDIENTE : {
                NUMERO : 7
            },
            FACTURADO : {
                NUMERO : 8
            },
            NO_FACTURADO : {
                NUMERO : 9
            }
        },
        ACTIVOS_ENTRADA : {
            PENDIENTE : {
                NUMERO : 7
            },
            APROBADO : {
                NUMERO : 8
            },
            RECHAZADO_DEPOSITO : {
                NUMERO : 9
            }
        }
    }
}




const SOBRANTE = {
    ESTADO : {
        PENDIENTE_REGISTRO : {
            PENDIENTE_DEPOSITO : {
                CODIGO           : "01",
                REGISTRO_ESTADO  : VAR_PENDIENTE_REGISTRO,
                DEPOSITO_ESTADO  : VAR_PENDIENTE_DEPOSITO,
                ESTADO_ACTUAL    : VAR_PENDIENTE_REGISTRO
            }
        },
        APROBADO_REGISTRO : {
            PENDIENTE_DEPOSITO : {
                CODIGO           : "02",
                REGISTRO_ESTADO  : VAR_APROBADO_REGISTRO,
                DEPOSITO_ESTADO  : VAR_PENDIENTE_DEPOSITO,
                ESTADO_ACTUAL    : VAR_PENDIENTE_DEPOSITO
            },
            APROBADO_DEPOSITO : {
                CODIGO           : "03",
                REGISTRO_ESTADO  : VAR_APROBADO_REGISTRO,
                DEPOSITO_ESTADO  : VAR_APROBADO_DEPOSITO,
                ESTADO_ACTUAL    : VAR_FINALIZADO
            },
            RECHAZADO_DEPOSITO : {
                CODIGO           : "04",
                REGISTRO_ESTADO  : VAR_APROBADO_REGISTRO,
                DEPOSITO_ESTADO  : VAR_RECHAZADO_DEPOSITO,
                ESTADO_ACTUAL    : VAR_RECHAZADO_DEPOSITO
            }
        }
    }
}



const ACTIVOS_SALIDA = {
    ESTADO : {
        PENDIENTE_DEPOSITO : {
            CODIGO           : "01",
            DEPOSITO_ESTADO  : VAR_PENDIENTE_DEPOSITO,
            ESTADO_ACTUAL    : VAR_PENDIENTE_DEPOSITO
        },
        APROBADO_DEPOSITO : {
            CODIGO           : "02",
            DEPOSITO_ESTADO  : VAR_APROBADO_DEPOSITO,
            ESTADO_ACTUAL    : VAR_FINALIZADO
        }
    }
}

const ACTIVOS_ENTRADA = {
    ESTADO : {
        PENDIENTE_REGISTRO : {
            PENDIENTE_DEPOSITO : {
                CODIGO          : "01",
                REGISTRO_ESTADO : VAR_PENDIENTE_REGISTRO,
                DEPOSITO_ESTADO : VAR_PENDIENTE_DEPOSITO,
                ESTADO_ACTUAL   : VAR_PENDIENTE_REGISTRO
            }
        },
        APROBADO_REGISTRO : {
            PENDIENTE_DEPOSITO : {
                CODIGO           : "02",
                REGISTRO_ESTADO  : VAR_APROBADO_REGISTRO,
                DEPOSITO_ESTADO  : VAR_PENDIENTE_DEPOSITO,
                ESTADO_ACTUAL    : VAR_PENDIENTE_DEPOSITO
            },
            APROBADO_DEPOSITO : {
                CODIGO           : "03",
                REGISTRO_ESTADO  : VAR_APROBADO_REGISTRO,
                DEPOSITO_ESTADO  : VAR_APROBADO_DEPOSITO,
                ESTADO_ACTUAL    : VAR_FINALIZADO
            },
            RECHAZADO_DEPOSITO : {
                CODIGO           : "04",
                REGISTRO_ESTADO  : VAR_APROBADO_REGISTRO,
                DEPOSITO_ESTADO  : VAR_RECHAZADO_DEPOSITO,
                ESTADO_ACTUAL    : VAR_RECHAZADO_DEPOSITO
            },
        },
        NO_REGISTRADO_REGISTRO : {
            CODIGO              : "05",
            REGISTRO_ESTADO     : VAR_NO_REGISTRADO_REGISTRO,
            DEPOSITO_ESTADO     : VAR_PENDIENTE_DEPOSITO,
            ESTADO_ACTUAL       : VAR_NO_REGISTRADO_REGISTRO
        }
    }
}

const SUCURSAL_CONFIGURACION_DETALLE = {
    DEVOLUCION_DEPOSITO_UNIFICADO : {
        KEY : "devolucion.deposito.unificado"
    },
    NOMBRE_SUCURSAL : {
        KEY : "nombre.sucursal"
    }
}

