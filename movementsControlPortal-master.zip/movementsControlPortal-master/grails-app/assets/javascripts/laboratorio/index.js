function showDictamen(dictamenId){
    var url = getLaboratorioDictamenesDetallesShowURL();
    goToUrl(window.location, url+"/"+dictamenId);
}

function createDictamen(){
    var url = getLaboratorioDictamenesDetallesCreateURL();
    goToUrl(window.location, url);
}

