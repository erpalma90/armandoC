var select2Element;
function initJsPage(){
    //select2Element = jQuery(".js-example-basic-single");
    //getDictamenList(select2Element);
    loadDatePicker(getById("laboratorioDateId"), 1);
}
var dictamenResultList = null;
async function getDictamenList(select2Element, newFechaClassElement){
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    passData.query = "SELECT id, descripcion FROM laboratorio_dictamen ";
    if(dictamenResultList == null){
        dictamenResultList = await getDataFromQueryAjax(urlStr, passData)
    }
    //var select2Element = document.getElementById("dictamenMultiSelect2Id");
    var currentSelect2Element = jQuery(select2Element)
    for(var x = 0; x < dictamenResultList.length; x++){
        var dta = dictamenResultList[x];
        var optionElement = document.createElement("option")
        optionElement.appendChild(document.createTextNode(dta.descripcion));
        optionElement.value = dta.id
        currentSelect2Element.append(optionElement);
    }
    currentSelect2Element.select2()


    currentSelect2Element.on('select2:select', function (e) {
        var data = e.params.data;
        if(data.text == 'Vencido'){
            newFechaClassElement.style.display = ""
        }else{
            newFechaClassElement.style.display = "none"
        }
    });

}
var dictamenFinalResultList = null;
async function getDictamenFinalList(select2Element){
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    passData.query = "SELECT id, descripcion FROM laboratorio_destino_final ";
    if(dictamenFinalResultList == null){
        dictamenFinalResultList = await getDataFromQueryAjax(urlStr, passData)
    }
    //var select2Element = document.getElementById("dictamenMultiSelect2Id");

    var currentSelect2Element = jQuery(select2Element);
    for(var x = 0; x < dictamenFinalResultList.length; x++){
        var dta = dictamenFinalResultList[x];
        var optionElement = document.createElement("option")
        optionElement.appendChild(document.createTextNode(dta.descripcion));
        optionElement.value = dta.id
        currentSelect2Element.append(optionElement);
    }
    currentSelect2Element.select2()


}
/*
function showDictamen(devolucionId){
    var elements = document.getElementsByClassName("dictamenDivClass"+devolucionId);
    var elementsIcons = document.getElementsByClassName("dictamenResultDivClass"+devolucionId);
    for(var x = 0; x < elements.length; x++){
        var element = elements[x];
        var elementIcon = elementsIcons[x];
        if(element.style.display == 'none'){
            element.style.display = ''
            $(element).fadeIn(500);
            $(elementIcon).fadeOut(300);
        }else{
            //element.style.display = 'none'
            $(element).fadeOut(500);
            $(elementIcon).fadeIn(800);
        }
    }
}
*/



function cancellDictamen(devolucionDetalleId){
    getById("dictamenSaveCancellBtnId-"+devolucionDetalleId).style.display = "none";
    jQuery(".trDictamenClass-"+devolucionDetalleId+":visible").remove();
}

function updateDevolucionDictamen(devolucionDetalleId, devolucionId){
    var requiredFieldsOkFlag = validateRequiredFields("dictamenTBodyId-"+devolucionDetalleId);
    if(requiredFieldsOkFlag){
        var cantidadVerificada = getById("cantidadVerificadaId-"+devolucionDetalleId).getAttribute("attr-cantidadVerificada");
        var totalDictaminado = getCantidadTotalDictaminadaPorDevolucionDetalle(devolucionDetalleId);
        //parseInt(cantidadVerificada) >= parseInt(total)
        if(parseInt(cantidadVerificada) >= parseInt(totalDictaminado)){
            var passData = new Object();

            var trDictamenClassElements = jQuery(".trDictamenClass-"+devolucionDetalleId+":visible");
            var laboratorioDictamenPorDetalleObjList = [];
            var laboratorioDictamenPorDetObj;
            for(var x = 0; x < trDictamenClassElements.length; x++){
                var currentElement = trDictamenClassElements[x];
                var requiredFieldsOkFlag = validateRequiredFields("dictamenTBodyId-"+devolucionDetalleId);
                var cantidad = currentElement.getElementsByClassName("dictamenCantidad-class")[0].value;
                var dictamen = currentElement.getElementsByClassName("js-example-basic-single")[0].value;
                var laboratorioDestFinal = currentElement.getElementsByClassName("laboratorio-destino-final-select2-class")[0].value;
                var fechaVencimiento = currentElement.getElementsByClassName("fechaClassElement")[0].value;
                laboratorioDictamenPorDetObj = new Object();
                laboratorioDictamenPorDetObj.cantidad = cantidad;
                laboratorioDictamenPorDetObj.laboratorioDictamenId = dictamen;
                laboratorioDictamenPorDetObj.fechaVencimiento = fechaVencimiento;
                laboratorioDictamenPorDetObj.laboratorioDestinoFinalId = laboratorioDestFinal;
                laboratorioDictamenPorDetalleObjList.push(laboratorioDictamenPorDetObj);
                //toastTr('success', 'Actualizado', 'Dictamen actualizado');
            }
            var urlStr = getInsertOrUpdateLaboratorioDictamenListURL();
            passData.devolucionId = devolucionId;
            passData.devolucionDetalleId = devolucionDetalleId;
            passData.laboratorioDictamenPorDetalleObjList = JSON.stringify(laboratorioDictamenPorDetalleObjList);
            if(laboratorioDictamenPorDetalleObjList != null){
                jQuery.ajax({
                    url: urlStr,
                    type: 'GET',
                    async:true,
                    //dataType: 'json',
                    data: passData,
                    success: function(data) {
                        jQuery("#dictamenTdId-"+devolucionDetalleId).html(data);
                        toastTr('success', 'Dictaminado Exitosamente', 'Se aplico el dictamen');
                    },
                    error: function (dataError) {
                        swalNotification('top-center', 'error', dataError.responseText, 2000);
                        console.log(dataError.responseText);
                        dataToReturn = ERROR.AJAX_RETURN;
                    }
                });
            }
        }else{
            toastTr('warning', 'No se puede Guardar', 'La cantidad dictaminada no puede superar la cantidad a dictaminar');
        }
    }else{
        laboratorioDictamenPorDetalleObjList = null;
    }



}

function showDictamenTable(devolucionDetalleId){
    getById("dictamenDivId-"+devolucionDetalleId).classList.add("div-show-true");
    getById("addBtnDictamen-"+devolucionDetalleId).classList.add("showAddDictamenBtnClass-true");

    getById("dictamenDivId-"+devolucionDetalleId).classList.remove("div-show-false");
    getById("addBtnDictamen-"+devolucionDetalleId).classList.remove("showAddDictamenBtnClass-false");
}

function validateToHideDictamenTable(devolucionDetalleId){
    var laboratorioDictamenPorDetalleClassElements = jQuery(".laboratorioDictamenPorDetalleClass-"+devolucionDetalleId);
    if(laboratorioDictamenPorDetalleClassElements.length == 0){
        getById("dictamenDivId-"+devolucionDetalleId).classList.remove("div-show-true");
        getById("addBtnDictamen-"+devolucionDetalleId).classList.remove("showAddDictamenBtnClass-true");

        getById("dictamenDivId-"+devolucionDetalleId).classList.add("div-show-false");
        getById("addBtnDictamen-"+devolucionDetalleId).classList.add("showAddDictamenBtnClass-false");
    }
}

function addDictamen(devolucionDetalleId){
    if(getById("dictamenSaveCancellBtnId-"+devolucionDetalleId) != null && getById("dictamenSaveCancellBtnId-"+devolucionDetalleId) != undefined){
        getById("dictamenSaveCancellBtnId-"+devolucionDetalleId).style.display = "";
    }
    var trElement = document.getElementsByClassName("trDictamenClass-"+devolucionDetalleId)[0];
    var newTrElement = trElement.cloneNode(true);
    newTrElement.style.display = "";
    //newTrElement.setAttribute("class", "newTrClass")
    var tableElement = getById("dictamenTBodyId-"+devolucionDetalleId);
    tableElement.appendChild(newTrElement)
    var newDictamenSelect2 = newTrElement.getElementsByClassName("js-example-basic-single")
    var newDestFinalSelect2 = newTrElement.getElementsByClassName("laboratorio-destino-final-select2-class")
    var newFechaClassElement = newTrElement.getElementsByClassName("fechaClassElement")[0]
    var removeBtnElement = newTrElement.getElementsByClassName("removeIconClass")[0];
    //removeBtnElement.setAttribute("onclick", "")
    removeBtnElement.addEventListener('click', ()=>{
        removeDictamenItem(newTrElement, devolucionDetalleId)
    })

    getDictamenList(newDictamenSelect2, newFechaClassElement);
    getDictamenFinalList(newDestFinalSelect2);
    loadDatePicker(newFechaClassElement, 1)
}
function areYouShureDeleteLaboratorioDictamenPorDetalleFromId(id, devolucionDetalleId, devolucionId){
    var title = "Estas seguro?";
    var text = "Estas seguro de eliminar este item del dictamen?";
    var icon = 'warning'
    var confirmButtonText = "Si, eliminar";
    acceptOrCancellModal(title, text ,icon , confirmButtonText, function () { deleteLaboratorioDictamenPorDetalleFromId(id, devolucionDetalleId, devolucionId); });
}

function deleteLaboratorioDictamenPorDetalleFromId(id, devolucionDetalleId, devolucionId){
    var urlStr = getDeleteLaboratorioDictamenPorDetalleFromIdURL();
    var passData = new Object();
    passData.devolucionId = devolucionId;
    passData.devolucionDetalleId = devolucionDetalleId;
    passData.laboratorioDictamenPorDetalleId = id;
    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:true,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            jQuery("#dictamenTdId-"+devolucionDetalleId).html(data);
            toastTr('success', 'Exitosa Eliminacion', 'Se aplico la eliminacion del item del dictamen');
        },
        error: function (dataError) {
            swalNotification('top-center', 'error', dataError.responseText, 2000);
            console.log(dataError.responseText);
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
}
function areYouShureSaveLaboratorioDictamen(operation){
    var cantidadDiferencias = validateMatchQuantities();
    if(cantidadDiferencias > 0){
        swalNotification('top-center', 'warning', 'Existen '+cantidadDiferencias+' productos con cantidades pendientes, favor cerrar las cantidades', 5000);
    }else{
        var title = "Estas seguro?";
        var text = "";
        var confirmButtonText = "";
        if(operation == "I"){
            text = "Estas seguro que deseas guardar el dictamen de la fecha "+getById("laboratorioDateId").value+"?";
            confirmButtonText = "Si, guardar";
        }else if(operation == "U"){
            text = "Estas seguro que deseas actualizar el dictamen de la fecha "+getById("laboratorioDateId").value+"?";
            confirmButtonText = "Si, actualizar";
        }
        var icon = 'warning'
        acceptOrCancellModal(title, text ,icon , confirmButtonText, function(){saveLaboratorio(operation)});
    }
}

function saveLaboratorio(operation){
    showSpinner();
    var laboratorioDate = getById("laboratorioDateId").value;
    var urlStr = getSaveLaboratorioDictamenCabURL();
    var passData = new Object();
    passData.laboratorioDate = laboratorioDate;
    passData.observacion = "";
    if(operation == "I"  || operation == "U"){
        passData.laboratorioDictamenCabId = getLaboratorioDictamenCabId();
    }

    passData.operation = operation;
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:true,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                goToUrl(getLaboratorioDictamenesDetallesIndexURL(), getLaboratorioDictamenesDetallesShowURL()+"/"+data, true);
            }else{
                alert('No se pudo guardar la devolucion: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function (dataError) {
            swalNotification('top-center', 'error', dataError.responseText, 2000);
            console.log(dataError.responseText);
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
}

function getCantidadTotalDictaminadaPorDevolucionDetalle(devolucionDetalleId){
    var elementos = jQuery(".cantidadDictaminadaClass-"+devolucionDetalleId+":visible")
    var total = 0;
    for(var x = 0; x < elementos.length; x++){
        var elemento = elementos[x];
        total = parseInt(total)+parseInt(elemento.value);
    }
    return total;
}

function removeDictamenItem(element, devolucionDetalleId){
    jQuery(element).remove();

    var laboratorioDictamenPorDetalleClassElements = jQuery(".laboratorioDictamenPorDetalleClass-"+devolucionDetalleId);

    var trDictamenClassElements = jQuery(".trDictamenClass-"+devolucionDetalleId+":visible");
    if((laboratorioDictamenPorDetalleClassElements == undefined || laboratorioDictamenPorDetalleClassElements.length == 0) &&
        trDictamenClassElements.length == 0){
        getById("dictamenDivId-"+devolucionDetalleId).classList.remove("div-show-true");
        getById("addBtnDictamen-"+devolucionDetalleId).classList.remove("showAddDictamenBtnClass-true");

        getById("dictamenDivId-"+devolucionDetalleId).classList.add("div-show-false");
        getById("addBtnDictamen-"+devolucionDetalleId).classList.add("showAddDictamenBtnClass-false");
    }

}


function validateMatchQuantities(){
    var sb = new StringBuilder();
    sb.append("SELECT count(dd.*) FROM devolucion_detalle dd ");
    sb.append("JOIN laboratorio_dictamen_por_detalle ldpd ON ldpd.devolucion_detalle_id = dd.id ");
    sb.append("WHERE laboratorio_dictamen_cab_id IS NULL ");
    sb.append("GROUP BY dd.id ");
    sb.append("HAVING dd.cantidad_verificada > SUM(ldpd.cantidad) ");
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    passData.query = sb.toString();
    var result = getDataFromQueryAjax(urlStr, passData)

    return result.length
}

function editDictamen(id){
    showSpinner();
    var url = getLaboratorioDictamenesDetallesEditURL()+"/"+id;
    goToUrl(window.location, url);
}

function areYouShureDeleteDictamen(laboratorioDictamenCabId){
    var title = "Estas seguro?";
    var text = "Estas seguro que deseas Eliminar el dictamen?";
    var confirmButtonText = "Si, eliminar";
    var icon = 'warning'
    acceptOrCancellModal(title, text ,icon , confirmButtonText, function(){deleteLaboratorioDictamen(laboratorioDictamenCabId)});
}

function deleteLaboratorioDictamen(laboratorioDictamenCabId){
    showSpinner();
    var urlStr = getLaboratorioDictamenesDetallesDeleteURL();
    var passData = new Object();
    passData.id = laboratorioDictamenCabId;
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:true,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                goToUrl(null, getLaboratorioDictamenesDetallesIndexURL(), false);
            }else{
                alert('No se pudo eliminar el dictamen: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function (dataError) {
            swalNotification('top-center', 'error', dataError.responseText, 2000);
            console.log(dataError.responseText);
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
}

function printLaboratorioDictamenCabDocument(laboratorioDictamenCabId, fechaDictamen){
    var userName = getLoggedUsername();
    document.title= "LaboratorioDictamen_id"+laboratorioDictamenCabId+"_"+userName+"_"+fechaDictamen;
    window.print();
    return false;
}

