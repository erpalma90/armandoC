async function cargarTablaRetornos(fleteroId){
    var urlStr = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT r.id, c.razon_social, re.estado_actual as retorno_estado_descripcion, re.codigo as retorno_estado_codigo, ");
    sb.append("r.factura_nro, r.factura_fecha, r.fecha_retorno FROM retorno r ");
    sb.append("LEFT JOIN gc_clientes c ON c.id = gc_cliente_id ");
    sb.append("JOIN retorno_estados re ON re.id = r.retorno_estado_id ");
    sb.append("LEFT JOIN liquidacion l ON l.id = r.liquidacion_id ")
    sb.append("LEFT JOIN liquidacion_estado le ON le.id = l.liquidacion_estado_id ");
    sb.append("WHERE 1=1 ");
    var filterSb = new StringBuilder();
    if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
        var status1 = RETORNO.ESTADO.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.CODIGO;
        var status2 = RETORNO.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO;
        filterSb.append("AND re.codigo in('"+status1+"', '"+status2+"') ");
    }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
        var status1 = RETORNO.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO;
        filterSb.append("AND re.codigo in('"+status1+"') ");
    }else if(CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
        filterSb.append("AND (le.codigo = '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"' OR le.codigo IS NULL) ");
        filterSb.append("AND re.codigo = '"+RETORNO.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"' ");
    }

    sb.append(filterSb.toString());
    sb.append("AND r.gc_fletero_id = ? ");
    //sb.append("ORDER BY d.fecha DESC ");

    passData.query = sb.toString();
    var argsToSet = setDatosRetorno(fleteroId);
    passData.argsToSet = JSON.stringify(argsToSet);
    dtoList = await getDataFromQueryAjax(urlStr, passData)

    var tbodyElement = getById("retornosTbodyId");
    var originalTrElement = getById("retornosTableTrId");
    for(var x = 0; x < dtoList.length; x++){
        var dto = dtoList[x];
        dto.retornoCheckActionElement = "check-"+dto.id
        dto.fecha_retorno = formatterDate(dto.fecha_retorno, 'DD-MM-YYYY HH:mm')
        dto.goToShow = "goToShow-"+dto.id


        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.id = MOVIMIENTOS.RETORNO.CODIGO+"-"+dto.id;
        newTrElement.setAttribute("attr-id", dto.id);
        newTrElement.style.display = "";
        var tdColorClass = ""
        if(dto.retorno_estado_codigo == RETORNO.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO){
            tdColorClass = "table-danger"
        }
        newTrElement.setAttribute("class", "retornoTrGeneradoClass "+tdColorClass);
        setDataInTableTd(newTrElement, dto)
        tbodyElement.appendChild(newTrElement)
    }

    retornoDataTableInitialize();
    return dtoList.length;
}


async function retornoDataTableInitialize(){

    var table = $('#retornoDataTableId').DataTable();

    jQuery('#retornoDataTableId tbody').on('click', 'td.details-control', async function () {
        //recuperamos el id de la devolucion
        // Get the rows id value
        //table.row(this).setAttribute("attr-showed", true);
        var tableId = table.row(this).id();
        var trElement = getById(tableId);
        trElement.setAttribute("attr-showed", "true");
        var id = trElement.getAttribute("attr-id");
        id = id.replace(/\D/g, '');
        id = parseInt(id, 10);
        var tr = jQuery(this).closest('tr');
        var row = table.row(tr);
        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        } else {
            var urlStr = getGetDataFromQueryURL();
            var passData = {};
            var sb = new StringBuilder();
            sb.append("SELECT p.id, p.codigo_barra, p.producto, rd.cantidad_documentada_ret, mr.descripcion as retorno_motivo, ");
            sb.append("rd.cantidad_verificada_ret ");
            sb.append("FROM retorno_detalle rd ");
            sb.append("JOIN gc_productos p ON p.id = rd.gc_productos_id ");
            sb.append("LEFT JOIN gc_motivo_retorno mr ON mr.id = rd.gc_motivo_retorno_id ");
            sb.append("WHERE rd.retorno_id = ");
            sb.append(id+" ");

            //passData.query = "SELECT p.id, p.codigo_barra, p.producto, dd.cantidad FROM devolucion_detalle dd JOIN gc_productos p ON p.id = dd.producto_id WHERE devolucion_id = "+id+")"
            passData.query = sb.toString();
            var productosDtoList = await getDataFromQueryAjax(urlStr, passData)
            row.child(retornoFormat(productosDtoList)).show();
            tr.addClass('shown');
        }

    });


}

/* Formatting function for row details - modify as you need */
function retornoFormat(dataDtoList) {
    var filaSb = new StringBuilder();
    if (dataDtoList != '') {
        for (var dataDto in dataDtoList) {
            var data = dataDtoList[dataDto];
            if(data.codigo_barra == null || data.codigo_barra == undefined){
                data.codigo_barra = "";
            }
            if(data.observacion == null || data.observacion == undefined){
                data.observacion = "";
            }

            filaSb.append("<tr>")
            filaSb.append("     <td>"+data.id+"</td>");
            filaSb.append("     <td>"+data.codigo_barra+"</td>");
            filaSb.append("     <td>"+data.producto+"</td>");

            if(CURRENT_ROLE == ROLES.ROLE_ADMIN || CURRENT_ROLE == ROLES.ROLE_REGISTRO ||
                CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
                filaSb.append("     <td>"+data.cantidad_documentada_ret+"</td>");
            }else{
                filaSb.append("     <td>"+data.cantidad_verificada_ret+"</td>");
            }
            filaSb.append("     <td>"+data.retorno_motivo+"</td>");

            filaSb.append("</tr>")




        }
        return '<table style="width:100%" id="example" class="display">' +
            '<thead>' +
            '<tr>' +
            '<th>Producto ID</th>' +
            '<th>Codigo Barra</th>' +
            '<th>Descripcion</th>' +
            '<th>Cant.Ret.</th>' +
            '<th>Motivo Ret</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>' +
            filaSb.toString() +
            '</tbody>' +
            '</table>';
    }
}



/**************************************DEPOSITO********************************************/
function areYouShureRetornoAprovvedModal(funcionActualizacion){
    var title = "Estas seguro? ";
    var text = "Estas seguro de realizar la aprobacion del retorno?";
    var icon = 'warning'
    var confirmButtonText = "Si, aprobar";

}

function areYouShureRetornoAprovvedModalInMovimientosPorFletero(){
    acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la aprobacion del retorno?" ,'warning' ,
        "Si, aprobar", function () {return actualizacionMasivaRetornos()});
}

async function actualizacionMasivaRetornos(){
    var checkActionElementList = jQuery(".retornoCheckActionElement:checked");
    if(checkActionElementList.length > 0){
        for(var x = 0; x < checkActionElementList.length; x++){
            var checkActionElement = checkActionElementList[x];
            var retornoId = checkActionElement.getAttribute("attr-id");
            await actualizacionDeRetornoEstado(ACCION_APROBAR, retornoId);
        }

    }else{
        toastTr('warning', '!', 'Seleccionar items para aprobación');
    }
}

function createShowRetornosFromFletero(){
    var fleteroId = getCurrentFleteroId();
    var urlStr = getGetAllRetornosFromFleteroIdURL();
    var passData = new Object();
    passData.retornoEstado = RETORNO.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO;
    passData.liquidacionEstado = LIQUIDACION.ESTADO.PENDIENTE.CODIGO;
    passData.fleteroId = fleteroId;
    var dataToReturn = null;
    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:false,
        //dataType: 'json',
        data: passData,
        success: function(data) {
            jQuery("#retornosFromFleterosDataId").html(data);
            jQuery("#retornosFromFleteroIdModalId").modal();
        },
        error: function () {
            alert("error")
            dataToReturn = ERROR.AJAX_RETURN;
        }
    });
}