async function initJsPage(){
    //var cantidadDevolucionDelFletero = getCantidadDevolucionDelFletero();
    //alert("cantidadDevolucionDelFletero: "+cantidadDevolucionDelFletero)
    var nombreFletero = getNombreFletero();
    jQuery("#nombreFleteroId").html(nombreFletero);
    var fleteroId = getCurrentFleteroId();
    $.noConflict();
    var cantidadDevoluciones    = await cargarTablaDevoluciones(fleteroId);
    var cantidadRetornos        = await cargarTablaRetornos(fleteroId);
    var cantidadSobrante        = await cargarTablaSobrantes(fleteroId);
    var cantidadActivosEntrada  = await cargarTablaActivosEntrada(fleteroId);
    var devolucionesTabElement          = getById("devoluciones-tab");
    var devolucionesTabContainElement   = getById("devolucionesTabContainId");
    var retornosTabElement              = getById("retornos-tab");
    var retornosTabContainElement       = getById("retornosTabContainId");
    var sobrantesTabElement             = getById("sobrantes-tab");
    var sobrantesTabContainElement      = getById("sobrantesTabContainId");
    var activosEntradaTabElement        = getById("activosEntrada-tab");
    var activosEntradaTabContainElement = getById("activosEntradaTabContainId");

    if(cantidadDevoluciones == 0){
        devolucionesTabElement.setAttribute("class", "");
        devolucionesTabElement.setAttribute("aria-selected", "false");
        devolucionesTabContainElement.classList.remove("active");
        devolucionesTabContainElement.classList.remove("show");

    }else{
        devolucionesTabElement.style.display = ""
    }


    if(cantidadRetornos == 0){
        retornosTabElement.setAttribute("class", "");
        retornosTabElement.setAttribute("aria-selected", "false");
        retornosTabContainElement.classList.remove("active");
        retornosTabContainElement.classList.remove("show");
        if(getById("showRetornosFromFleteroBtnId") != null && getById("showRetornosFromFleteroBtnId") != undefined){
            getById("showRetornosFromFleteroBtnId").style.display = "none";
        }
    }else{
        if(getById("showRetornosFromFleteroBtnId") != null && getById("showRetornosFromFleteroBtnId") != undefined){
            getById("showRetornosFromFleteroBtnId").style.display = "";
        }
        if(cantidadDevoluciones == 0){
            retornosTabElement.setAttribute("class", "active");
            retornosTabElement.setAttribute("aria-selected", "true");
            retornosTabContainElement.classList.add("active");
            retornosTabContainElement.classList.add("show");
        }
        retornosTabElement.style.display = ""
    }


    if(cantidadSobrante == 0){
        sobrantesTabElement.setAttribute("class", "");
        sobrantesTabElement.setAttribute("aria-selected", "false");
        sobrantesTabContainElement.classList.remove("active");
        sobrantesTabContainElement.classList.remove("show");
    }else{
        if(cantidadDevoluciones == 0 && cantidadRetornos == 0){
            sobrantesTabElement.setAttribute("class", "active");
            sobrantesTabElement.setAttribute("aria-selected", "true");
            sobrantesTabContainElement.classList.add("active");
            sobrantesTabContainElement.classList.add("show");
        }
        sobrantesTabElement.style.display = ""
    }

    if(cantidadActivosEntrada == 0){
        activosEntradaTabElement.setAttribute("class", "");
        activosEntradaTabElement.setAttribute("aria-selected", "false");
        activosEntradaTabContainElement.classList.remove("active");
        activosEntradaTabContainElement.classList.remove("show");
    }else{
        if(cantidadDevoluciones == 0 && cantidadRetornos == 0 && cantidadSobrante == 0){
            activosEntradaTabElement.setAttribute("class", "active");
            activosEntradaTabElement.setAttribute("aria-selected", "true");
            activosEntradaTabContainElement.classList.add("active");
            activosEntradaTabContainElement.classList.add("show");
        }
        activosEntradaTabElement.style.display = ""
    }


    $(function() {
        $('.btn-group-fab').on('click', '.btn', function() {
            $('.btn-group-fab').toggleClass('active');
        });
        $('has-tooltip').tooltip();
    });
}


async function cargarTablaDevoluciones(fleteroId){

    var urlStr = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT distinct(d.id), d.fletero_id as fletero_id, f.fletero, d.cliente_id, c.razon_social, d.con_snc, d.devolucion_estado_id, ");
    var devolucionEstado = "de.estado_actual"
    sb.append(devolucionEstado+" ");
    sb.append("as devolucion_estado_descripcion, de.codigo as devolucion_estado_codigo, d.metodo_de_carga_id, ");
    sb.append("dmc.descripcion as devolucion_metodo_carga_descripcion, d.factura_nro, ");
    sb.append("d.fecha, d.snc_nro ")
    sb.append("FROM devolucion d ");
    sb.append("JOIN gc_fletero f ON f.id = d.fletero_id ");
    sb.append("LEFT JOIN gc_clientes c ON d.cliente_id = c.id ");
    sb.append("LEFT JOIN devolucion_estados de ON de.id = d.devolucion_estado_id ");
    sb.append("LEFT JOIN devolucion_metodo_de_carga dmc ON dmc.id = d.metodo_de_carga_id ");
    sb.append("LEFT JOIN liquidacion l ON l.id = d.liquidacion_id ")
    sb.append("LEFT JOIN liquidacion_estado le ON le.id = l.liquidacion_estado_id ");
    sb.append("LEFT JOIN devolucion_detalle dd ON dd.devolucion_id = d.id ")
    sb.append("WHERE 1=1 ");
    var filterSb = new StringBuilder();
    if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
        var status1 = DEVOLUCION.ESTADOS.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO;
        var status2 = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.LABORATORIO.CODIGO;
        filterSb.append("AND de.codigo in('"+status1+"', '"+status2+"') ");
    }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
        var status1 = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO;
        filterSb.append("AND de.codigo in('"+status1+"') ");
    }else if(CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
        filterSb.append("AND (le.codigo = '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"' OR le.codigo IS NULL) ");
        filterSb.append("AND (de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO +"' ");
        filterSb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.DERRAME_LABORATORIO.CODIGO +"' ");
        filterSb.append("OR de.codigo = '"+DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.STOCK_LABORATORIO.CODIGO +"') ");
        filterSb.append("AND dd.cantidad_documentada != dd.cantidad_verificada ");
    }


    sb.append(filterSb.toString())
    sb.append("AND d.fletero_id = ? AND transferencia_filial IS NOT TRUE ");
    sb.append("ORDER BY d.fecha DESC ");

    passData.query = sb.toString();
    var argsToSet = setDatosDevolucion(fleteroId);
    passData.argsToSet = JSON.stringify(argsToSet);
    devolucionesDtoList = await getDataFromQueryAjax(urlStr, passData)

    var tbodyElement = getById("devolucionesTbodyId");
    var originalTrElement = getById("devolucionesTableTrId");
    for(var x = 0; x < devolucionesDtoList.length; x++){
        var dto = devolucionesDtoList[x];
        dto.checkActionElement = "check-"+dto.id
        dto.fecha = formatterDate(dto.fecha, 'DD-MM-YYYY HH:mm')
        dto.goToShow = "goToShow-"+dto.id
        if(dto.con_snc == true){
            dto.con_snc = "Si"
        }else{
            dto.con_snc = "No"
        }
        if(dto.snc_nro == null){
            dto.snc_nro = ""
        }

        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.id = MOVIMIENTOS.DEVOLUCION.CODIGO+"-"+dto.id;
        newTrElement.style.display = "";
        newTrElement.setAttribute("attr-id", dto.id)
        var tdColorClass = ""
        if(dto.devolucion_estado_codigo == DEVOLUCION.ESTADOS.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.LABORATORIO.CODIGO){
            tdColorClass = "table-danger"
        }
        newTrElement.setAttribute("class", "devolucionTrGeneradoClass "+tdColorClass);
        setDataInTableTd(newTrElement, dto)
        tbodyElement.appendChild(newTrElement)
    }
    devolucionDataTableInitialize()
    /*
    if(devolucionesDtoList.length > 0){
        getById("devolucionesTabId").style.display = "block";
        getById("devolucionesTabContainId").style.display = "block";
    }
    */
    return devolucionesDtoList.length;
}

function setDatosDevolucion(fleteroId){
    var columnsMap = new Map();
    columnsMap.set(1, [fleteroId, DATABASE.DATA_TYPE.BIGINT]);
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;

}
function setDatosRetorno(fleteroId){
    var columnsMap = new Map();
    columnsMap.set(1, [fleteroId, DATABASE.DATA_TYPE.BIGINT]);
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;

}


async function devolucionDataTableInitialize(){
    //$.noConflict();
    var table = $('#devolucionDataTableId').DataTable();
    // Add event listener for opening and closing details
    jQuery('#devolucionDataTableId tbody').on('click', 'td.details-control', async function () {
        //recuperamos el id de la devolucion
        // Get the rows id value
        //table.row(this).setAttribute("attr-showed", true);
        var trId = table.row(this).id();
        var trElement = getById(trId);
        trElement.setAttribute("attr-showed", "true");
        var id = trElement.getAttribute("attr-id");
        id = parseInt(id, 10);
        var tr = jQuery(this).closest('tr');
        var row = table.row(tr);
        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        } else {
            var urlStr = getGetDataFromQueryURL();
            var passData = {};
            var sb = new StringBuilder();
            sb.append("SELECT p.id, p.codigo_barra, p.producto, dd.cantidad_documentada, dm.devolucion_motivo, ");
            sb.append("dd.nro_documento_relacionado, dd.cantidad_verificada, dd.observacion ");
            sb.append("FROM devolucion_detalle dd JOIN gc_productos p ON p.id = dd.producto_id LEFT JOIN devolucion_motivos dm ON dm.id = dd.motivo_devolucion_documentada_id ");
            sb.append("WHERE devolucion_id = ")
            sb.append(id)
            if(CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
                sb.append("AND dd.cantidad_documentada != dd.cantidad_verificada ")
            }
            //passData.query = "SELECT p.id, p.codigo_barra, p.producto, dd.cantidad FROM devolucion_detalle dd JOIN gc_productos p ON p.id = dd.producto_id WHERE devolucion_id = "+id+")"
            passData.query = sb.toString();
            var productosDtoList = await getDataFromQueryAjax(urlStr, passData)
            row.child(format(productosDtoList)).show();
            tr.addClass('shown');
        }
    });
}

/* Formatting function for row details - modify as you need */
function format(dataDtoList) {
    var filaSb = new StringBuilder();
    if (dataDtoList != '') {
        for (var dataDto in dataDtoList) {
            var data = dataDtoList[dataDto]
            if(data.nro_documento_relacionado == null || data.nro_documento_relacionado == undefined){
                data.nro_documento_relacionado = "";
            }
            if(data.codigo_barra == null || data.codigo_barra == undefined){
                data.codigo_barra = "";
            }
            if(data.observacion == null || data.observacion == undefined){
                data.observacion = "";
            }


            filaSb.append("<tr>")
            filaSb.append("     <td>"+data.id+"</td>");
            filaSb.append("     <td>"+data.codigo_barra+"</td>");
            filaSb.append("     <td>"+data.producto+"</td>");
            filaSb.append("     <td>");
            if(CURRENT_ROLE == ROLES.ROLE_ADMIN || CURRENT_ROLE == ROLES.ROLE_REGISTRO ||
                CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
                if(data.cantidad_documentada != data.cantidad_verificada){
                    filaSb.append("<div class = 'row p-0'> ");
                    filaSb.append("     <div class = 'col-4 bg-success p-0'> ");
                    filaSb.append("             Doc. ");
                    filaSb.append("     </div> ");
                    filaSb.append("     <div class = 'col-4 bg-warning p-0'> ");
                    filaSb.append("             Verf.");
                    filaSb.append("     </div> ");
                    filaSb.append("     <div class = 'col-4 bg-danger p-0'> ");
                    filaSb.append("             Falt.");
                    filaSb.append("     </div> ");
                    filaSb.append("</div>");
                    filaSb.append("<div class = 'row p-0'> ");
                    filaSb.append("     <div class = 'col-4 table-success p-0'> ");
                    filaSb.append("             "+data.cantidad_documentada);
                    filaSb.append("     </div> ");
                    filaSb.append("     <div class = 'col-4 table-warning p-0'> ");
                    filaSb.append("             "+data.cantidad_verificada);
                    filaSb.append("     </div> ");
                    filaSb.append("     <div class = 'col-4 table-danger p-0'> ");
                    var faltante = parseInt(data.cantidad_documentada)-parseInt(data.cantidad_verificada)
                    filaSb.append("             "+ faltante);
                    filaSb.append("     </div> ");
                    filaSb.append("</div>");
                }else{
                    filaSb.append("     "+data.cantidad_documentada);
                }
            }else{
                //filaSb.append("     "+data.cantidad_verificada);
            }

            filaSb.append("     </td>");
            filaSb.append("     <td>"+data.devolucion_motivo+"</td>");
            filaSb.append("     <td>"+data.nro_documento_relacionado+"</td>");
            filaSb.append("     <td>"+data.observacion+"</td>");
            filaSb.append("</tr>")




        }
        return '<table style="width:100%" id="example" class="display">' +
            '<thead>' +
            '<tr>' +
            '<th>Producto ID</th>' +
            '<th>Codigo Barra</th>' +
            '<th>Descripcion</th>' +
            '<th>Unid.</th>' +
            '<th>Motivo Devolucion</th>' +
            '<th>Factura</th>' +
            '<th>Observacion</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>' +
            filaSb.toString() +
            '</tbody>' +
            '</table>';
    }
}

async function validarContraseñaFleteroYActualizacionMasiva(){
    var checkActionElementList = jQuery(".checkActionElement:checked");
    if(checkActionElementList.length > 0){
        var okFleteroPassFlag = await validarContraseñaFletero();
        if(okFleteroPassFlag){
            await actualizacionMasivaDeEstado(1);
        }
    }else{
        toastTr('warning', '!', 'Seleccionar items para aprobación');
    }
}
function devolucionStatusApproved(){
    actualizacionMasivaDeEstado(1)
}
async function actualizacionMasivaDeEstado(value){
    try {
        showSpinner();
        //$( "input:checked" )
        var checkActionElementList = jQuery(".checkActionElement:checked");
        var devolucionesSeleccionadasId = new StringBuilder();
        for(var x = 0; x < checkActionElementList.length; x++){
            var checkElement = checkActionElementList[x];
            var devolucionId = checkElement.getAttribute("attr-id");
            devolucionesSeleccionadasId.append(devolucionId+",");
        }
        var devSelectedId = devolucionesSeleccionadasId.toString().substring(0, devolucionesSeleccionadasId.toString().length-1);
        var passData = new Object();
        passData.checkedList = devSelectedId;
        var newStatus = "";
        if(value == 1){
            if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
                newStatus = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO;
                if(SUCURSAL_CONFIGURACION_DETALLE_DEVOLUCION_DEPOSITO_UNIFICADO_KEY == 'true'){
                    newStatus = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO;
                }
            }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
                newStatus = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO;
            }
        }else{
            if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || currentRole == ROLES.ROLE_ADMIN){
                newStatus = DEVOLUCION.ESTADOS.NO_REGISTRADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO;
            }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
                newStatus = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.LABORATORIO.CODIGO;
            }
        }
        passData.nuevoEstadoDevolucion = newStatus;
        var dataReturn = await getDataFromQueryAjax(updateAprobacionDevolucionUrl(), passData, reloadPage());
    }catch (error){
        hideSpinner();
        console.log("Error accionAprobar: "+error)
    }
}

function reloadPage(){
    location.reload();
}