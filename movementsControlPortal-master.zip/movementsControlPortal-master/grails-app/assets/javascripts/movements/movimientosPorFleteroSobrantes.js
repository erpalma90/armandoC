async function cargarTablaSobrantes(fleteroId){
    var urlStr = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT s.id, se.estado_actual as sobrante_estado_descripcion, se.codigo as sobrante_estado_codigo, ");
    sb.append("s.fecha_sobrante FROM sobrante s ");
    sb.append("JOIN sobrante_estados se ON se.id = s.sobrante_estados_id ");
    sb.append("WHERE 1=1 ");
    var filterSb = new StringBuilder();
    if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
        var status1 = SOBRANTE.ESTADO.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.CODIGO;
        var status2 = SOBRANTE.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO;
        filterSb.append("AND se.codigo in('"+status1+"', '"+status2+"') ");
    }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
        var status1 = SOBRANTE.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO;
        filterSb.append("AND se.codigo in('"+status1+"') ");
    }

    sb.append(filterSb.toString());
    sb.append("AND s.gc_fletero_id = ? ");

    passData.query = sb.toString();
    var argsToSet = setDatosRetorno(fleteroId);
    passData.argsToSet = JSON.stringify(argsToSet);
    dtoList = await getDataFromQueryAjax(urlStr, passData)

    var tbodyElement = getById("sobrantesTbodyId");
    var originalTrElement = getById("sobrantesTableTrId");
    for(var x = 0; x < dtoList.length; x++){
        var dto = dtoList[x];
        dto.sobrantesCheckActionElement = "check-"+dto.id
        dto.goToShow = "goToShow-"+dto.id
        dto.fecha_sobrante = formatterDate(dto.fecha_sobrante, 'DD-MM-YYYY HH:mm')

        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.id = MOVIMIENTOS.SOBRANTE.CODIGO+"-"+dto.id;
        newTrElement.setAttribute("attr-id", dto.id);
        newTrElement.style.display = "";
        var tdColorClass = ""
        if(dto.sobrante_estado_codigo == SOBRANTE.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO){
            tdColorClass = "table-danger"
        }
        newTrElement.setAttribute("class", "sobranteTrGeneradoClass "+tdColorClass);
        setDataInTableTd(newTrElement, dto)
        tbodyElement.appendChild(newTrElement)
    }

    sobranteDataTableInitialize();
    return dtoList.length;
}

async function sobranteDataTableInitialize(){

    var table = $('#sobranteDataTableId').DataTable();

    jQuery('#sobranteDataTableId tbody').on('click', 'td.details-control', async function () {
        //recuperamos el id de la devolucion
        // Get the rows id value
        //table.row(this).setAttribute("attr-showed", true);
        var tableId = table.row(this).id();
        var trElement = getById(tableId);
        trElement.setAttribute("attr-showed", "true");
        var id = trElement.getAttribute("attr-id");
        id = id.replace(/\D/g, '');
        id = parseInt(id, 10);
        var tr = jQuery(this).closest('tr');
        var row = table.row(tr);
        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        } else {
            var urlStr = getGetDataFromQueryURL();
            var passData = {};
            var sb = new StringBuilder();
            sb.append("SELECT p.id, p.codigo_barra, p.producto, sd.cantidad_documentada ");
            sb.append("FROM sobrante_detalle sd ");
            sb.append("JOIN gc_productos p ON p.id = sd.gc_producto_id ");
            sb.append("WHERE sd.sobrante_id = ");
            sb.append(id+" ");

            //passData.query = "SELECT p.id, p.codigo_barra, p.producto, dd.cantidad FROM devolucion_detalle dd JOIN gc_productos p ON p.id = dd.producto_id WHERE devolucion_id = "+id+")"
            passData.query = sb.toString();
            var productosDtoList = await getDataFromQueryAjax(urlStr, passData)
            row.child(sobranteFormat(productosDtoList)).show();
            tr.addClass('shown');
        }

    });


}

function sobranteFormat(dataDtoList) {
    var filaSb = new StringBuilder();
    if (dataDtoList != '') {
        for (var dataDto in dataDtoList) {
            var data = dataDtoList[dataDto];
            if(data.codigo_barra == null || data.codigo_barra == undefined){
                data.codigo_barra = "";
            }
            if(data.observacion == null || data.observacion == undefined){
                data.observacion = "";
            }

            filaSb.append("<tr>")
            filaSb.append("     <td>"+data.id+"</td>");
            filaSb.append("     <td>"+data.codigo_barra+"</td>");
            filaSb.append("     <td>"+data.producto+"</td>");

            if(CURRENT_ROLE == ROLES.ROLE_ADMIN || CURRENT_ROLE == ROLES.ROLE_REGISTRO ||
                CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
                filaSb.append("     <td>"+data.cantidad_documentada+"</td>");
            }

            filaSb.append("</tr>")




        }
        return '<table style="width:100%" id="example" class="display">' +
            '<thead>' +
            '<tr>' +
            '<th>Producto ID</th>' +
            '<th>Codigo Barra</th>' +
            '<th>Descripcion</th>' +
            '<th>Cant.</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>' +
            filaSb.toString() +
            '</tbody>' +
            '</table>';
    }
}

function areYouShureSobranteAprovvedModalInMovimientosPorFletero(){
    acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la aprobacion del sobrante?" ,'warning' ,
        "Si, aprobar", function () {return actualizacionMasivaSobrantes()});
}
async function actualizacionMasivaSobrantes(){
    var checkActionElementList = jQuery(".sobrantesCheckActionElement:checked");
    if(checkActionElementList.length > 0){
        for(var x = 0; x < checkActionElementList.length; x++){
            var checkActionElement = checkActionElementList[x];
            var sobranteId = checkActionElement.getAttribute("attr-id");
            await actualizacionDeSobranteEstado(ACCION_APROBAR, sobranteId);
        }

    }else{
        toastTr('warning', '!', 'Seleccionar items para aprobación');
    }
}