async function cargarTablaActivosEntrada(fleteroId){
    var urlStr = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();

    sb.append("SELECT ae.id, aee.estado_actual as activos_entrada_estado_descripcion, aee.codigo as activos_entrada_estado_codigo, ");
    sb.append("ae.fecha FROM activos_entrada ae ");
    sb.append("LEFT JOIN activos_entrada_detalle aed ON aed.activos_entrada_id = ae.id ")
    sb.append("JOIN activos_entrada_estados aee ON aee.id = ae.activos_entrada_estado_id ");
    sb.append("LEFT JOIN liquidacion l ON l.activos_entrada_id = ae.id ");
    sb.append("LEFT JOIN liquidacion_estado le ON le.id = l.liquidacion_estado_id ");
    sb.append("WHERE 1=1 ");


    var filterSb = new StringBuilder();
    var list = [];
    if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
        list.push(ACTIVOS_ENTRADA.ESTADO.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.CODIGO);
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO);
    }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.CODIGO);
    }else if(CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
        sb.append("AND aed.cantidad_documentada > aed.cantidad_verificada_deposito ");
        sb.append("AND (le.codigo = '"+LIQUIDACION.ESTADO.PENDIENTE.CODIGO+"' OR le.codigo IS NULL) ");
        list.push(ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO);
    }
    filterSb.append("AND aee.codigo in("+getListToString(list)+") ");

    sb.append(filterSb.toString());
    sb.append("AND ae.gc_fletero_id = ? ");

    sb.append("group by ae.id, aee.estado_actual, aee.codigo, ae.fecha ")
    console.log("sb.toString(): "+sb.toString());
    passData.query = sb.toString();
    var argsToSet = setDatosRetorno(fleteroId);
    passData.argsToSet = JSON.stringify(argsToSet);
    dtoList = await getDataFromQueryAjax(urlStr, passData)

    var tbodyElement = getById("activosEntradaTbodyId");
    var originalTrElement = getById("activosEntradaTableTrId");
    for(var x = 0; x < dtoList.length; x++){
        var dto = dtoList[x];
        dto.activosEntradaCheckActionElement = "check-"+dto.id
        dto.goToShow = "goToShow-"+dto.id
        dto.fecha = formatterDate(dto.fecha, 'DD-MM-YYYY HH:mm')

        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.id = MOVIMIENTOS.ACTIVOS_ENTRADA.CODIGO+"-"+dto.id;
        newTrElement.setAttribute("attr-id", dto.id);
        newTrElement.style.display = "";
        var tdColorClass = ""
        if(dto.activos_entrada_estado_codigo == ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.CODIGO){
            tdColorClass = "table-danger"
        }
        newTrElement.setAttribute("class", "activosEntradaTrGeneradoClass "+tdColorClass);
        setDataInTableTd(newTrElement, dto)
        tbodyElement.appendChild(newTrElement)
    }

    activosEntradaDataTableInitialize();
    return dtoList.length;
}



async function activosEntradaDataTableInitialize(){

    var table = $('#activosEntradaDataTableId').DataTable();

    jQuery('#activosEntradaDataTableId tbody').on('click', 'td.details-control', async function () {
        //recuperamos el id de la devolucion
        // Get the rows id value
        //table.row(this).setAttribute("attr-showed", true);
        var tableId = table.row(this).id();
        var trElement = getById(tableId);
        trElement.setAttribute("attr-showed", "true");
        var id = trElement.getAttribute("attr-id");
        id = id.replace(/\D/g, '');
        id = parseInt(id, 10);
        var tr = jQuery(this).closest('tr');
        var row = table.row(tr);
        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        } else {
            var urlStr = getGetDataFromQueryURL();
            var passData = {};
            var sb = new StringBuilder();
            sb.append("SELECT p.id, p.codigo_barra, p.producto, aed.cantidad_documentada ");
            sb.append("FROM activos_entrada_detalle aed ");
            sb.append("JOIN gc_productos p ON p.id = aed.gc_producto_id WHERE aed.activos_entrada_id = ");
            sb.append(id+" ");

            //passData.query = "SELECT p.id, p.codigo_barra, p.producto, dd.cantidad FROM devolucion_detalle dd JOIN gc_productos p ON p.id = dd.producto_id WHERE devolucion_id = "+id+")"
            passData.query = sb.toString();
            var productosDtoList = await getDataFromQueryAjax(urlStr, passData)
            row.child(activosEntradaFormat(productosDtoList)).show();
            tr.addClass('shown');
        }

    });


}


function activosEntradaFormat(dataDtoList) {
    var filaSb = new StringBuilder();
    if (dataDtoList != '') {
        for (var dataDto in dataDtoList) {
            var data = dataDtoList[dataDto];
            if(data.codigo_barra == null || data.codigo_barra == undefined){
                data.codigo_barra = "";
            }
            if(data.observacion == null || data.observacion == undefined){
                data.observacion = "";
            }

            filaSb.append("<tr>")
            filaSb.append("     <td>"+data.id+"</td>");
            //filaSb.append("     <td>"+data.codigo_barra+"</td>");
            filaSb.append("     <td>"+data.producto+"</td>");

            if(CURRENT_ROLE == ROLES.ROLE_ADMIN || CURRENT_ROLE == ROLES.ROLE_REGISTRO){
                filaSb.append("     <td>"+data.cantidad_documentada+"</td>");
            }

            filaSb.append("</tr>")




        }
        return '<table style="width:100%" id="example" class="display">' +
            '<thead>' +
            '<tr>' +
            '<th>Producto ID</th>' +
            //'<th>Codigo Barra</th>' +
            '<th>Descripcion</th>' +
            '<th>Cant.</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>' +
            filaSb.toString() +
            '</tbody>' +
            '</table>';
    }
}

function areYouShureActivosEntradaAprovvedModalInMovimientosPorFletero(){
    acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la aprobacion de la Entrada de Activo?" ,'warning' ,
        "Si, aprobar", function () {return actualizacionMasivaActivosEntrada()});
}
async function actualizacionMasivaActivosEntrada(){
    var checkActionElementList = jQuery(".activosEntradaCheckActionElement:checked");
    if(checkActionElementList.length > 0){
        for(var x = 0; x < checkActionElementList.length; x++){
            var checkActionElement = checkActionElementList[x];
            var activosEntradaId = checkActionElement.getAttribute("attr-id");
            await actualizacionActivosEntradaEstado(ACCION_APROBAR, activosEntradaId);
        }

    }else{
        toastTr('warning', '!', 'Seleccionar items para aprobación');
    }
}

