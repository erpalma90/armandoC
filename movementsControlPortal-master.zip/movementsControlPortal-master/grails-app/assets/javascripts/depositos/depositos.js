function initJsPage(){
    init();
}