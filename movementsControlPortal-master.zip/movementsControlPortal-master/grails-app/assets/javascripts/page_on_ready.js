/*
loadInitFunction();
function loadInitFunction(){
    var xhr = new XMLHttpRequest(),
        method = "GET",
        url = window.location.href;

    xhr.open(method, url, true);
    xhr.onreadystatechange = function () {
        if(xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
            initJsPage();
        }
    };
    xhr.send();
}
*/

window.onload = function () {
    initJsPage();
}