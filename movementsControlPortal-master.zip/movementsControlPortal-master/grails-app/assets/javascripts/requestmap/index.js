function initJsPage(){
    dataTableInitialize();
}


async function dataTableInitialize(){
    jQuery.noConflict();


    var table = jQuery('#requestmapTableId').dataTable( {
        "columnDefs": [
            { "width": "100%", "targets": 0 }
        ]
    } );
}