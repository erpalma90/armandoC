function initJsPage(){
    getLastAuditoriaObservacion();
    if(CURRENT_ROLE == ROLES.ROLE_LIQUIDACION){
        loadDetailsClass(); //ESTA FUNCION REALIZA EL CALCULO DE LOS MONTOS CON EL ROLE DE LIQUIDACION
    }
}
var dataTable = null;
async function validateFleteroPassAndUpdateStatus(){
    if(SUCURSAL_CONFIGURACION_DETALLE_DEVOLUCION_DEPOSITO_UNIFICADO_KEY == "true"){
        var inactiveProductID = getAllProductActiveFlag();
        if(inactiveProductID==null){
            await actualizacionDeEstado(1);
        }else{
            swalNotification('top-center', "warning",
                getMensajeProductoInactivo(inactiveProductID), 10000);
        }
    }else{
        await actualizacionDeEstado(1);
    }
}


function getMensajeProductoInactivo(text){
    return "Esta devolucion no puede ser aprobada, el producto con codigo: '"+text+"', " +
        "se encuentra inactivo. Favor consultar con Area Comercial"
}


async function actualizacionDeEstado(value, unificadoFlag){
    var devolucionId = getDevolucionId();
    var fleteroContraseña = getById("fleteroContraseñaInputId").value;
    try {
        var passFlag = true;
        var passData = new Object();
        passData.checkedList = devolucionId;
        var newStatus = "";
        if(value == 1){
            if((CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN) && unificadoFlag != true){
                newStatus = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO;
            }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO  || unificadoFlag == true){
                newStatus = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.APROBADO_DEPOSITO.LABORATORIO.CODIGO;
            }
        }else if(value == 3){
            if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
                newStatus = DEVOLUCION.ESTADOS.NO_REGISTRADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO;
            }
        }else{
            if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
                newStatus = DEVOLUCION.ESTADOS.NO_REGISTRADO_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO;
            }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
                newStatus = DEVOLUCION.ESTADOS.APROBADO_REGISTRO.RECHAZADO_DEPOSITO.LABORATORIO.CODIGO;
            }
        }

        passData.nuevoEstadoDevolucion = newStatus;
        passData.fleteroContraseña = fleteroContraseña;
        var returnActualizacionDeEstado = await postDataFromQueryAjax(updateAprobacionDevolucionUrl(), passData, reloadThisPage);
        if(returnActualizacionDeEstado != ERROR.AJAX_RETURN){
            var obs = "";
            if(getById("motivoRechazoDeposito") != null){
                obs = getById("motivoRechazoDeposito").value;
            }else if(getById("motivoNoRegistroRegistroId") != null){
                obs = getById("motivoNoRegistroRegistroId").value;
            }
            let devolucionObj = new Object();
            devolucionObj.devolucionEstado = passData.nuevoEstadoDevolucion;
            devolucionObj.observacion = obs;
            await saveInDevolucionAuditoria(devolucionId, JSON.stringify(devolucionObj), passData.nuevoEstadoDevolucion, "U", obs);
        }
        if(SUCURSAL_CONFIGURACION_DETALLE_DEVOLUCION_DEPOSITO_UNIFICADO_KEY == "true" && (unificadoFlag == null || unificadoFlag == undefined)){
            await actualizacionDeEstado(value, true)
        }

    }catch (error){
        hideSpinner();
        alert("Error accionAprobar: "+error)
    }
}


function saveInDevolucionAuditoria(entityId, estadoJson, estado, action, observation){
    var data = new Object();
    data.action = action;
    data.dominioId = entityId;
    data.observacion = observation;
    data.dominio = "Devolucion"
    data.userId = getLoggedUserId();
    data.estado = estado;
    data.datos = estadoJson;
    insertarAuditoria(data);
}


function observacionDevolucion(){
    jQuery("#observacion-modal-id").modal();
}

function verificacionCantidadesDeposito(){
    var cantidadesModal = document.getElementsByClassName("cantidadVerificadaDepositoClass");
    for(var x = 0; x < cantidadesModal.length; x++){
        var element = cantidadesModal[x]
        console.log("Cantidad verificada registro: "+element.getAttribute("attr-cantidadVerificada"))
    }
    jQuery("#verificacion-deposito-modal-id").modal();
}

function actualizarCantidadVerificadaDeposito(){
    showSpinner();
    var cantVerificadaDepositoList = document.getElementsByClassName("cantidadVerificadaDepositoClass");
    var existChangeFlag = false;
    if(cantVerificadaDepositoList != undefined && cantVerificadaDepositoList != null){
        for(var x = 0; x < cantVerificadaDepositoList.length; x++){
            var elemento = cantVerificadaDepositoList[x];
            var cantidadNuevo = elemento.value
            var cantidadVerificadaDepositoActual = elemento.getAttribute("attr-cantidadVerificadaDeposito");
            var devolucionDetalleId = elemento.getAttribute("attr-devolucionDetalleId");
            if(cantidadNuevo != null && cantidadNuevo != "" && parseInt(cantidadNuevo) >= 0){
                if(cantidadNuevo.toString() != cantidadVerificadaDepositoActual.toString()){
                    updateVerificacionDevolucionDetalle(devolucionDetalleId, cantidadNuevo, "cantidad_verificada_deposito", existChangeFlag);
                    existChangeFlag = true;
                }
            }
        }
    }
    if(!existChangeFlag){
        jQuery('#verificacion-deposito-modal-id').modal('toggle');
        hideSpinner();
    }

}

async function actualizarVerificacionDevolucionDetalles(){
    showSpinner();
    var elementosCantidadVerificada = document.getElementsByClassName("cantidadVerificadaClass");
    var sb = new StringBuilder();
    var existChangeFlag = false;
    if(elementosCantidadVerificada != undefined && elementosCantidadVerificada != null){
        for(var x = 0; x < elementosCantidadVerificada.length; x++){
            var elemento = elementosCantidadVerificada[x];
            var cantidadVerificadaNueva = elemento.value
            var cantidadDocumentada = elemento.getAttribute("attr-cant-documentada");
            var devolucionDetalleId = elemento.getAttribute("attr-devolucionDetalleId");
            var cantidadVerificadaActual = elemento.getAttribute("attr-cantidadVerificadaActual");
            if(cantidadVerificadaNueva.toString().trim() == "" || cantidadVerificadaNueva.toString().trim().indexOf(".") != -1 || cantidadVerificadaNueva.toString().trim().indexOf(",") != -1){
                cantidadVerificadaNueva = cantidadDocumentada;
            }else if(cantidadVerificadaNueva.toString() != cantidadVerificadaActual.toString()){
                await updateVerificacionDevolucionDetalle(devolucionDetalleId, cantidadVerificadaNueva, "cantidad_verificada", existChangeFlag);
                if(SUCURSAL_CONFIGURACION_DETALLE_DEVOLUCION_DEPOSITO_UNIFICADO_KEY == "true"){
                    updateVerificacionDevolucionDetalle(devolucionDetalleId, cantidadVerificadaNueva, "cantidad_verificada_deposito", existChangeFlag);
                }
                existChangeFlag = true;
            }
        }
    }
    if(!existChangeFlag){
        jQuery('#observacion-modal-id').modal('toggle');
        hideSpinner();
    }
}


function updateVerificacionDevolucionDetalle(devolucionDetalleId, cantidad, columnToUpdate, existChangeFlag){
    var passData = new Object(); //getDevolucionDetailVerificacionUpdateData(devolucionDetalleId, cantidad, columnToUpdate);
    var passDataList = []
    if(!existChangeFlag){
        passDataList.push(getDevolucionUpdateLastUserModified());
    }
    passDataList.push(getDevolucionDetailVerificacionUpdateData(devolucionDetalleId, cantidad, columnToUpdate));
    passData.parentId = getDevolucionId();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                var urlStr = window.location;
                window.location = urlStr;
                //location.href = getDevolucionesShowUrl()+"/"+data;
            }else{
                alert('No se pudo guardar la devolucion: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo guardar la devolucion');
        }
    });
}

function getDevolucionDetailVerificacionUpdateData(devolucionDetalleId, cantidad, columnToUpdate){
    var sb = new StringBuilder();
    sb.append("UPDATE devolucion_detalle SET "+columnToUpdate+" = ? WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosActualizarVerificacion(devolucionDetalleId, cantidad);
    passData.argsToSet = argsToSet;
    return JSON.stringify(passData);
}

function getDatosActualizarVerificacion(devolucionDetalleId, cantidad){
    var list = [];
    var columnsMap = new Map();
    columnsMap.set(1, [cantidad, DATABASE.DATA_TYPE.INTEGER])
    columnsMap.set(2, [devolucionDetalleId, DATABASE.DATA_TYPE.BIGINT])
    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    list.push(obj)
    return list;
}



function validacionDeRechazo(){
    jQuery("#rechazar-modal-id").modal();
    var correoDepositoSupervisor = getConfigurationValueFromKey("deposito.supervisor.correo.destinatario");
    jQuery("#correoNotificacionDivId").html(correoDepositoSupervisor);
    //actualizacionDeEstado(2);
}

function rechazarYEnviarCorreo(){
    var motivoRec = getById("motivoRechazoDeposito").value
    if(motivoRec != null && motivoRec != ""){
        showSpinner();
        var urlStr = getSendMailURL();
        var passData = new Object();
        passData.mailTo = getConfigurationValueFromKey("deposito.supervisor.correo.destinatario");
        passData.subject = "Devolucion Rechazada en Deposito"
        var element = getById("bodyHtmlId");
        var htmlContent = element.innerHTML;
        var motivoRechazoDeposito = rechazoHtml(getDevolucionId());
        passData.body = motivoRechazoDeposito+htmlContent
        getDataFromQueryAjaxJson(urlStr, passData, null);
        actualizacionDeEstado(2);
    }else{
        toastTr('warning', 'Advertencia', 'Debe describir el motivo del rechazo');
    }
}
function rechazar(){
    actualizacionDeEstado(2);
}


function modalConfirmApproval(){
    if(CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
        modalContraseñaFletero('validarContraseñaFleteroYActualizacionMasiva')
    }else if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO){
        //todo acenturion validar que el producto esté activo
        var inactiveProductID = getAllProductActiveFlag();
        if(inactiveProductID==null){
            var title = "Estas seguro? ";
            var text = "Estas seguro de realizar la aprobacion de la devolucion";
            var icon = 'warning'
            var confirmButtonText = "Si, aprobar";
            acceptOrCancellModal(title, text ,icon , confirmButtonText, validateCantidadesVerificadas)
        }else{
            swalNotification('top-center', "warning",
                getMensajeProductoInactivo(inactiveProductID), 10000);
        }

    }
}

function getAllProductActiveFlag(){
    var devolucionTrElements = document.getElementsByClassName("devolucionShowTrClass");
    var productId = null;
    for(var x=0; x < devolucionTrElements.length; x++){
        var element = devolucionTrElements[x]
        var activo = element.getAttribute("attr-producto-activo")
        if(activo!="SI"){
            productId = element.getAttribute("attr-productoId");
            break;
        }
    }
    return productId;
}

function getAllProductActiveFlagAsync(){
    var devolucionTrElements = document.getElementsByClassName("devolucionShowTrClass");
    var productId = null;
    for(var x=0; x < devolucionTrElements.length; x++){
        var element = devolucionTrElements[x]
        var activo = element.getAttribute("attr-producto-activo")
        if(activo!="SI"){
            productId = element.getAttribute("attr-productoId");
            break;
        }
    }
    return productId;
}

function updateDevolucionStatusToApproved(){
    actualizacionDeEstado(1)
}
function editDevolucion(){
    var devolucionId = getDevolucionId();
    goToEditDevolucion(devolucionId)
    //var url = getDevolucionEditUrl()+"/"+devolucionId;
    //location.href = url
}
function goToEditDevolucion(devolucionId){
    showSpinner();
    goToUrl(window.location, getDevolucionEditUrl()+"/"+devolucionId);
}

function validateCantidadesVerificadas(){
    var cantidadesVerificadas = document.getElementsByClassName("cantidadVerificadaDepositoClass");
    var resultMap = new Map();
    if(cantidadesVerificadas != undefined && cantidadesVerificadas != null){
        for(var x = 0; x < cantidadesVerificadas.length; x++){
            var elemento = cantidadesVerificadas[x];
            var cantidadVerificadaRegistro = elemento.getAttribute("attr-cantidadVerificada");
            var cantidadVerificadaDeposito = elemento.getAttribute("attr-cantidadVerificadaDeposito");
            var devolucionDetalleId = elemento.getAttribute("attr-devolucionDetalleId");
            if(cantidadVerificadaRegistro != cantidadVerificadaDeposito){
                resultMap.set(devolucionDetalleId, "Registro: "+cantidadVerificadaRegistro+" - Deposito: "+cantidadVerificadaDeposito);
            }
        }
    }
   if(resultMap.size == 0){
       swalNotification('top-center', "success", "Cantidades Coicidentes con Registro", 7000);
       updateDevolucionStatusToApproved();
   }else{
        //alert("Existe diferencia")
       var title = "La cantidad no coincide con la verificacion de Registro, favor volver a realizar el conteo, o aplicar rechazo del movimiento";
       swalNotification('top-center', "warning",
           title, 7000);
   }
}

function reassignFletero(){
    getFletero();
    jQuery("#reassign-fletero-modal-id").modal();

}

function updateDevolucionFletero(){
    showSpinner();
    var passData = getDevolucionUpdateFletero();
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'GET',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                reloadThisPage();
            }else{
                alert('No se pudo guardar la devolucion: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo guardar la devolucion');
        }
    });
}
function getDevolucionUpdateFletero(){
    var sb = new StringBuilder();
    sb.append("UPDATE devolucion SET fletero_id = ?, user_last_updated_id = ?, ");
    sb.append("portal_fecha_ultima_actualizacion = current_timestamp WHERE id = ? ");
    var query = sb.toString();
    var passData = new Object();
    passData.query = query.toString();
    var argsToSet = getDatosDevolucionUpdateFletero();
    passData.argsToSet = JSON.stringify(argsToSet);
    return passData;
}

function getDatosDevolucionUpdateFletero(){
    var fleteroId = jQuery("#fleteroSelectId").val();
    var devolucionId = getDevolucionId();
    var columnsMap = new Map();
    columnsMap.set(1, [fleteroId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(2, [getLoggedUserId(), DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(3, [devolucionId, DATABASE.DATA_TYPE.BIGINT])

    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;
}

function noRegistrarYEnviarCorreo(){
    var textElement = getById("motivoNoRegistroRegistroId").value;
    if(textElement != null && textElement.toString().trim() != ""){
        showSpinner();
        var urlStr = getSendMailURL();
        var passData = new Object();
        passData.mailTo = getConfigurationValueFromKey("registro.supervisor.correo.destinatario");
        passData.subject = "Movimiento sin Registrar"
        var element = getById("bodyHtmlId");
        var htmlContent = element.innerHTML;
        var motivoRechazoDeposito = noRegistradoHtml();
        passData.body = motivoRechazoDeposito+htmlContent
        getDataFromQueryAjaxJson(urlStr, passData, null);
        actualizacionDeEstado(3);
    }else{
        alert("Escriba el motivo")
    }
}
function changeQuantity(element){
    var currentValue = element.value;
    var cantDocumentada = element.getAttribute("attr-cant-documentada")
    if(parseInt(currentValue) > parseInt(cantDocumentada)){
        toastTr('warning', 'Atencion', 'La cantidad Verificada no puede ser mayor a la cantidad Documentada');
        element.value = 0;
    }

    if(parseInt(currentValue) < 0){
        toastTr('warning', 'Atencion', 'La cantidad Verificada no puede ser menor a 0');
        element.value = 0;
    }
}

function printDocument(devolucionId, fletero, cliente){
    var d = moment().format('DD MM YYYY HH:mm');
    document.title=devolucionId+"_"+fletero+"_"+cliente+"_"+d;
    window.print();
    return false;
}

function validacionDeNoRegistro(){
    jQuery("#no-registrar-modal-id").modal();
    var correoDepositoSupervisor = getConfigurationValueFromKey("registro.supervisor.correo.destinatario");
    jQuery("#correoNotificacionRegistroDivId").html(correoDepositoSupervisor);
    //actualizacionDeEstado(2);
}



function noRegistradoHtml(){
    var r = new StringBuilder();
    r.append("<table>")
    r.append("  <tr>")
    r.append("      <td>")
    r.append("          <b>Usuario: </b>")
    r.append("      </td>")
    r.append("      <td>")
    r.append("          "+getLoggedUsername());
    r.append("      </td>")
    r.append("  </tr>")
    r.append("  <tr>")
    r.append("      <td>")
    r.append("          <b>Motivo: </b>")
    r.append("      </td>")
    r.append("      <td>")
    r.append("          "+getById("motivoNoRegistroRegistroId").value);
    r.append("      </td>")
    r.append("  </tr>")
    r.append("</table>")
    return r.toString();
}

function getDevolucionUpdateLastUserModified(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("UPDATE devolucion SET user_last_updated_id = ?, portal_fecha_ultima_actualizacion = current_timestamp ");
    sb.append("WHERE id = ? ")
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosDevolucionActualizacion();
    passData.argsToSet = argsToSet;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        passData = null;
    }
    return JSON.stringify(passData);
}

function getDatosDevolucionActualizacion(){
    let devolucionDetallesList = [];
    let columnsMap = new Map();
    var devolucionId = getDevolucionId();

    columnsMap.set(1, [getLoggedUserId(), DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(2, [devolucionId,      DATABASE.DATA_TYPE.BIGINT])

    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    devolucionDetallesList.push(obj);

    return devolucionDetallesList;

}


async function showAudit(devolucionId){
    if(dataTable != null){
        dt2.clear();
        dt2.destroy()
        //dataTable.fnDraw(false);
    }
    var cardElement = getById("cardBodyId")
    jQuery(cardElement).children().remove();

    var devolucionesTableElement = getById("auditoriaTableId");
    var newDevolucionesTableElement = devolucionesTableElement.cloneNode(true);
    newDevolucionesTableElement.setAttribute("id", "");
    newDevolucionesTableElement.style.display = "";

    cardElement.appendChild(newDevolucionesTableElement);
    var newTableElement = cardElement.getElementsByTagName("table")[0]
    newTableElement.setAttribute("id", "auditoriaTableId");
    var newTbodyElement = newTableElement.getElementsByTagName("tbody")[0];
    newTbodyElement.setAttribute("id", "auditoriaTbodyId");
    var newOriginalTrElement = newTbodyElement.getElementsByTagName("tr")[0];
    newOriginalTrElement.setAttribute("id", "auditoriaTableTrId");


    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select aj.*, u.username, r.authority from audit_json aj ");
    sb.append("join users u on u.id = aj.user_id ")
    sb.append("join users_roles ur on ur.users_id = u.id ");
    sb.append("join roles r on ur.roles_id = r.id ");
    sb.append("WHERE aj.table_id = '"+devolucionId+"' AND table_name = 'devolucion'  order by aj.date desc");

    passData.query = sb.toString();
    devolucionesDtoList = await getDataFromQueryAjax(urlStr, passData)
    var tbodyElement = getById("auditoriaTbodyId");
    var originalTrElement = getById("auditoriaTableTrId");
    var formatter= 'DD-MM-YYYY HH:mm';
    for(var x = 0; x < devolucionesDtoList.length; x++){
        var dto = devolucionesDtoList[x];
        dto.date = formatterDate(dto.date, "DD-MM-YYYY HH:mm:ss");
        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.id = "";
        newTrElement.style.display = "";
        newTrElement.setAttribute("class", "auditoriaTrGeneradoClass");
        setDataInTableTd(newTrElement, dto)
        tbodyElement.appendChild(newTrElement)
        getById("auditoriaTableTrId").style.display = 'none'
    }
    dt2 = jQuery("#auditoriaTableId").DataTable({
        "order": [],
        "columnDefs": [ {
            "targets"  : 'no-sort',
            "orderable": false,
        }]
    });
    jQuery("#showDevolucionAuditId").modal();
}

async function getLastAuditoriaObservacion(){
    var devolucionId = getDevolucionId();
    var sb = new StringBuilder();
    sb.append("SELECT concat(u.id,'-',u.username) as userdata, u.username, ");
    sb.append("a.observacion, de.estado_actual  FROM auditoria a ");
    sb.append("JOIN users u ON u.id = a.user_id ");
    sb.append("JOIN users_roles ur ON ur.users_id = u.id ");
    sb.append("JOIN roles r ON r.id = ur.roles_id ");
    sb.append("JOIN devolucion_estados de ON de.codigo = a.estado ");
    sb.append("WHERE a.dominio_id = '"+devolucionId+"' ");
    sb.append("ORDER BY a.fecha_auditoria DESC LIMIT 1 ");

    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    passData.query = sb.toString();
    var auditStatusDtoList = await getDataFromQueryAjax(urlStr, passData)
    for(var x = 0; x < auditStatusDtoList.length; x++){
        var dto = auditStatusDtoList[x];
        if(dto.observacion != null && dto.observacion.trim() != ""){
            var divElement = getById("auditDivID");
            divElement.style.display = "";
            var htmlSb = new StringBuilder();
            htmlSb.append("<span style = 'color:red;'> ");
            htmlSb.append(dto.username+": "+dto.observacion);
            htmlSb.append("</span>");
            jQuery(divElement).html(htmlSb.toString());
        }
    }
}





function changeTotal(element){
    var devolucionDetalleId = element.getAttribute("attr-devolucionDetalleId");
    var cantidadFaltanteElement = getById("cantidadFaltanteId-"+devolucionDetalleId);
    if(cantidadFaltanteElement != null && cantidadFaltanteElement.trim != ""){
        var cantidadFaltante = cantidadFaltanteElement.value
        var precioUnitario = element.value;
        var totalFaltante = precioUnitario*cantidadFaltante;
        var totalFaltanteElement = getById("totalfaltante-"+devolucionDetalleId);
        totalFaltanteElement.value = Math.round(totalFaltante);
        var allTotalFaltante = document.getElementsByClassName("totalFaltanteClass");
        var total = 0;
        for(var x = 0; x < allTotalFaltante.length; x++){
            var element = allTotalFaltante[x];
            total = parseInt(element.value)+parseInt(total);
        }
        jQuery("#montoTotalFaltanteSpanId").html(Math.round(total));
    }

}

function loadDetailsClass(){
    var elements = document.getElementsByClassName("precioUnitarioClass");
    for(var x = 0; x < elements.length; x++){
        var element = elements[x];
        changeTotal(element)
    }
}





function noFacturadoHtml(){
    var r = new StringBuilder();
    r.append("<table>")
    r.append("  <tr>")
    r.append("      <td>")
    r.append("          <b>Usuario: </b>")
    r.append("      </td>")
    r.append("      <td>")
    r.append("          "+getLoggedUsername());
    r.append("      </td>")
    r.append("  </tr>")
    r.append("  <tr>")
    r.append("      <td>")
    r.append("          <b>Motivo: </b>")
    r.append("      </td>")
    r.append("      <td>")
    r.append("          "+getById("observacionNoFacturadoLiquidacion").value);
    r.append("      </td>")
    r.append("  </tr>")
    r.append("</table>")
    return r.toString();
}


async function liquidacionChangeStatus(newStatus, observation){
    var productMap = new Map();
    var preciosUnit = document.getElementsByClassName("precioUnitarioClass");
    var detailsObject = new Object();
    var detailsObjectList = [];
    for(var x = 0; x < preciosUnit.length; x++){
        var element = preciosUnit[x];
        var devolucionDetalleId = element.getAttribute("attr-devolucionDetalleId");
        var precioUnit = element.value;
        var totalFaltante = getById("totalfaltante-"+devolucionDetalleId).value;
        var cantidadFaltante = getById("cantidadFaltanteId-"+devolucionDetalleId).value;

        detailsObject.devolucionDetalleId = devolucionDetalleId;
        detailsObject.precioUnit = precioUnit;
        detailsObject.totalFaltante = totalFaltante;
        detailsObject.cantidadFaltante = cantidadFaltante;
        detailsObjectList.push(JSON.stringify(detailsObject));
    }
    var urlStr = getUpdateDevolucionLiquidacionStatusURL();
    var passData = new Object();
    passData.devolucionId = getDevolucionId();
    passData.liquidacionEstadoCodigo = newStatus;
    if(observation == null || observation == undefined){
        observation = "";
    }
    passData.observacion = observation.trim();
    passData.devolucionDetalleLiquidacionObjList = JSON.stringify(detailsObjectList);
    await ajaxPutData(urlStr, passData, reloadThisPage);
}

function copyThisDevolucion(){
    var sncNro = getSncNro();
    var clienteId = getClienteId();
    var devolucionEstadoId = getDevolucionEstadoId();
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var passDataSb = new StringBuilder();

    passDataSb.append("select count(*) from devolucion d ");
    passDataSb.append("join devolucion_estados de on de.id = d.devolucion_estado_id ");
    passDataSb.append("where d.snc_nro = '"+sncNro+"' and cliente_id = "+clienteId+" and de.id != "+devolucionEstadoId+" ");
    passData.query = passDataSb.toString();
    var cantidadList =  getDataFromQueryAjax(urlStr, passData)
    var cantidad = cantidadList[0].count;
    if(parseInt(cantidad) > 0){
        swalNotification('top-center', 'warning', 'Ya existe una devolucion con este cliente y esta SNC.', 3000);
    }else{
        acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la copia de la devolucion?" ,'warning' ,
            "Si, realizar la copia", function () {return ejecutarCopiaDevolucion()});
    }

}

function ejecutarCopiaDevolucion(){
    showSpinner()
    var devolucionId = getDevolucionId();
    var passData = new Object();
    passData.devolucionId = devolucionId;
    var urlStr = getCopyDevolucionUrl();
    ajaxGetData(urlStr, passData, goToDevolucionShow)
}

function goToDevolucionShow(devolucionId){
    goToUrl(window.location, getDevolucionesShowUrl()+"/"+devolucionId);
}

