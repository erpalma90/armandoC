var devolucionDetalleToDeleteList = [];

async function initJsPage(){
    await getMotivoDevolucion();
    await getFletero();
    await getClientes();
    //await getProductsMultiSelect();
    await loadPlugins();
    getProductosDevolucionesWhitLimit();

    var currentPage = await currentPageName();
    if(currentPage == 'edit'){
        await loadDevolucionesData();
    }
    /*
    jQuery('#clienteSelectId').on("change", function (e) {
        var productosSelectedIdList = jQuery('#productMultiSelect2Id').val();
        if(productosSelectedIdList.length > 0){
            customToast('warning', 'Estas Seguro?', 'Si cambia el cliente se quitaran todos los productos seleccionados',
                'Si, cambiar', removeAllProductosSelecteds, mantenerClienteSeleccionado)
        }
    });
    */
}
function removeAllProductosSelecteds(){
    jQuery('#productMultiSelect2Id').trigger('unselect');
}

function mantenerClienteSeleccionado(){
    alert("Mantener Cliente Seleccionado")
}
async function getMotivoDevolucion(){
    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    passData.query = "SELECT * FROM devolucion_motivos WHERE es_activo is true ";
    var motivoDevolucionList = await getDataFromQueryAjax(urlStr, passData)
    var motivoDevolucionSelect2Element = document.getElementById("motivoDevolucionSelectId");
    jQuery(motivoDevolucionSelect2Element).select2();
    for(var x = 0; x < motivoDevolucionList.length; x++){
        var motivoDevolucionDta = motivoDevolucionList[x];
        var optionElement = document.createElement("option");
        optionElement.appendChild(document.createTextNode(motivoDevolucionDta.devolucion_motivo));
        optionElement.value = motivoDevolucionDta.id
        motivoDevolucionSelect2Element.append(optionElement);
    }
}



function getClientes(){


    jQuery('#clienteSelectId').select2({
        placeholder: 'Select a option',
        ajax: {
            url: getClientesUrl(),
            dataType: 'json',
            type: 'GET',
            processResults(data) {
                return {
                    results: jQuery.map(data, function (item) {
                        return {
                            text:   item.datosCliente,
                            id:     item.id,
                        }
                    })
                }
            }
        }
    });


}


function loadPlugins(){
    jQuery("#fechaFacturaId").datepicker({
        format: "dd/mm/yyyy",
        clearBtn: true,
        language: "es",
        autoclose: true,
        todayHighlight: true

    });
    jQuery("#fechaNcId").datepicker({
        format: "dd/mm/yyyy",
        clearBtn: true,
        language: "es",
        autoclose: true,
        todayHighlight: true
    });
    //jQuery("#datepicker").datepicker();
}
var currentStepNumberVal = 1;
function nextBtnClicked(btnElement, nextStep){
    var currentStepNumber = currentStepNumberVal;
    var currentBodyStep = getById("bodyStep"+currentStepNumber+"Id");
    //attr-required
    var parentElementId = "bodyStep"+currentStepNumber+"Id";
    var requiredFieldsOkFlag = true;
    if(nextStep == true){
        requiredFieldsOkFlag = validateRequiredFields(parentElementId);
    }
    if(requiredFieldsOkFlag){
        currentBodyStep.style.display = "none";
        var stepMap = getNextOrPrevousStep(currentStepNumber)
        var newStepNumber
        if(nextStep){
            newStepNumber = stepMap.get("nextStep");
            getById("previousBtnId").style.display = ""
        }else{
            newStepNumber = stepMap.get("previousStep");
            if(newStepNumber == 1){
                btnElement.style.display = "none" //Se oculta el boton de atras cuando estamos en la primera parte
            }
        }
        var newBodyStep = getById("bodyStep"+newStepNumber+"Id");
        newBodyStep.style.display = "";
        var newStepMap =  getNextOrPrevousStep(newStepNumber)
        var title = newStepMap.get("title");
        jQuery("#stepsTitleId").html(title);

        stepLine(newStepNumber);
        btnElement.setAttribute("current-step", newStepNumber)
        currentStepNumberVal = newStepNumber;
    }

}
function getNextOrPrevousStep(currentStep){
    var nextStep = 1;
    var previousStep = 1;
    var title = "Identificacion"
    switch(currentStep) {
        case 1:
            nextStep = 2;
            previousStep = 1;
            title = "Identificacion"
            break;
        case 2:
            nextStep = 3
            previousStep = 1;
            title = "Documentos"
            break;
        case 3:
            nextStep = 4
            previousStep = 2;
            title = "Productos"
            break;
        case 4:
            nextStep = 5
            previousStep = 3;
            title = "Observacion"
            break;
        default:
            alert("default nextStep")
    }
    var returnMap = new Map();
    returnMap.set("nextStep", nextStep)
    returnMap.set("previousStep", previousStep);
    returnMap.set("title", title);
    return returnMap;
}

function stepLine(currentStep){
    var disabledList;
    var stepElement = getById("step"+currentStep+"Id");
    stepElement.removeAttribute("disabled");
    stepElement.classList.remove("btn-default");
    stepElement.classList.add("btn-success");
    switch(currentStep) {
        case 1:
            getById("nextBtnId").style.display = ""
            getById("saveBtnId").style.display = "none"
            getById("updateBtnId").style.display = "none"
            disabledList = ["step2Id", "step3Id", "step4Id"];
            break;
        case 2:
            getById("nextBtnId").style.display = ""
            getById("saveBtnId").style.display = "none"
            getById("updateBtnId").style.display = "none"
            disabledList = ["step3Id", "step4Id"];
            break;
        case 3:
            getById("nextBtnId").style.display = ""
            getById("saveBtnId").style.display = "none"
            getById("updateBtnId").style.display = "none"
            disabledList = ["step4Id"];
            break;
        case 4:
            getById("nextBtnId").style.display = "none"
            if(currentPageName()=='create'){
                getById("saveBtnId").style.display = ""
            }else if (currentPageName() == 'edit'){
                getById("updateBtnId").style.display = ""
            }
            break;
        default:
            alert("default nextStep")
    }
    if(disabledList != null && disabledList != undefined){
        for(var i = 0; i < disabledList.length; i++){
            var disabledId = disabledList[i];
            var element = getById(disabledId);
            if(element != null && element != undefined){
                element.setAttribute("disabled", "disabled");
                element.classList.remove("btn-success");
                element.classList.add("btn-default");
            }
        }
    }
}

/*
function getProductsMultiSelect(){
    //todo acenturion
    var selectedList = jQuery('#productMultiSelect2Id').val();
    jQuery('#productMultiSelect2Id').select2({
        placeholder: 'Seleccionar los productos',
        hideSelected: true,
        ajax: {
            url: getProductosUrl(),
            dataType: 'json',
            type: 'GET',
            data: function (params) {
                var query = {
                    //todo acenturion
                    clienteId: jQuery("#clienteSelectId").val(),
                    selectedProductsIds : jQuery('#productMultiSelect2Id').val().toString(),
                    q: params.term
                }

                // Query parameters will be ?search=[term]&page=[page]
                return query;
            },
            processResults(data) {
                return {
                    results: jQuery.map(data, function (item) {
                        return {
                            text:   item.datosProducto,
                            id:     item.id,
                        }
                    })
                }
            }
        }
    });

    var eventSelect = $("#productMultiSelect2Id");
    eventSelect.on("select2:select", function (e) {
        var id = e.params.data.id;
        addProductsSelectedInTable(id);
    });
    eventSelect.on("select2:unselect", function (e) {
        var id = e.params.data.id;
        removeTrFromTrId("product-tr-id-"+id)
    });


}
*/



async function addProductsSelectedInTable(productId, importe, unidadMedida){
    //var idProductosSeleccionados = jQuery("#productMultiSelect2Id").select2("val");
    var idProductosSeleccionados = productId;
    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();

    var sb = new StringBuilder();
    sb.append("SELECT p.*, um_bot.unidad_medida as medida_und, um_caj.unidad_medida as medida_pack, ump.id as unidad_medida_producto, ");
    sb.append("ump.gc_unidad_medidas_id as unidad_medida_id ")
    sb.append("FROM gc_unidad_medida_productos ump ");
    sb.append("JOIN gc_productos p on p.id = ump.gc_productos_id ");
    sb.append("LEFT JOIN gc_unidad_medidas um_bot ON um_bot.id = ump.gc_unidad_medidas_id AND um_bot.unidad_medida IN ('Bot', 'Und', 'Lat', 'Tet') ");
    sb.append("LEFT JOIN gc_unidad_medidas um_caj ON um_caj.id = ump.gc_unidad_medidas_id AND um_caj.unidad_medida IN ('Caj', 'Pack') ");
    sb.append("WHERE 1=1 ");
    sb.append("AND p.id = "+idProductosSeleccionados+" ");
    sb.append("ORDER BY p.id ASC, um_bot.unidad_medida NULLS LAST ");
    sb.append("LIMIT 1 ");

    //passData.query = "SELECT * FROM gc_productos WHERE id in ("+idProductosSeleccionados+")";
    passData.query = sb.toString();
    var productList = await getDataFromQueryAjax(urlStr, passData)
    var productTableElement = getById("productTableBodyId");
    var originalTrElement = getById("productTableTrId");
    for(var x = 0; x < productList.length; x++){
        var dto = productList[x];
        dto.removeId = "product-tr-id-"+dto.id
        dto.cantidad = 0;
        var productTr = getById("product-tr-id-"+dto.id);
        if(productTr == null || productTr == undefined){
            var newTrElement = originalTrElement.cloneNode(true);
            newTrElement.style.display = "";
            newTrElement.setAttribute("attr-product-id", dto.id)
            newTrElement.setAttribute("attr-importe", importe)
            newTrElement.setAttribute("attr-unidadMedida", dto.unidad_medida_id)
            newTrElement.setAttribute("id", "product-tr-id-"+dto.id);
            newTrElement.setAttribute("class", "new-product")
            setDataInTableTd(newTrElement, dto)
            productTableElement.appendChild(newTrElement)

            var subProducto1 = dto.sub_producto1;
            if(subProducto1 != null && subProducto1 != undefined && subProducto1.trim() != ""){
                await addProductsSelectedInTable(subProducto1, 0, null);
            }
            var subProducto2 = dto.sub_producto2;
            if(subProducto2 != null && subProducto2 != undefined && subProducto2.trim() != ""){
                await addProductsSelectedInTable(subProducto2, 0, null);
            }
        }
    }
}

function removeTrFromTrId(elementId, id){
    var productTrElement = document.getElementById(elementId);
    jQuery(productTrElement).remove();
    if(id != null && id != undefined){
        //jQuery('#productMultiSelect2Id').val(id).trigger("change");
        jQuery("#productMultiSelect2Id option[value='"+id+"']").remove();
    }
    if(productTrElement.classList.contains('existing-product')){
        devolucionDetalleToDeleteList.push(productTrElement.getAttribute("attr-devolucion-detalle-id"))
    }
}
function getDevolucionPassDataInsert(montoTotal){
    var sb = new StringBuilder();
    sb.append("INSERT INTO devolucion(id, version, devolucion_motivo_id, devolucion_estado_id, devolucion_tipo_id, vendedor_id, ");
    sb.append("factura_fecha, nc_fecha, factura_nro, ");
    sb.append("metodo_de_carga_id, creado_por_usuario_id, activo, fecha, observacion,monto_total, snc_nro, ");
    sb.append("fletero_id, sucursal_id, ");
    sb.append("cliente_id,nc_nro, con_snc, fecha_creacion_devolucion, debe_procesar_freight_order) ");
    sb.append("VALUES (nextval('devolucion_seq'), 0, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, current_timestamp, ?, ?, ?, ");
    sb.append("?, ?, ?, ?, ?, current_timestamp, true) ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosDevolucionInsert(montoTotal);
    passData.argsToSet = JSON.stringify(argsToSet);
    return passData;
}

function getDevolucionDetailsPassDataInsert(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("INSERT INTO devolucion_detalle(id, version, cantidad_documentada, devolucion_id, precio_unitario, unidad_medida_id, producto_id, ");
    sb.append("precio_total, cantidad_verificada, motivo_devolucion_documentada_id, motivo_devolucion_verificada_id, observacion, cantidad_verificada_deposito) ");
    sb.append("VALUES (nextval('devolucion_detalle_seq'), 0, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?) ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosDevolucionDetalleInsert();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDevolucionDetailsUpdateLastUserModified(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("UPDATE devolucion SET user_last_updated_id = ?, portal_fecha_ultima_actualizacion = current_timestamp ");
    sb.append("WHERE id = ? ")
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosDevolucionActualizacion();
    passData.argsToSet = argsToSet;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        passData = null;
    }
    return JSON.stringify(passData);
}

function saveDevolucion(){
    showSpinner();
    //todo acenturion
    var passDataList = []
    passDataList.push(getDevolucionDetailsPassDataInsert())
    var passData = getDevolucionPassDataInsert(0);
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                console.log("window.location: "+window.location);
                goToUrl(window.location.search, getDevolucionesShowUrl()+"/"+data, true);
            }else{
                alert('No se pudo guardar la devolucion: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo guardar la devolucion');
        }
    });

    /*
    var productFinalPriceURL = getProductFinalPriceURL();
    var price = getDataFromQueryAjax(productFinalPriceURL, '', null)
    alert("price: "+price)
    */
}

function getDatosDevolucionInsert(montoTotal){
    var devolucionMotivoId = jQuery("#motivoDevolucionSelectId").val();
    var fleteroId = jQuery("#fleteroSelectId").val();
    var clienteId = jQuery("#clienteSelectId").val();
    var sncNro = document.getElementById("sncNroId").value;
    var facturaNro = document.getElementById("facturaNroId").value;
    var facturaFecha = document.getElementById("fechaFacturaId").value;
    var ncFecha = document.getElementById("fechaNcId").value;
    var devolucionEstadoId = getOneValueFromTableAndCode("id", "devolucion_estados", DEVOLUCION.ESTADOS.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO);
    var devolucionTipoCode = getDevolucionTipoCode();
    var devolucionTipoId = getOneValueFromTableAndCode("id", "devolucion_tipos", devolucionTipoCode);
    //var vendedorId;
    var metodoDeCargaId = getOneValueFromTableAndCode("id", "devolucion_metodo_de_carga", DEVOLUCION.METODO_DE_CARGA.MANUAL.CODIGO);

    var creadoPorUsuario = getLoggedUserId();
    var activo = true;
    var observacion = document.getElementById("observacionId").value;
    var ncNro;
    var esConSNC = getById("esConSNCId").checked;
    var columnsMap = new Map();
    columnsMap.set(1, [devolucionMotivoId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(2, [devolucionEstadoId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(3, [devolucionTipoId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(4, [null, DATABASE.DATA_TYPE.BIGINT]) //vendedor
    columnsMap.set(5, [facturaFecha, DATABASE.DATA_TYPE.TIMESTAMP])
    columnsMap.set(6, [ncFecha, DATABASE.DATA_TYPE.TIMESTAMP])
    columnsMap.set(7, [facturaNro, DATABASE.DATA_TYPE.VARCHAR])
    columnsMap.set(8, [metodoDeCargaId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(9, [creadoPorUsuario, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(10, [activo, DATABASE.DATA_TYPE.BOOLEAN])
    columnsMap.set(11, [observacion, DATABASE.DATA_TYPE.VARCHAR])
    columnsMap.set(12, [montoTotal, DATABASE.DATA_TYPE.DOUBLE]) //monto total
    columnsMap.set(13, [sncNro, DATABASE.DATA_TYPE.VARCHAR])
    columnsMap.set(14, [fleteroId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(15, [null, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(16, [clienteId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(17, [ncNro, DATABASE.DATA_TYPE.VARCHAR])
    columnsMap.set(18, [esConSNC, DATABASE.DATA_TYPE.BOOLEAN])


    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;

}

function getDatosDevolucionDetalleInsert(){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let trProductosAgregados = document.getElementsByClassName("new-product");
    let devolucionDetallesList = [];
    for(let i = 0; i < trProductosAgregados.length; i++){
        var productElement = trProductosAgregados[i]
        let productId = productElement.getAttribute("attr-product-id")
        let cantidadProducto = getById("cantidad-"+productId).value;
        //getPrecioProductoPorCliente();
        let precioUnitario = Math.round(parseFloat(productElement.getAttribute("attr-importe")));

        let precioTotal = Math.round(cantidadProducto*precioUnitario);
        let unidadMedidaId = productElement.getAttribute("attr-unidadMedida");
        let sucursalId = null;
        //todo acenturion
        var devolucionMotivoId = jQuery("#motivoDevolucionSelectId").val();
        var observacion = document.getElementById("observacionId").value;
        var cantidadVerificadaDeposito = null;
        //alert(SESSION_VALUE)
        if(SUCURSAL_CONFIGURACION_DETALLE_DEVOLUCION_DEPOSITO_UNIFICADO_KEY == "true"){
            cantidadVerificadaDeposito = cantidadProducto;
        }


        let columnsMap = new Map();
        columnsMap.set(1, [cantidadProducto, DATABASE.DATA_TYPE.INTEGER]) //Cantidad Documentada
        columnsMap.set(2, ['parentId',      DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(3, [precioUnitario,  DATABASE.DATA_TYPE.DOUBLE])
        columnsMap.set(4, [unidadMedidaId,  DATABASE.DATA_TYPE.BIGINT]) //vendedor
        columnsMap.set(5, [productId,       DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(6, [precioTotal,     DATABASE.DATA_TYPE.DOUBLE])
        columnsMap.set(7, [cantidadProducto, DATABASE.DATA_TYPE.BIGINT]) //Cantidad Verificada
        columnsMap.set(8, [devolucionMotivoId, DATABASE.DATA_TYPE.BIGINT]) // Motivo Documentado
        columnsMap.set(9, [devolucionMotivoId, DATABASE.DATA_TYPE.BIGINT]) //Motivo Verificado
        columnsMap.set(10, [observacion, DATABASE.DATA_TYPE.VARCHAR]) //Motivo Verificado
        columnsMap.set(11, [cantidadVerificadaDeposito, DATABASE.DATA_TYPE.INTEGER]) //Motivo Verificado
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        devolucionDetallesList.push(obj);
    }

    return devolucionDetallesList;

}

function getDatosDevolucionActualizacion(){
    let devolucionDetallesList = [];
    let columnsMap = new Map();
    var devolucionId = getDevolucionId();

    columnsMap.set(1, [getLoggedUserId(), DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(2, [devolucionId,      DATABASE.DATA_TYPE.BIGINT])

    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    devolucionDetallesList.push(obj);

    return devolucionDetallesList;

}


function getDevolucionTipoCode(){
    var esConSNCElement = document.getElementById("esConSNCId");
    var valToReturn = ""
    if(esConSNCElement.checked == true){
        valToReturn = DEVOLUCION.TIPOS.CON_SNC.CODIGO;
    }else{
        valToReturn = DEVOLUCION.TIPOS.SIN_SNC.CODIGO;
    }
    return valToReturn;
}

function disabledElements(element){
    var sncNroElement = document.getElementById("sncNroId");
    var facturaNroElement = document.getElementById("facturaNroId")
    var fechaFacturaElement = document.getElementById("fechaFacturaId");
    var fechaNcElement = document.getElementById("fechaNcId");
    if(element.checked == true){
        sncNroElement.removeAttribute("disabled");
        facturaNroElement.removeAttribute("disabled");
        fechaFacturaElement.removeAttribute("disabled");
        fechaNcElement.removeAttribute("disabled");
    }else{
        sncNroElement.setAttribute("disabled", "true");
        facturaNroElement.setAttribute("disabled", "true");
        fechaFacturaElement.setAttribute("disabled", "true");
        fechaNcElement.setAttribute("disabled", "true");
        sncNroElement.value = ""
        facturaNroElement.value = ""
        fechaFacturaElement.value = ""
        fechaNcElement.value = ""
    }

}

/************************************************************************************************************************************************/
function loadDevolucionesData(){
    var motivoDevolucionId = getMotivoDevolucionId();
    var fleteroId = getFleteroId();
    jQuery('#motivoDevolucionSelectId').val(motivoDevolucionId)
    jQuery('#fleteroSelectId').val(fleteroId)
    jQuery('.js-data-example-ajax').trigger('change');

    var clienteSelect = jQuery('#clienteSelectId');
    var clienteRazonSocial = getClienteRazonSocial();
    var clienteId = getClienteId();
    var option = new Option(clienteRazonSocial, clienteId, true, true);
    clienteSelect.append(option).trigger('change');


    var conSnc = getConSNC();
    if(conSnc == true){
        getById("esConSNCId").checked = true;
    }else{
        var esConSNCElement = getById("esConSNCId")
        esConSNCElement.checked = false;
        disabledElements(esConSNCElement)
    }
    getById("sncNroId").value = getSNCNro();
    getById("facturaNroId").value = getFacturaNro();
    if(getFacturaFecha() != null && getFacturaFecha() != undefined && getFacturaFecha().trim() != ""){
        getById("fechaFacturaId").value = formatterDate(getFacturaFecha(), 'DD/MM/YYYY');
    }
    if(getFechaNc() != null && getFechaNc() != undefined && getFechaNc().trim() != ""){
        getById("fechaNcId").value = formatterDate(getFechaNc(), 'DD/MM/YYYY');
    }
    //alert("getDevolucionDetallesList: "+getDevolucionDetallesList())
    var productsElementsList = document.getElementsByClassName("productsSelectedHiddenClass")
    var productsSelect2 = jQuery("#productMultiSelect2Id")
    for(var x = 0; x < productsElementsList.length; x++){
        var productElement = productsElementsList[x];
        var productId = productElement.value;

        var productDescription = productElement.getAttribute("attr-product-descr")
        var opt = new Option(productDescription, productId, true, true);
        productsSelect2.append(opt).trigger('change');
    }
    getById("observacionId").value = getObservacion();
}

function updateDevolucion(){
    var productDataMap = null; //getPrecioProductoPorCliente();
    var productPriceMap = null; //productDataMap.get("productPriceMap");
    var productUnidadMedidaIdMap = null//productDataMap.get("productUnidadMedidaIdMap");

    // productPriceMap.set("TOTAL", 0)
    showSpinner();

    var passDataList = []
    var devolucionDetailsPassDataUpdate = getDevolucionDetailsPassDataUpdate();
    if(devolucionDetailsPassDataUpdate != null){
        passDataList.push(devolucionDetailsPassDataUpdate);
    }
    var devolucionDetailsPassDataInsert = getDevolucionDetailsPassDataInsert()
    if(devolucionDetailsPassDataInsert != null){
        passDataList.push(devolucionDetailsPassDataInsert)
    }
    var devolucionDetailsPassDataDelete = getDevolucionDetailsPassDataDelete()
    if(devolucionDetailsPassDataDelete != null){
        passDataList.push(devolucionDetailsPassDataDelete)
    }
    //acenturion
    //var devolucionDetailsUpdateLastUserModified = getDevolucionUpdateLastUserModified();
    var detailChangeFlag = false;
    if(passDataList != null && passDataList != [] && passDataList.length > 0){
        //passDataList.push(devolucionDetailsUpdateLastUserModified);
        detailChangeFlag = true;
    }
    var montoTotal = 0 //Math.round(productPriceMap.get("TOTAL"));
    var passData = getDevolucionPassDataUpdate(montoTotal, detailChangeFlag);
    passData.parentId = getDevolucionId();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                goToBackUrl()
            }else{
                alert('No se pudo guardar la devolucion: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo guardar la devolucion');
        }
    });

}

function getDevolucionPassDataUpdate(montoTotal, detailChangeFlag){
    var sb = new StringBuilder();
    sb.append("UPDATE devolucion SET devolucion_motivo_id = ?, devolucion_estado_id = ?, devolucion_tipo_id = ? , vendedor_id = ?, ");
    sb.append("factura_fecha = ?, nc_fecha = ?, factura_nro = ?, ");
    sb.append("metodo_de_carga_id = ?, creado_por_usuario_id = ?, activo = ?, fecha = current_timestamp, observacion = ?, monto_total = ?, ");
    sb.append("snc_nro = ?, fletero_id = ?, sucursal_id = ?, ");
    sb.append("cliente_id = ?, nc_nro = ?, con_snc = ?, user_last_updated_id = ?, portal_fecha_ultima_actualizacion = current_timestamp WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosDevolucionUpdate(montoTotal, detailChangeFlag);
    passData.argsToSet = JSON.stringify(argsToSet);

    return passData;
}

function getDatosDevolucionUpdate(montoTotal, detailChangeFlag){
    var devolucionMotivoId = jQuery("#motivoDevolucionSelectId").val();
    var fleteroId = jQuery("#fleteroSelectId").val();
    var clienteId = jQuery("#clienteSelectId").val();
    var sncNro = document.getElementById("sncNroId").value;
    var facturaNro = document.getElementById("facturaNroId").value;
    var facturaFecha = document.getElementById("fechaFacturaId").value;
    var ncFecha = document.getElementById("fechaNcId").value;
    var devolucionEstadoId = getOneValueFromTableAndCode("id", "devolucion_estados", DEVOLUCION.ESTADOS.PENDIENTE_REGISTRO.PENDIENTE_DEPOSITO.LABORATORIO.CODIGO);

    var devolucionTipoCode = getDevolucionTipoCode();
    var devolucionTipoId = getOneValueFromTableAndCode("id", "devolucion_tipos", devolucionTipoCode);
    //var vendedorId;
    var metodoDeCargaId = getOneValueFromTableAndCode("id", "devolucion_metodo_de_carga", DEVOLUCION.METODO_DE_CARGA.MANUAL.CODIGO);
    var creadoPorUsuario = getLoggedUserId();
    var activo = true;
    var observacion = document.getElementById("observacionId").value;
    var ncNro;
    var esConSNC = getById("esConSNCId").checked;
    var columnsMap = new Map();
    var devolucionId = getDevolucionId();
    var formattedNcFecha = "";
    if(ncFecha != null && ncFecha != "" && ncFecha != undefined){
        var formattedNcFecha = ncFecha.split("/").reverse().join("-")+" 00:00:00.0";
    }
    var formattedFacturaFecha = "";
    if(facturaFecha != null && facturaFecha != "" && facturaFecha != undefined){
        formattedFacturaFecha = facturaFecha.split("/").reverse().join("-")+" 00:00:00.0";
    }
    let obj = null;
    var originalMotivoDevolucion = "";
    if(getMotivoDevolucionId() != null && getMotivoDevolucionId() != undefined){
        originalMotivoDevolucion = getMotivoDevolucionId();
    }
    if(devolucionMotivoId != originalMotivoDevolucion.toString() || fleteroId != getFleteroId().toString() || clienteId != getClienteId().toString()
        || esConSNC.toString() != getConSNC().toString() ||
        sncNro != getSNCNro().toString() || formattedNcFecha != getFechaNc().toString() || facturaNro != getFacturaNro().toString()
        || formattedFacturaFecha != getFacturaFecha().toString() ||
        observacion != getObservacion().toString() || detailChangeFlag){
        columnsMap.set(1, [devolucionMotivoId, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(2, [devolucionEstadoId, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(3, [devolucionTipoId, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(4, [null, DATABASE.DATA_TYPE.BIGINT]) //vendedor
        columnsMap.set(5, [facturaFecha, DATABASE.DATA_TYPE.TIMESTAMP])
        columnsMap.set(6, [ncFecha, DATABASE.DATA_TYPE.TIMESTAMP])
        columnsMap.set(7, [facturaNro, DATABASE.DATA_TYPE.VARCHAR])
        columnsMap.set(8, [metodoDeCargaId, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(9, [creadoPorUsuario, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(10, [activo, DATABASE.DATA_TYPE.BOOLEAN])
        columnsMap.set(11, [observacion, DATABASE.DATA_TYPE.VARCHAR])
        columnsMap.set(12, [montoTotal, DATABASE.DATA_TYPE.DOUBLE]) //monto total
        columnsMap.set(13, [sncNro, DATABASE.DATA_TYPE.VARCHAR])
        columnsMap.set(14, [fleteroId, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(15, [null, DATABASE.DATA_TYPE.BIGINT]) //sucursales
        columnsMap.set(16, [clienteId, DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(17, [ncNro, DATABASE.DATA_TYPE.VARCHAR])
        columnsMap.set(18, [esConSNC, DATABASE.DATA_TYPE.BOOLEAN])
        columnsMap.set(19, [getLoggedUserId(), DATABASE.DATA_TYPE.BIGINT])
        columnsMap.set(20, [devolucionId, DATABASE.DATA_TYPE.BIGINT])
        obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
    }

    return obj;
}
function getDevolucionDetailsPassDataUpdate(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("UPDATE devolucion_detalle SET cantidad_documentada = ?, devolucion_id = ?, precio_unitario = ?, unidad_medida_id = ?, ");
    sb.append("producto_id = ?, precio_total = ?, cantidad_verificada = ?, motivo_devolucion_documentada_id = ?, ");
    sb.append("motivo_devolucion_verificada_id = ?, observacion = ? WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosDevolucionDetalleUpdate();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosDevolucionDetalleUpdate(){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let trProductosExistentes = document.getElementsByClassName("existing-product");
    let devolucionDetallesList = [];
    for(let i = 0; i < trProductosExistentes.length; i++){
        let trElement = trProductosExistentes[i];
        var productId = trElement.getAttribute("attr-product-id");
        let cantidadProductoOriginal = trElement.getAttribute("attr-product-quantity");
        let cantidadProducto = getById("cantidad-"+productId).value;
        let observacionProductoOriginal = trElement.getAttribute("attr-product-observacion");
        var observacion = document.getElementById("observacionId").value;
        let precioUnitarioOriginal = trElement.getAttribute("attr-product-precioUnitario")
        //let precioUnitario = Math.round(productPriceMap.get(productId));
        let precioTotal = Math.round(cantidadProducto*precioUnitarioOriginal);
        // productPriceMap.set("TOTAL", Math.round(productPriceMap.get("TOTAL")+precioTotal));
        if(cantidadProductoOriginal != cantidadProducto || observacionProductoOriginal != observacion
            /*|| precioUnitarioOriginal != precioUnitario*/){
            let unidadMedidaId = null
            let sucursalId = null;
            //todo acenturion
            var devolucionMotivoId = jQuery("#motivoDevolucionSelectId").val();
            var devolucionDetalleId = trElement.getAttribute("attr-devolucion-detalle-id");
            let columnsMap = new Map();
            columnsMap.set(1, [cantidadProducto, DATABASE.DATA_TYPE.INTEGER]) //Cantidad Documentada
            columnsMap.set(2, ['parentId',      DATABASE.DATA_TYPE.BIGINT])
            columnsMap.set(3, [precioUnitarioOriginal,  DATABASE.DATA_TYPE.DOUBLE])
            columnsMap.set(4, [unidadMedidaId,  DATABASE.DATA_TYPE.BIGINT]) //vendedor
            columnsMap.set(5, [productId,       DATABASE.DATA_TYPE.BIGINT])
            columnsMap.set(6, [precioTotal,     DATABASE.DATA_TYPE.DOUBLE])
            columnsMap.set(7, [cantidadProducto, DATABASE.DATA_TYPE.BIGINT]) //Cantidad Verificada
            columnsMap.set(8, [devolucionMotivoId, DATABASE.DATA_TYPE.BIGINT])
            columnsMap.set(9, [devolucionMotivoId, DATABASE.DATA_TYPE.BIGINT])
            columnsMap.set(10, [observacion, DATABASE.DATA_TYPE.VARCHAR])
            columnsMap.set(11, [devolucionDetalleId, DATABASE.DATA_TYPE.BIGINT]) //Motivo Verificado
            let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
                obj[key] = value;
                return obj;
            }, {});
            devolucionDetallesList.push(obj);
        }
    }

    return devolucionDetallesList;

}

function getDevolucionDetailsPassDataDelete(){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("DELETE FROM devolucion_detalle WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosDevolucionDetalleDelete();
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosDevolucionDetalleDelete(){
    //cantidad, devolucion_id, precio_unitario, unidad_medida_id, producto_id, sucursal_id, precio_total
    let devolucionDetallesList = [];
    for(let i = 0; i < devolucionDetalleToDeleteList.length; i++){
        let devolucionDetalleId = devolucionDetalleToDeleteList[i]
        let columnsMap = new Map();
        columnsMap.set(1, [devolucionDetalleId, DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        devolucionDetallesList.push(obj);
    }
    return devolucionDetallesList;
}

function getPrecioProductoPorCliente(){
    var productDataMap = new Map();
    var productPriceMap = new Map();
    var productUnidadMedidaIdMap = new Map();
    var clienteId = jQuery("#clienteSelectId").val();
    var productoSeleccionadosId = jQuery('#productMultiSelect2Id').val().toString();
    var urlStr = getGetDataFromQueryURL();
    var passData = {};

    var query = new StringBuilder();
    query.append("SELECT p.id, p.codigo_barra, p.categoria, p.producto, gcpv.gc_listas_de_precios_id, ");
    query.append("lp.descripcion, gcpv.unidad_medidas_id, um.unidad_medida, gcpv.importe ");
    query.append("FROM gc_carga_de_precios_de_ventas gcpv ");
    query.append("JOIN gc_listas_de_precios lp ON lp.id = gcpv.gc_listas_de_precios_id ");
    query.append("JOIN gc_unidad_medidas um ON um.id = gcpv.unidad_medidas_id ");
    query.append("JOIN gc_productos p ON p.id = gcpv.gc_productos_id ");
    query.append("JOIN gc_clientes c ON c.listas_de_precios_id = lp.id ");
    query.append("WHERE 1=1 ")
    query.append("AND c.id = "+clienteId);
    query.append("AND p.id in ("+productoSeleccionadosId+") ");
    query.append("AND um.unidad_medida in ('Bot', 'Und', 'Lat', 'Tet') ");
    passData.query = query.toString();
    var productsSelectedDtoList = getDataFromQueryAjax(urlStr, passData)
    for(var x = 0; x < productsSelectedDtoList.length; x++){
        var productDto = productsSelectedDtoList[x];
        //SE AJUSTA ESTA PARTE PARA APLICAR YA DIRECTAMENTE EL PRECIO CON IVA DEL PRODUCTO
        var iva = (productDto.importe * 10)/100;
        var importeConIva = productDto.importe + iva;
        productPriceMap.set(productDto.id, importeConIva);
        productUnidadMedidaIdMap.set(productDto.id, productDto.unidad_medidas_id);
    }

    productDataMap.set("productPriceMap", productPriceMap);
    productDataMap.set("productUnidadMedidaIdMap", productUnidadMedidaIdMap);
    return productDataMap;
}

function getProductosDevolucionesWhitLimit(){
    var url = getGetDataFromQueryAndPsURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("SELECT gump.gc_productos_id as id, min(gump.cantidad) as cantidad, um.unidad_medida, p.producto, ");
    sb.append("concat(p.id,CASE WHEN p.codigo_barra is not null THEN CONCAT(' - ', p.codigo_barra) END, ");
    sb.append("CONCAT(' - ',p.producto)) as result, p.codigo_barra, p.categoria, p.producto, ");
    sb.append("um.id as unidad_medida_id ");
    sb.append("FROM gc_unidad_medida_productos gump ");
    sb.append("JOIN gc_unidad_medidas um ON um.id = gump.gc_unidad_medidas_id ");
    sb.append("JOIN gc_productos p ON p.id = gump.gc_productos_id ");
    sb.append("WHERE 1=1 ");

    passData.query = sb.toString();
    var productMultiSelect2Element = jQuery('#productMultiSelect2Id');
    setSelect2WhitLimit(productMultiSelect2Element, sb.toString(), setProductosDevolucionesData, getProductosDevolucionesFilterQuery, url)
    productMultiSelect2Element.on("select2:select", async function (e) {
        var id = e.params.data.id;
        var importe = e.params.data.queryData.importe;
        //todo acenturion
        var iva = (importe * 10)/100;
        importe = Math.round(importe + iva);
        var unidadMedida = e.params.data.queryData.unidad_medida_id;
        await addProductsSelectedInTable(id, importe, unidadMedida);
    });
    productMultiSelect2Element.on("select2:unselect", function (e) {
        var id = e.params.data.id;
        removeTrFromTrId("product-tr-id-"+id)
    });
}

function setProductosDevolucionesData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}

function getProductosDevolucionesFilterQuery(query, filter){
    var clienteId = jQuery("#clienteSelectId").val()
    var sb = new StringBuilder();
    sb.append(query.toString()+" ");

    sb.append(" AND p.active_odoo is true ")
    var selectedProducts = jQuery('#productMultiSelect2Id').val().toString()
    if(selectedProducts != undefined && selectedProducts != null && selectedProducts.trim() != ''){
        sb.append(" AND p.id NOT IN ("+selectedProducts+") ")
    }

    if(filter != undefined && filter != null && filter.trim() != ''){
        sb.append("AND concat(p.id,CASE WHEN p.codigo_barra is not null THEN CONCAT(' - ', p.codigo_barra) END, CONCAT(' - ',p.producto)) ilike ? ")
    }

    sb.append("group by gump.gc_productos_id, um.unidad_medida, p.producto, ");
    sb.append("concat(p.id,CASE WHEN p.codigo_barra is not null THEN CONCAT(' - ', p.codigo_barra) END, ");
    sb.append("CONCAT(' - ',p.producto)), p.codigo_barra, p.categoria, p.producto, ");
    sb.append("um.id ");
    sb.append("having min(gump.cantidad) = 1 ");
    sb.append("order by gump.gc_productos_id asc ");

    return sb.toString();

}