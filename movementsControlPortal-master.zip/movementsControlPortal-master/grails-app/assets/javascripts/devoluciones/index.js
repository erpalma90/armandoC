function initJsPage(){
    dataTableInitialize();
}

async function dataTableInitialize(){
    $.noConflict();
    var table = $('#example').DataTable();
    // Add event listener for opening and closing details
    jQuery('#example tbody').on('click', 'td.details-control', async function () {
        //recuperamos el id de la devolucion
        // Get the rows id value
        var id = table.row(this).id();
        id = id.replace(/\D/g, '');
        id = parseInt(id, 10);

        var tr = jQuery(this).closest('tr');
        var row = table.row(tr);
        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        }else {
            var urlStr = getGetDataFromQueryURL();
            var passData = {};
            var sb = new StringBuilder();
            sb.append("SELECT p.id, p.codigo_barra, p.producto, dd.cantidad_documentada, dm.devolucion_motivo, ");
            sb.append("dd.nro_documento_relacionado, dd.precio_unitario, precio_total ");
            sb.append("FROM devolucion_detalle dd JOIN gc_productos p ON p.id = dd.producto_id ");
            sb.append("LEFT JOIN devolucion_motivos dm ON dm.id = dd.motivo_devolucion_documentada_id ");
            sb.append("WHERE devolucion_id = ")
            sb.append(id)
            //passData.query = "SELECT p.id, p.codigo_barra, p.producto, dd.cantidad FROM devolucion_detalle dd JOIN gc_productos p ON p.id = dd.producto_id WHERE devolucion_id = "+id+")"
            passData.query = sb.toString();
            var productosDtoList = await getDataFromQueryAjax(urlStr, passData)
            row.child(format(productosDtoList)).show();
            tr.addClass('shown');
        }
    });
}


/* Formatting function for row details - modify as you need */
function format(dataDtoList) {
    var fila = "";
    if (dataDtoList != '') {
        for (var dataDto in dataDtoList) {
            var data = dataDtoList[dataDto]
            if(data.codigo_barra == null){
                data.codigo_barra = "";
            }
            if(data.nro_documento_relacionado == null){
                data.nro_documento_relacionado = "";
            }
            console.log("data: "+data);
            fila = fila + '<tr><td>' + data.id + '</td><td>' + data.codigo_barra + '</td><td>' + data.producto + '</td><td>' + data.cantidad_documentada + '</td><td>' + data.devolucion_motivo + '</td><td>' + data.nro_documento_relacionado + '</td><td>' + data.precio_unitario + '</td><td>' + data.precio_total + '</td></tr>';
        }
        return '<table style="width:100%" id="example" class="display">' +
            '<thead>' +
            '<tr>' +
            '<th>Producto ID</th>' +
            '<th>Codigo Barra</th>' +
            '<th>Descripcion</th>' +
            '<th>Cantidad</th>' +
            '<th>Motivo Devolucion</th>' +
            '<th>Factura</th>' +
            '<th>Prec. Unit</th>' +
            '<th>Prec. Tot</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>' +
            fila +
            '</tbody>' +
            '</table>';
    }
}

function mostrar_rechazos(id){
    var parametros={
        "tipo":"listar_rechazos",
        "devolucion_id": id};
    $.ajax({
        url:'dev_apro_deposito_rechazos.php',
        data: parametros,
        beforeSend: function(objeto){
            $('.items').html('Cargando...');
        },
        success:function(data){
            $(".items").html(data).fadeIn('slow');
        }
    })
}