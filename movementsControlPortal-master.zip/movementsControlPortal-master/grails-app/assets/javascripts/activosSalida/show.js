
function areYouShureActivosSalidaAprovvedModalInShow(activosSalidaId){
    acceptOrCancellModal("Estas seguro? ", "Estas seguro de realizar la aprobacion de la salida de activos?" ,'warning' ,
        "Si, aprobar", function () {return actualizacionActivosSalidaEstado(ACCION_APROBAR, activosSalidaId)});
}



async function actualizacionActivosSalidaEstado(value, activosSalidaId){
    showSpinner();
    try {
        var passData = new Object();
        passData.checkedList = activosSalidaId;
        var newStatus = "";
        if(value == ACCION_APROBAR){
            if(CURRENT_ROLE == ROLES.ROLE_DEPOSITO || CURRENT_ROLE == ROLES.ROLE_REGISTRO || CURRENT_ROLE == ROLES.ROLE_ADMIN){
                newStatus = ACTIVOS_SALIDA.ESTADO.APROBADO_DEPOSITO.CODIGO;
            }
        }

        passData.nuevoEstado = newStatus;
        var returnActualizacionDeEstado = ajaxGetData(updateActivosSalidaEstadoUrl(), passData, resolveResult);
        if(returnActualizacionDeEstado != ERROR.AJAX_RETURN){
            var obs = "";
            let obj = new Object();
            obj.estado = passData.nuevoEstado;
            obj.observacion = obs;
            await saveInAuditoria(activosSalidaId, JSON.stringify(obj), passData.nuevoEstado, "U", obs);
        }
    }catch (error){
        hideSpinner();
        alert("Error accionAprobar: "+error)
    }
}

function resolveResult(data){
    var resumenComprobanteStockDto = JSON.parse(data);
    if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_SUCCESS_TRANSACTION){
        reloadThisPage()
    }else if(resumenComprobanteStockDto.serverAction == SERVER_RESPONSE.SERVER_ERROR){
        hideSpinner();
        swalNotification('top-center', 'error', 'NO SE PUEDE EJECUTAR, CONSULTAR CON TI', 2000);
    }else{
        hideSpinner();
        swalNotification('top-center', 'warning', resumenComprobanteStockDto.message, 7000)
    }
}


function saveInAuditoria(id, estadoRetornoJson, estado, action, observation){
    var data = new Object();
    data.action = action;
    data.dominioId = id;
    data.observacion = observation;
    data.dominio = "Activos_Salida"
    data.userId = getLoggedUserId();
    data.estado = estado;
    data.datos = estadoRetornoJson;
    insertarAuditoria(data);
}
