async function initJsPage(){
    //await retornosMotivosSelect2();
    await getFleteroWhitLimit();
}

function saveActivosSalida(){
    showSpinner()
    var existFleteroEnFechaFlag = validateActivosSalidaFleteroFechaExist();
    if(parseInt(existFleteroEnFechaFlag) == 0){
        var insertList = [];
        getInsertUpdateOrDeleteMapList(null, insertList, null)
        if(insertList.length > 0){
            var passDataList = [];
            passDataList.push(getActivosSalidaDetailsPassDataInsert(insertList))
            var passData = getActivosSalidaPassDataInsert();
            passData.details = JSON.stringify(passDataList);
            var urlStr = getDynamicExecuteUpdateUrl();
            jQuery.ajax({
                url: urlStr,
                type: 'PUT',
                async:false,
                data: passData,
                success: function(data) {
                    if(data != ERROR.SERVER_ERROR){
                        goToUrl(getIndexUrl(), getActivosSalidaShowUrl()+"/"+data, true);
                    }else{
                        alert('No se pudo guardar el activo salida: e '+ERROR.SERVER_ERROR);
                        hideSpinner();
                    }
                },
                error: function () {
                    hideSpinner();
                    alert('Error, no se pudo guardar el activo salida');
                }
            });
        }else{
            hideSpinner()
            var txtSb = new StringBuilder();
            txtSb.append("No se puede guardar, todas las cantidades de productos estan en cero.")
            swalNotification('top-center', 'warning', txtSb.toString(), 3000);
        }

    }else{
        hideSpinner()
        var txtSb = new StringBuilder();
        txtSb.append("No se puede crear esta salida de activo, el fletero ya cuenta con una salida de activo creado en ");
        txtSb.append("la fecha.")
        swalNotification('top-center', 'warning', txtSb.toString(), 3000);
    }

}




function getActivosSalidaPassDataInsert(){
    var sb = new StringBuilder();
    sb.append("INSERT INTO activos_salida(id, version, fecha, gc_fletero_id, activos_salida_estado_id, user_creation_id, user_creation_date, observacion) ");
    sb.append("VALUES (nextval('activos_salida_seq'), 0, current_timestamp, ?, ?, ?, current_timestamp, ?) ");

    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosActivosSalidaInsert();
    passData.argsToSet = JSON.stringify(argsToSet);
    return passData;
}

function getDatosActivosSalidaInsert(){
    var gcFleteroId = jQuery("#fleteroSelectId").val();

    var activosSalidaEstadoPendienteId = getOneValueFromTableAndCode("id", "activos_salida_estados",
        ACTIVOS_SALIDA.ESTADO.PENDIENTE_DEPOSITO.CODIGO);
    var userCreationId = getLoggedUserId();
    var observacion = getById("observacionId").value;
    var columnsMap = new Map();
    columnsMap.set(1, [gcFleteroId                      , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(2, [activosSalidaEstadoPendienteId   , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(3, [userCreationId                   , DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(4, [observacion                      , DATABASE.DATA_TYPE.VARCHAR]);


    let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
    return obj;

}