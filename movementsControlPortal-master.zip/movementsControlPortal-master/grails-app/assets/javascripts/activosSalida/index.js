function initJsPage(){
    jQuery("#activosSalidaTableId").DataTable()
}