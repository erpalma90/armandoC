var retornoDetalleToDeleteList = [];
async function initJsPage(){
    await getFleteroWhitLimit();
    //await retornosMotivosSelect2();
    await loadRetornosData();
    //await getFleteroWhitLimit()


}

async function loadRetornosData(){
    setOptToSelect2(jQuery("#fleteroSelectId"), getFleteroNroAndName(), getFleteroId());
    getById("observacionId").value = getObservacion();
}



function updateActivosSalida(){
    showSpinner()
    var newFleteroId = jQuery("#fleteroSelectId").val();
    var existFleteroEnFechaFlag = validateActivosSalidaFleteroFechaExist();
    if(parseInt(existFleteroEnFechaFlag) == 0 || parseInt(newFleteroId) == parseInt(getFleteroId())){
        var updateList = [];
        var insertList = [];
        var deleteList = [];
        getInsertUpdateOrDeleteMapList(updateList, insertList, deleteList)
        executeUpdateActivosSalidaDetalle(updateList, insertList, deleteList);
    }else{
        hideSpinner()
        var txtSb = new StringBuilder();
        txtSb.append("No se puede actualizar esta salida de activo, el fletero ya cuenta con una salida de activo creado en ");
        txtSb.append("la fecha.")
        swalNotification('top-center', 'warning', txtSb.toString(), 3000);
    }


}

function executeUpdateActivosSalidaDetalle(updateList, insertList, deleteList){
    var passDataList = []
    var detailsPassDataUpdate = getActivosSalidaDetailsPassDataUpdate(updateList);
    if(detailsPassDataUpdate != null){
        passDataList.push(detailsPassDataUpdate);
    }

    var detailsPassDataInsert = getActivosSalidaDetailsPassDataInsert(insertList)
    if(detailsPassDataInsert != null){
        passDataList.push(detailsPassDataInsert)
    }

    var detailsPassDataDelete = getActivosSalidaDetailsPassDataDelete(deleteList)
    if(detailsPassDataDelete != null){
        passDataList.push(detailsPassDataDelete)
    }


    var passData = getActivosSalidaPassDataUpdate();
    passData.parentId = getActivosSalidaId();
    passData.details = JSON.stringify(passDataList);
    var urlStr = getDynamicExecuteUpdateUrl();
    jQuery.ajax({
        url: urlStr,
        type: 'PUT',
        async:false,
        data: passData,
        success: function(data) {
            if(data != ERROR.SERVER_ERROR){
                goToUrl(getIndexUrl(), getActivosSalidaShowUrl()+"/"+data, true);
            }else{
                alert('No se pudo guardar la salida de activo: e '+ERROR.SERVER_ERROR);
                hideSpinner();
            }
        },
        error: function () {
            hideSpinner();
            alert('Error, no se pudo guardar la salida de activo');
        }
    });
}



function getActivosSalidaDetailsPassDataUpdate(updateList){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("UPDATE activos_salida_detalle SET version = version+1, cantidad = ? WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosActivosSalidaDetalleUpdate(updateList);
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosActivosSalidaDetalleUpdate(updateList){
    let detallesList = [];
    for(let i = 0; i < updateList.length; i++){
        var activosSalidaDetalleMap = updateList[i]
        let columnsMap = new Map();
        columnsMap.set(1, [activosSalidaDetalleMap.cantidad,                DATABASE.DATA_TYPE.INTEGER]);
        columnsMap.set(2, [activosSalidaDetalleMap.activosSalidaDetalleId,  DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        detallesList.push(obj);
    }
    return detallesList;
}

function getActivosSalidaPassDataUpdate(){
    var sb = new StringBuilder();
    sb.append("UPDATE activos_salida SET version=version+1, gc_fletero_id=?, activos_salida_estado_id=?, ");
    sb.append("user_last_updated_date=current_timestamp, user_last_updated_id=?, observacion=? ");
    sb.append("WHERE id = ? ");

    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosActivosSalidaUpdate();
    passData.argsToSet = JSON.stringify(argsToSet);

    return passData;
}

function getDatosActivosSalidaUpdate(){
    var currentUserId = getLoggedUserId();
    var gcFleteroId = jQuery("#fleteroSelectId").val();
    var estadoPendienteId = getOneValueFromTableAndCode("id", "activos_salida_estados", ACTIVOS_SALIDA.ESTADO.PENDIENTE_DEPOSITO.CODIGO);
    var observacion = getById("observacionId").value;

    let obj = null;
    var columnsMap = new Map();
    columnsMap.set(1, [gcFleteroId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(2, [estadoPendienteId, DATABASE.DATA_TYPE.BIGINT]);
    columnsMap.set(3, [currentUserId, DATABASE.DATA_TYPE.BIGINT])
    columnsMap.set(4, [observacion, DATABASE.DATA_TYPE.VARCHAR]);
    columnsMap.set(5, [getActivosSalidaId(), DATABASE.DATA_TYPE.BIGINT]);

    obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});

    return obj;
}

function getActivosSalidaDetailsPassDataDelete(deleteList){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("DELETE FROM activos_salida_detalle WHERE id = ? ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosActivosSalidaDetalleDelete(deleteList);
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosActivosSalidaDetalleDelete(deleteList){
    let devolucionDetallesList = [];
    for(let i = 0; i < deleteList.length; i++){
        let activosSalidaDetalleMap = deleteList[i]
        let columnsMap = new Map();
        columnsMap.set(1, [activosSalidaDetalleMap.activosSalidaDetalleId, DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        devolucionDetallesList.push(obj);
    }
    return devolucionDetallesList;
}