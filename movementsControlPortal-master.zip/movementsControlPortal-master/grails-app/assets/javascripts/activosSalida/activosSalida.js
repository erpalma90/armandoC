function getFleteroWhitLimit(){
    var url = getGetDataFromQueryAndPsInGCURL();
    var passData = {};
    var sb = new StringBuilder();
    //sb.append("SELECT id, fletero as result FROM gc_fletero ");
    sb.append("SELECT TOP 300 f.[Id Fleteros] as id, cast(f.[Numero Camion] as varchar)+'-'+cast(f.nombre as varchar) AS result  ");
    sb.append("FROM [VTA_C Comprobantes de Ventas] cv ");
    sb.append("INNER JOIN vta_fleteros f ON ");
    sb.append("cv.[id sucursales] = f.[id sucursales] AND ");
    sb.append("cv.[id fleteros] = f.[id fleteros] ");
    sb.append("WHERE cv.Status = '00' AND cv.[Fecha] > '01/01/2021' ");
    sb.append("AND cv.[fecha cierre] IS NULL ");
    passData.query = sb.toString();
    var fleteroSelect2Element = jQuery('#fleteroSelectId');
    setSelect2WhitLimit(fleteroSelect2Element, sb.toString(), setFleteroData, getFleteroFilterQuery, url)

    fleteroSelect2Element.on('change', function (e) {
        $('#facturaNroSelect2Id').val(null).trigger('change');
    });
}


function setFleteroData(filter, query){
    if(filter != null && filter != undefined && filter.trim() != ''){
        var columnsMap = new Map();
        columnsMap.set(1, ['%'+filter+'%', DATABASE.DATA_TYPE.VARCHAR]);

        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        return obj;
    }
}


function getFleteroFilterQuery(query, filter){
    if(filter != undefined && filter != null && filter.trim() != ''){
        query = query+" AND cast(f.[Numero Camion] as varchar)+'-'+cast(f.nombre as varchar) like ? "
    }
    return query+" GROUP BY f.[Id Fleteros], f.[Numero Camion], f.nombre ORDER BY result ASC ";
}


var currentStepNumberVal = 1;
function nextPalletSeparadorSalidaBtnClicked(btnElement, nextStep){
    var currentStepNumber = currentStepNumberVal;
    var currentBodyStep = getById("bodyStep"+currentStepNumber+"Id");
    //attr-required
    var parentElementId = "bodyStep"+currentStepNumber+"Id";
    var requiredFieldsOkFlag = true;
    if(nextStep == true){
        requiredFieldsOkFlag = validateRequiredFields(parentElementId);
    }

    if(requiredFieldsOkFlag){
        currentBodyStep.style.display = "none";
        if(currentStepNumber == 1){

            //loadDatosDeFactura();
            //getFacturaDetalleMultiSelect2();
            //hideSpinner();
        }
        var stepMap = getNextOrPrevousStep(currentStepNumber)
        var newStepNumber
        if(nextStep){
            newStepNumber = stepMap.get("nextStep");
            getById("previousBtnId").style.display = ""
        }else{
            newStepNumber = stepMap.get("previousStep");
            if(newStepNumber == 1){
                btnElement.style.display = "none" //Se oculta el boton de atras cuando estamos en la primera parte
            }
        }
        var newBodyStep = getById("bodyStep"+newStepNumber+"Id");
        newBodyStep.style.display = "";
        var newStepMap =  getNextOrPrevousStep(newStepNumber)
        var title = newStepMap.get("title");
        jQuery("#stepsTitleId").html(title);

        stepLine(newStepNumber);
        btnElement.setAttribute("current-step", newStepNumber)
        currentStepNumberVal = newStepNumber;
    }

}
function getNextOrPrevousStep(currentStep){
    var nextStep = 1;
    var previousStep = 1;
    var title = "Identificacion"
    switch(currentStep) {
        case 1:
            nextStep = 2;
            previousStep = 1;
            title = "Identificacion"
            break;
        case 2:
            nextStep = 4
            previousStep = 1;
            title = "Observacion"
            break;
        default:
            alert("default nextStep")
    }
    var returnMap = new Map();
    returnMap.set("nextStep", nextStep)
    returnMap.set("previousStep", previousStep);
    returnMap.set("title", title);
    return returnMap;
}

function stepLine(currentStep){
    var disabledList;
    var stepElement = getById("step"+currentStep+"Id");
    stepElement.removeAttribute("disabled");
    stepElement.classList.remove("btn-default");
    stepElement.classList.add("btn-success");
    switch(currentStep) {
        case 1:
            getById("nextBtnId").style.display = ""
            getById("saveBtnId").style.display = "none"
            getById("updateBtnId").style.display = "none"
            disabledList = ["step2Id", "step3Id", "step4Id"];
            break;
        case 2:
            getById("nextBtnId").style.display = "none"
            if(currentActivosSalidaPageName()=='create'){
                getById("saveBtnId").style.display = ""
            }else if (currentActivosSalidaPageName() == 'edit'){
                getById("updateBtnId").style.display = ""
            }
            break;
        default:
            alert("default nextStep")
    }
    if(disabledList != null && disabledList != undefined){
        for(var i = 0; i < disabledList.length; i++){
            var disabledId = disabledList[i];
            var element = getById(disabledId);
            if(element != null && element != undefined){
                element.setAttribute("disabled", "disabled");
                element.classList.remove("btn-success");
                element.classList.add("btn-default");
            }
        }
    }
}


function getActivosSalidaDetailsPassDataInsert(insertList){
    //todo acenturion
    var sb = new StringBuilder();
    sb.append("INSERT INTO activos_salida_detalle(id, version, cantidad, gc_producto_id, activos_salida_id) ");
    sb.append("VALUES (nextval('activos_salida_detalle_seq'), 0, ?, ?, ?) ");
    var insertQuery = sb.toString();
    var passData = new Object();
    passData.query = insertQuery.toString();
    var argsToSet = getDatosActivosSalidaDetalleInsert(insertList);
    passData.argsToSet = argsToSet;
    var finalValue = null;
    if(argsToSet == null || argsToSet == "" || argsToSet == []){
        finalValue = null;
    }else{
        finalValue = JSON.stringify(passData);
    }
    return finalValue;
}

function getDatosActivosSalidaDetalleInsert(insertList){
    let detallesList = [];
    for(let i = 0; i < insertList.length; i++){
        var activosSalidaDetalleMap = insertList[i]
        let columnsMap = new Map();
        columnsMap.set(1, [activosSalidaDetalleMap.cantidad,                DATABASE.DATA_TYPE.INTEGER]);
        columnsMap.set(2, [activosSalidaDetalleMap.productId,               DATABASE.DATA_TYPE.BIGINT]);
        columnsMap.set(3, ['parentId',                                      DATABASE.DATA_TYPE.BIGINT]);
        let obj = Array.from(columnsMap).reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
        detallesList.push(obj);
    }
    return detallesList;
}


function getInsertUpdateOrDeleteMapList(updateList, insertList, deleteList){
    var elements = document.getElementsByClassName("tr-activosSalida");
    var activosSalidaDetalleMap = null;
    for(var i = 0; i < elements.length; i++){
        activosSalidaDetalleMap = new Object();
        var element = elements[i];
        var cantidadElement = element.getElementsByClassName("cantidad")[0]
        if(cantidadElement != null && cantidadElement != undefined){
            var cantidad = parseInt(cantidadElement.value);
            var activosSalidaDetalleId          = cantidadElement.getAttribute("attr-activosSalidaDetalleId");
            var activosSalidaDetalleCantidad    = parseInt(cantidadElement.getAttribute("attr-activosSalidaDetalleCantidad"));
            var productoId                      = cantidadElement.getAttribute("attr-productoId");
            if(activosSalidaDetalleId != null && activosSalidaDetalleId != undefined && activosSalidaDetalleId != ""){
                if(cantidad != 0 && cantidad != activosSalidaDetalleCantidad){
                    activosSalidaDetalleMap.activosSalidaDetalleId = activosSalidaDetalleId
                    activosSalidaDetalleMap.cantidad = cantidad;
                    updateList.push(activosSalidaDetalleMap)
                }else if(cantidad == 0){
                    activosSalidaDetalleMap.activosSalidaDetalleId = activosSalidaDetalleId
                    deleteList.push(activosSalidaDetalleMap)
                }
            }else{
                if(cantidad > 0){
                    activosSalidaDetalleMap.productId = productoId
                    activosSalidaDetalleMap.cantidad = cantidad;
                    insertList.push(activosSalidaDetalleMap)
                }
            }
        }

    }
}

function validateActivosSalidaFleteroFechaExist(){
    var fleteroId = jQuery("#fleteroSelectId").val();
    var sb = new StringBuilder();
    sb.append("SELECT count(asa.*) FROM activos_salida asa ");
    sb.append("LEFT JOIN activos_entrada ae ON ae.activos_salida_id = asa.id ");
    sb.append("LEFT JOIN activos_entrada_estados aee ON aee.id = ae.activos_entrada_estado_id ");
    sb.append("WHERE asa.gc_fletero_id = "+fleteroId+" AND cast(asa.fecha as DATE) = current_date ");
    sb.append("AND (aee.codigo != '"+ACTIVOS_ENTRADA.ESTADO.APROBADO_REGISTRO.APROBADO_DEPOSITO.CODIGO+"' OR aee.codigo IS NULL)");


    var urlStr = getGetDataFromQueryURL();
    var passData = new Object();
    passData.query = sb.toString();
    var list = getDataFromQueryAjax(urlStr, passData);
    return list[0].count
}

var dataTable = null;
async function showActivosSalidaAudit(activosSalidaId){
    var activosSalidaDtoList = null;
    if(dataTable != null){
        dt2.clear();
        dt2.destroy()
        //dataTable.fnDraw(false);
    }
    var cardElement = getById("cardBodyId")
    jQuery(cardElement).children().remove();

    var devolucionesTableElement = getById("auditoriaTableId");
    var newDevolucionesTableElement = devolucionesTableElement.cloneNode(true);
    newDevolucionesTableElement.setAttribute("id", "");
    newDevolucionesTableElement.style.display = "";

    cardElement.appendChild(newDevolucionesTableElement);
    var newTableElement = cardElement.getElementsByTagName("table")[0]
    newTableElement.setAttribute("id", "auditoriaTableId");
    var newTbodyElement = newTableElement.getElementsByTagName("tbody")[0];
    newTbodyElement.setAttribute("id", "auditoriaTbodyId");
    var newOriginalTrElement = newTbodyElement.getElementsByTagName("tr")[0];
    newOriginalTrElement.setAttribute("id", "auditoriaTableTrId");


    var urlStr = getGetDataFromQueryURL();
    var passData = {};
    var sb = new StringBuilder();
    sb.append("select aj.*, u.username, r.authority from audit_json aj ");
    sb.append("join users u on u.id = aj.user_id ")
    sb.append("join users_roles ur on ur.users_id = u.id ");
    sb.append("join roles r on ur.roles_id = r.id ");
    sb.append("WHERE aj.table_id = '"+activosSalidaId+"' AND table_name = 'activos_salida'  order by aj.date desc");

    passData.query = sb.toString();
    activosSalidaDtoList = await getDataFromQueryAjax(urlStr, passData)
    var tbodyElement = getById("auditoriaTbodyId");
    var originalTrElement = getById("auditoriaTableTrId");
    var formatter= 'DD-MM-YYYY HH:mm';
    for(var x = 0; x < activosSalidaDtoList.length; x++){
        var dto = activosSalidaDtoList[x];
        dto.date = formatterDate(dto.date, "DD-MM-YYYY HH:mm:ss");
        var newTrElement = originalTrElement.cloneNode(true);
        newTrElement.id = "";
        newTrElement.style.display = "";
        newTrElement.setAttribute("class", "auditoriaTrGeneradoClass");
        setDataInTableTd(newTrElement, dto)
        tbodyElement.appendChild(newTrElement)
        getById("auditoriaTableTrId").style.display = 'none'
    }
    dt2 = jQuery("#auditoriaTableId").DataTable({
        "order": [],
        "columnDefs": [ {
            "targets"  : 'no-sort',
            "orderable": false,
        }]
    });
    jQuery("#showDevolucionAuditId").modal();
}