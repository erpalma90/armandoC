// This is a manifest file that'll be compiled into application.js.
//
// Any JavaScript file within this directory can be referenced here using a relative path.
//
// You're free to add application-wide JavaScript to this file, but it's generally better
// to create separate JavaScript files as needed.
//
//= require jquery-3.3.1.min
//= require bootstrap
//= require popper.min

//= require_self
/** //= require template */





function getById(id){
    var element = document.getElementById(id);
    return element;
}

function goToUrl(currentUrl, nextUrl, appendFlag, appendParams){
    var url = nextUrl;
    if(appendFlag == undefined || appendFlag == null || appendFlag != false){
        url = url+"?lastUrl="+currentUrl
        if(appendParams != null && appendParams != ""){
            url = url.trim()+" "+appendParams.trim();
        }
    }

    location.href = url;
}

function goToBackUrl(){
    var urlStr = lastUrlToBack();
    showSpinner();
    window.location = urlStr;
}
validateAndShowMenu();
function validateAndShowMenu(){
    let menuElementsList = document.getElementsByClassName("nav-item has-treeview");
    for(var x = 0; x < menuElementsList.length; x++){
        let element = menuElementsList[x];
        let childs = element.getElementsByClassName("sec-item");
        if(childs.length == 0){
            element.style.display = 'none';
        }
    }
}

var counter = 0;
function enviromentInfo(){
    ++counter;
    if(counter == 5){
        jQuery("#enviroment-info-modal-id").modal();
        counter = 0;
    }
}



function modalConfirmFacturar(tipoMovimiento){
    var title = "Estas seguro? ";
    var text = "Estas seguro de cambiar el estado a Facturado?";
    var icon = 'warning';
    var confirmButtonText = "Si, facturado";

    acceptOrCancellModal(title, text ,icon , confirmButtonText, function () { facturado(tipoMovimiento); });
}

function facturado(tipoMovimiento){
    if(tipoMovimiento == MOVIMIENTOS.ACTIVOS_ENTRADA.CODIGO){
        updateLiquidacionStatus(LIQUIDACION.ESTADO.APROBADO.CODIGO);
    }else{
        liquidacionChangeStatus(LIQUIDACION.ESTADO.APROBADO.CODIGO);
    }
}

function validacionDeNoFacturar(tipoMovimiento){
    jQuery("#noFacturar-modal-id").modal();
    var correoDepositoSupervisor = getConfigurationValueFromKey("liquidacion.supervisor.correo.destinatario");
    jQuery("#correoNotificacionDivId").html(correoDepositoSupervisor);
    var noFacturarBtnElement = getById("noFacturarBtnId");
    noFacturarBtnElement.setAttribute("onclick", "noFacturarYEnviarCorreo("+tipoMovimiento+")")

}

async function noFacturarYEnviarCorreo(tipoMovimiento){
    var motivoRec = getById("observacionNoFacturadoLiquidacion").value
    if(motivoRec != null && motivoRec != ""){
        showSpinner();
        if(tipoMovimiento == MOVIMIENTOS.DEVOLUCION.CODIGO){
            liquidacionChangeStatus(LIQUIDACION.ESTADO.NO_FACTURADO.CODIGO, motivoRec);
        }else if(tipoMovimiento == MOVIMIENTOS.ACTIVOS_ENTRADA.CODIGO){
            updateLiquidacionStatus(LIQUIDACION.ESTADO.NO_FACTURADO.CODIGO, motivoRec);
        }
    }else{
        toastTr('warning', 'Advertencia', 'Debe describir el motivo de la no facturacion');
    }
}